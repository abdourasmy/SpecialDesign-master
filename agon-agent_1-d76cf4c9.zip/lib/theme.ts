import { useColorScheme } from 'react-native';

export const light = {
  dark: false,
  bg: '#F3F5F9', card: '#FFFFFF', text: '#0F172A', sub: '#64748B', border: '#E3E8EF',
  primary: '#0B6E8A', primarySoft: '#E0F2F7', accent: '#F59E0B', accentSoft: '#FEF3C7',
  success: '#15803D', successSoft: '#DCFCE7', danger: '#DC2626', dangerSoft: '#FEE2E2',
  warn: '#B45309', warnSoft: '#FEF3C7', info: '#4338CA', infoSoft: '#E0E7FF', input: '#F8FAFC',
  hero: '#0A2A3C', overlay: 'rgba(15,23,42,0.5)',
};
export const darkT: typeof light = {
  dark: true,
  bg: '#0A1119', card: '#131D29', text: '#F1F5F9', sub: '#94A3B8', border: '#223044',
  primary: '#38BDD8', primarySoft: '#10303B', accent: '#FBBF24', accentSoft: '#3A2D0A',
  success: '#4ADE80', successSoft: '#12301E', danger: '#F87171', dangerSoft: '#3B1616',
  warn: '#FBBF24', warnSoft: '#3A2D0A', info: '#A5B4FC', infoSoft: '#1E2250', input: '#0E1722',
  hero: '#07202E', overlay: 'rgba(0,0,0,0.65)',
};
export type Theme = typeof light;

export const useTheme = (): Theme => (useColorScheme() === 'dark' ? darkT : light);

export const R = { sm: 8, md: 12, lg: 16, xl: 22 };
