import { Bucket, DB, Op, Product, Movement, Warranty, Sale, Settings, RoleKey } from './types';
import { uid } from './format';

export const ROLE_LABEL: Record<RoleKey, string> = {
  owner: 'المالك', manager: 'مدير', receptionist: 'موظف استقبال', technician: 'فني صيانة',
  cashier: 'أمين صندوق', storekeeper: 'أمين مخزن', accountant: 'محاسب',
};
export type Perm =
  | 'dashboard' | 'sales' | 'repairs' | 'repairs.manage' | 'inventory' | 'inventory.edit' | 'purchases'
  | 'finance' | 'reports' | 'customers' | 'staff' | 'sync' | 'settings' | 'damage' | 'warranty';
const ALL: Perm[] = ['dashboard', 'sales', 'repairs', 'repairs.manage', 'inventory', 'inventory.edit', 'purchases', 'finance', 'reports', 'customers', 'staff', 'sync', 'settings', 'damage', 'warranty'];
export const ROLE_PERMS: Record<RoleKey, Perm[]> = {
  owner: ALL,
  manager: ALL.filter((p) => p !== 'settings'),
  receptionist: ['dashboard', 'repairs', 'customers', 'warranty', 'sales'],
  technician: ['repairs', 'repairs.manage', 'inventory', 'warranty'],
  cashier: ['dashboard', 'sales', 'customers', 'finance', 'warranty', 'repairs'],
  storekeeper: ['inventory', 'inventory.edit', 'purchases', 'damage', 'dashboard'],
  accountant: ['dashboard', 'finance', 'reports', 'purchases', 'customers', 'sales'],
};

export const REPAIR_STATUS: Record<string, { label: string; tone: string; icon: string }> = {
  received: { label: 'تم الاستلام', tone: 'info', icon: 'download-outline' },
  diagnosing: { label: 'قيد الفحص', tone: 'warn', icon: 'search-outline' },
  awaiting_approval: { label: 'بانتظار الموافقة', tone: 'warn', icon: 'hourglass-outline' },
  approved: { label: 'تمت الموافقة', tone: 'success', icon: 'checkmark-circle-outline' },
  waiting_parts: { label: 'بانتظار القطع', tone: 'warn', icon: 'cube-outline' },
  in_progress: { label: 'قيد الإصلاح', tone: 'primary', icon: 'construct-outline' },
  quality_check: { label: 'فحص الجودة', tone: 'info', icon: 'shield-checkmark-outline' },
  ready: { label: 'جاهز للتسليم', tone: 'success', icon: 'gift-outline' },
  delivered: { label: 'تم التسليم', tone: 'muted', icon: 'archive-outline' },
  rejected: { label: 'رفضه العميل', tone: 'danger', icon: 'close-circle-outline' },
  unrepairable: { label: 'غير قابل للإصلاح', tone: 'danger', icon: 'alert-circle-outline' },
  cancelled: { label: 'ملغي', tone: 'muted', icon: 'ban-outline' },
  abandoned: { label: 'مهجور', tone: 'muted', icon: 'trash-outline' },
};
export const TRANSITIONS: Record<string, string[]> = {
  received: ['diagnosing', 'cancelled'],
  diagnosing: ['awaiting_approval', 'unrepairable', 'cancelled'],
  awaiting_approval: ['approved', 'rejected', 'cancelled'],
  approved: ['waiting_parts', 'in_progress', 'cancelled'],
  waiting_parts: ['in_progress', 'cancelled'],
  in_progress: ['waiting_parts', 'quality_check', 'unrepairable'],
  quality_check: ['ready', 'in_progress'],
  ready: ['delivered', 'abandoned'],
  rejected: ['delivered', 'abandoned'],
  unrepairable: ['delivered', 'abandoned'],
  cancelled: ['delivered'],
  delivered: [],
  abandoned: [],
};
export const CLOSED_STATUSES = ['delivered', 'cancelled', 'abandoned'];

export const PAY_METHODS: Record<string, string> = { cash: 'نقدي', card: 'بطاقة', transfer: 'تحويل بنكي', wallet: 'محفظة إلكترونية' };
export const DAMAGE_CATS: Record<string, string> = {
  damaged: 'تالف', wastage: 'هالك', expired: 'منتهي الصلاحية', lost: 'مفقود', shortage: 'عجز مخزون',
  internal: 'استهلاك داخلي', repairable: 'تالف قابل للإصلاح',
};
export const BUCKET_LABEL: Record<Bucket, string> = {
  available: 'متاح للبيع', repairable: 'تالف قابل للإصلاح', quarantine: 'حجر', disposed: 'مُتلف / مشطوب',
};

const WH0 = 'wh-main';

export function emptyDB(): DB {
  return {
    customers: [], custDevices: [], models: [], products: [], warehouses: [{ id: WH0, name: 'المستودع الرئيسي' }],
    suppliers: [], staff: [{ id: 'staff-owner', name: 'المالك', role: 'owner', active: true }], sales: [], returns: [],
    purchases: [], purchaseReturns: [], repairs: [], movements: [], cash: [], damages: [], warranties: [], claims: [], reviews: [],
  };
}

const MODELS: [string, string, string][] = [
  ['Apple', 'iPhone 13', 'هاتف'], ['Apple', 'iPhone 14', 'هاتف'], ['Apple', 'iPhone 15 Pro', 'هاتف'],
  ['Samsung', 'Galaxy A54', 'هاتف'], ['Samsung', 'Galaxy S23', 'هاتف'], ['Xiaomi', 'Redmi Note 12', 'هاتف'],
  ['Huawei', 'Nova 11', 'هاتف'], ['Apple', 'iPad 9', 'لوحي'], ['Lenovo', 'ThinkPad T14', 'حاسوب محمول'],
  ['HP', 'Pavilion 15', 'حاسوب محمول'],
];

/** Base state is identical on every device (deterministic ids) so seeds never duplicate across replicas. */
export function initialDB(seedDemo: boolean): DB {
  const db = emptyDB();
  db.models = MODELS.map(([brand, name, category], i) => ({ id: 'seed-m' + i, brand, name, category }));
  if (!seedDemo) return db;
  const m = (i: number) => 'seed-m' + i;
  const P = (i: number, name: string, category: string, cost: number, price: number, qty: number, compat: [number, boolean][], extra: Partial<Product> = {}) => {
    const id = 'seed-p' + i;
    db.products.push({
      id, sku: 'SKU-' + String(1000 + i), barcode: '6' + String(900000000 + i * 137), name, category, kind: 'product', cost, price,
      minStock: 3, unit: 'قطعة', warrantyDays: 0, compat: compat.map(([k, v]) => ({ modelId: m(k), verified: v })), createdAt: 0, ...extra,
    });
    db.movements.push({ id: 'seed-mv' + i, productId: id, wh: WH0, qty, bucket: 'available', type: 'opening', cost, note: 'رصيد افتتاحي', ts: 0, op: 'seed' });
  };
  P(1, 'جراب سيليكون iPhone 13', 'جرابات', 4, 12, 15, [[0, true]]);
  P(2, 'واقي شاشة زجاجي iPhone 13', 'واقيات شاشة', 1.5, 6, 30, [[0, true]]);
  P(3, 'شاحن سريع 20W USB-C', 'شواحن', 7, 18, 12, [[0, true], [1, true], [2, true], [7, true]], { warrantyDays: 180 });
  P(4, 'كابل USB-C إلى Lightning 1م', 'كوابل', 3, 10, 25, [[0, true], [1, true]], { warrantyDays: 90 });
  P(5, 'سماعة سلكية Lightning', 'سماعات', 6, 16, 8, [[0, true], [1, false]]);
  P(6, 'جراب شفاف Galaxy A54', 'جرابات', 3, 9, 10, [[3, true]]);
  P(7, 'واقي شاشة Galaxy A54', 'واقيات شاشة', 1.2, 5, 22, [[3, true]]);
  P(8, 'شاحن Samsung 25W', 'شواحن', 8, 20, 9, [[3, true], [4, true]], { warrantyDays: 180 });
  P(9, 'شاشة أصلية iPhone 13', 'قطع غيار', 85, 150, 4, [[0, true]], { warrantyDays: 90 });
  P(10, 'بطارية iPhone 13', 'قطع غيار', 22, 55, 6, [[0, true]], { warrantyDays: 90 });
  P(11, 'شاشة Galaxy A54', 'قطع غيار', 60, 110, 3, [[3, true]], { warrantyDays: 90 });
  P(12, 'بطارية Redmi Note 12', 'قطع غيار', 12, 30, 2, [[5, true]], { warrantyDays: 60 });
  P(13, 'منفذ شحن Galaxy S23', 'قطع غيار', 9, 25, 5, [[4, true]], { warrantyDays: 60 });
  P(14, 'قرص SSD 512GB', 'حاسوب', 38, 70, 7, [[8, true], [9, true]], { warrantyDays: 365 });
  db.products.push({
    id: 'seed-s1', sku: 'SRV-001', name: 'أجرة فحص وتشخيص', category: 'خدمات', kind: 'service', cost: 0, price: 5, minStock: 0,
    unit: 'خدمة', compat: [], createdAt: 0,
  });
  db.products.push({
    id: 'seed-s2', sku: 'SRV-002', name: 'تركيب واقي شاشة', category: 'خدمات', kind: 'service', cost: 0, price: 2, minStock: 0,
    unit: 'خدمة', compat: [], createdAt: 0,
  });
  db.suppliers.push({ id: 'seed-sup1', name: 'مؤسسة النور لقطع الغيار', phone: '0500000001', opening: 0, createdAt: 0 });
  db.suppliers.push({ id: 'seed-sup2', name: 'شركة الأفق للإكسسوارات', phone: '0500000002', opening: 0, createdAt: 0 });
  return db;
}

export const isPhysical = (db: DB, productId: string) => {
  const p = db.products.find((x) => x.id === productId);
  return !p || p.kind !== 'service';
};

function mv(db: DB, op: Op, key: string, o: { productId: string; wh: string; qty: number; bucket?: Bucket; type: string; ref?: string; cost?: number; note?: string }) {
  if (!o.qty || !isPhysical(db, o.productId)) return;
  db.movements.push({
    id: op.id + ':' + key, ts: op.ts, op: op.id, bucket: o.bucket || 'available', cost: o.cost || 0,
    productId: o.productId, wh: o.wh, qty: o.qty, type: o.type, ref: o.ref, note: o.note,
  });
}

function onHand(db: DB, productId: string) {
  let t = 0;
  for (const m of db.movements) if (m.productId === productId && m.bucket === 'available') t += m.qty;
  return t;
}

function cash(db: DB, op: Op, key: string, e: Omit<import('./types').CashEntry, 'id' | 'ts' | 'userId'>) {
  if (!(e.amount > 0)) return;
  db.cash.push({ ...e, id: op.id + ':c' + key, ts: op.ts, userId: op.user });
}

function applySale(db: DB, op: Op, sale: Sale, warranties: Warranty[]) {
  if (db.sales.some((s) => s.id === sale.id)) return;
  db.sales.push({ ...sale, opId: op.id });
  sale.lines.forEach((l, i) => {
    if (!l.noStock) mv(db, op, 's' + i, { productId: l.productId, wh: sale.wh, qty: -l.qty, type: 'sale', ref: sale.id, cost: l.cost });
  });
  sale.payments.forEach((p, i) => {
    if (p.prepaid) return;
    cash(db, op, 'p' + i, {
      dir: 'in', method: p.method, amount: p.amount, category: sale.kind === 'repair' ? 'repair_payment' : 'sale',
      party: { type: 'customer', id: sale.customerId }, ref: sale.id,
    });
  });
  for (const w of warranties || []) if (!db.warranties.some((x) => x.id === w.id)) db.warranties.push(w);
}

const COLLS: Record<string, keyof DB> = {
  customers: 'customers', custDevices: 'custDevices', models: 'models', products: 'products', warehouses: 'warehouses',
  suppliers: 'suppliers', staff: 'staff',
};

export function applyOp(db: DB, op: Op): void {
  const p = op.p;
  switch (op.type) {
    case 'upsert': {
      const arr = db[COLLS[p.coll]] as any[];
      if (!arr) return;
      const i = arr.findIndex((x) => x.id === p.rec.id);
      if (i >= 0) arr[i] = { ...arr[i], ...p.rec };
      else arr.push(p.rec);
      return;
    }
    case 'customer.merge': {
      const { fromId, toId } = p;
      db.sales.forEach((s) => { if (s.customerId === fromId) s.customerId = toId; });
      db.repairs.forEach((r) => { if (r.customerId === fromId) r.customerId = toId; });
      db.custDevices.forEach((d) => { if (d.customerId === fromId) d.customerId = toId; });
      db.cash.forEach((c) => { if (c.party?.type === 'customer' && c.party.id === fromId) c.party.id = toId; });
      db.warranties.forEach((w) => { if (w.customerId === fromId) w.customerId = toId; });
      const c = db.customers.find((x) => x.id === fromId);
      if (c) { c.deleted = true; c.mergedInto = toId; }
      return;
    }
    case 'sale.final':
      return applySale(db, op, p.sale, p.warranties);
    case 'sale.return': {
      const r = p.ret;
      if (db.returns.some((x) => x.id === r.id)) return;
      db.returns.push({ ...r, opId: op.id });
      r.lines.forEach((l: any, i: number) =>
        mv(db, op, 'r' + i, { productId: l.productId, wh: r.wh, qty: l.qty, bucket: l.restock ? 'available' : 'quarantine', type: 'sale_return', ref: r.saleId, cost: costOf(db, l.productId) }),
      );
      if (r.refund) {
        const sale = db.sales.find((s) => s.id === r.saleId);
        cash(db, op, 'rf', { dir: 'out', method: r.refund.method, amount: r.refund.amount, category: 'sale_return', party: { type: 'customer', id: sale ? sale.customerId : null }, ref: r.saleId });
      }
      return;
    }
    case 'repair.create': {
      const r = p.repair;
      if (db.repairs.some((x) => x.id === r.id)) return;
      db.repairs.push({ ...r, opId: op.id });
      if (r.deposit > 0)
        cash(db, op, 'dep', { dir: 'in', method: p.method || 'cash', amount: r.deposit, category: 'repair_deposit', party: { type: 'customer', id: r.customerId }, ref: r.id });
      return;
    }
    case 'repair.status': {
      const r = db.repairs.find((x) => x.id === p.id);
      if (!r) return;
      r.status = p.status;
      r.history.push({ status: p.status, ts: op.ts, userId: op.user, note: p.note });
      return;
    }
    case 'repair.assign': {
      const r = db.repairs.find((x) => x.id === p.id);
      if (r) r.technicianId = p.technicianId;
      return;
    }
    case 'repair.estimate': {
      const r = db.repairs.find((x) => x.id === p.id);
      if (r && !r.estimates.some((e) => e.id === p.est.id)) r.estimates.push({ ...p.est, ts: op.ts, userId: op.user });
      return;
    }
    case 'repair.decide': {
      const r = db.repairs.find((x) => x.id === p.id);
      const e = r?.estimates.find((x) => x.id === p.estId);
      if (!r || !e) return;
      e.approval = { method: p.method, approved: p.approved, ts: op.ts, userId: op.user };
      r.status = p.approved ? 'approved' : 'rejected';
      r.history.push({ status: r.status, ts: op.ts, userId: op.user, note: 'طريقة الموافقة: ' + p.method });
      return;
    }
    case 'repair.part': {
      const r = db.repairs.find((x) => x.id === p.id);
      if (!r) return;
      mv(db, op, 'rp', { productId: p.productId, wh: r.wh, qty: -p.qty, type: p.qty > 0 ? 'repair_consume' : 'repair_return', ref: r.id, cost: p.cost });
      const ex = r.parts.find((x) => x.productId === p.productId);
      if (ex) { ex.qty += p.qty; if (ex.qty <= 0) r.parts = r.parts.filter((x) => x !== ex); }
      else if (p.qty > 0) r.parts.push({ productId: p.productId, name: p.name, qty: p.qty, price: p.price, cost: p.cost });
      return;
    }
    case 'repair.deliver': {
      const r = db.repairs.find((x) => x.id === p.id);
      if (!r || r.status === 'delivered') return;
      if (p.sale) applySale(db, op, p.sale, p.warranties);
      r.status = 'delivered';
      r.saleId = p.sale ? p.sale.id : undefined;
      r.deliveredTo = p.recipient;
      r.warrantyDays = p.warrantyDays;
      r.history.push({ status: 'delivered', ts: op.ts, userId: op.user, note: 'المستلم: ' + p.recipient });
      return;
    }
    case 'purchase.create': {
      const pu = p.pur;
      if (db.purchases.some((x) => x.id === pu.id)) return;
      pu.lines.forEach((l: any, i: number) => {
        if (!isPhysical(db, l.productId)) return;
        const prod = db.products.find((x) => x.id === l.productId);
        const oh = Math.max(0, onHand(db, l.productId));
        const unit = l.cost + (pu.shipping + pu.extra) / Math.max(1, pu.lines.reduce((a: number, b: any) => a + b.qty, 0));
        if (prod) prod.cost = oh + l.qty > 0 ? Math.round(((oh * prod.cost + l.qty * unit) / (oh + l.qty)) * 100) / 100 : unit;
        mv(db, op, 'u' + i, { productId: l.productId, wh: pu.wh, qty: l.qty, type: 'purchase', ref: pu.id, cost: unit });
      });
      db.purchases.push({ ...pu, opId: op.id });
      pu.payments.forEach((pm: any, i: number) =>
        cash(db, op, 'p' + i, { dir: 'out', method: pm.method, amount: pm.amount, category: 'purchase', party: { type: 'supplier', id: pu.supplierId }, ref: pu.id }),
      );
      return;
    }
    case 'purchase.return': {
      const r = p.ret;
      if (db.purchaseReturns.some((x) => x.id === r.id)) return;
      db.purchaseReturns.push(r);
      r.lines.forEach((l: any, i: number) => mv(db, op, 'r' + i, { productId: l.productId, wh: r.wh, qty: -l.qty, type: 'purchase_return', ref: r.purchaseId, cost: l.cost }));
      if (r.refund) cash(db, op, 'rf', { dir: 'in', method: r.refund.method, amount: r.refund.amount, category: 'purchase_return', party: { type: 'supplier', id: r.supplierId }, ref: r.purchaseId });
      return;
    }
    case 'cash.add': {
      const e = p.entry;
      if (db.cash.some((x) => x.id === e.id)) return;
      db.cash.push({ ...e, ts: op.ts, userId: op.user });
      return;
    }
    case 'damage.create': {
      const d = p.d;
      if (db.damages.some((x) => x.id === d.id)) return;
      const repairable = d.category === 'repairable';
      mv(db, op, 'o', { productId: d.productId, wh: d.wh, qty: -d.qty, type: 'damage_out', ref: d.id, cost: d.unitCost, note: d.reason });
      mv(db, op, 'i', { productId: d.productId, wh: d.wh, qty: d.qty, bucket: repairable ? 'repairable' : 'disposed', type: 'damage_in', ref: d.id, cost: d.unitCost });
      db.damages.push({ ...d, ts: op.ts, userId: op.user, status: repairable ? 'repairable' : 'written_off', lossCost: repairable ? 0 : d.total });
      return;
    }
    case 'damage.resolve': {
      const d = db.damages.find((x) => x.id === p.id);
      if (!d || d.status !== 'repairable') return;
      if (p.action === 'recover') {
        mv(db, op, 'a', { productId: d.productId, wh: d.wh, qty: -d.qty, bucket: 'repairable', type: 'recovery_out', ref: d.id, cost: d.unitCost });
        mv(db, op, 'b', { productId: d.productId, wh: d.wh, qty: d.qty, bucket: 'available', type: 'recovery_in', ref: d.id, cost: d.unitCost });
        d.status = 'recovered';
        if (p.recoveryCost > 0) {
          d.lossCost += p.recoveryCost;
          cash(db, op, 'rc', { dir: 'out', method: 'cash', amount: p.recoveryCost, category: 'recovery_cost', ref: d.id, note: d.name });
        }
      } else {
        mv(db, op, 'a', { productId: d.productId, wh: d.wh, qty: -d.qty, bucket: 'repairable', type: 'dispose_out', ref: d.id, cost: d.unitCost });
        mv(db, op, 'b', { productId: d.productId, wh: d.wh, qty: d.qty, bucket: 'disposed', type: 'dispose_in', ref: d.id, cost: d.unitCost });
        d.status = 'disposed';
        d.lossCost = d.total;
      }
      return;
    }
    case 'stock.adjust': {
      mv(db, op, 'a', { productId: p.productId, wh: p.wh, qty: p.delta, type: p.kind, ref: p.id, cost: costOf(db, p.productId), note: p.reason });
      return;
    }
    case 'stock.transfer': {
      mv(db, op, 'o', { productId: p.productId, wh: p.from, qty: -p.qty, type: 'transfer_out', ref: p.id, cost: costOf(db, p.productId) });
      mv(db, op, 'i', { productId: p.productId, wh: p.to, qty: p.qty, type: 'transfer_in', ref: p.id, cost: costOf(db, p.productId) });
      return;
    }
    case 'claim.create': {
      if (!db.claims.some((x) => x.id === p.claim.id)) db.claims.push({ ...p.claim, ts: op.ts, status: 'open' });
      return;
    }
    case 'claim.resolve': {
      const c = db.claims.find((x) => x.id === p.id);
      if (c) { c.status = p.status; c.resolution = p.resolution; c.resolvedAt = op.ts; }
      return;
    }
    case 'conflict.review': {
      if (!db.reviews.some((x) => x.id === p.id)) db.reviews.push({ id: p.id, productId: p.productId, deficit: p.deficit, note: p.note, ts: op.ts, userId: op.user });
      return;
    }
  }
}

export const costOf = (db: DB, productId: string) => db.products.find((x) => x.id === productId)?.cost || 0;

export function sortOps(ops: Op[]): Op[] {
  return [...ops].sort((a, b) => a.lc - b.lc || (a.dev < b.dev ? -1 : a.dev > b.dev ? 1 : 0) || a.seq - b.seq);
}

export function replay(ops: Op[], seedDemo: boolean): DB {
  const db = initialDB(seedDemo);
  for (const op of sortOps(ops)) applyOp(db, op);
  return db;
}

// ---------- derived data ----------
export interface StockInfo { available: number; repairable: number; quarantine: number; disposed: number; byWh: Record<string, number>; value: number }
export function computeStock(db: DB): Record<string, StockInfo> {
  const out: Record<string, StockInfo> = {};
  for (const m of db.movements) {
    const s = (out[m.productId] ||= { available: 0, repairable: 0, quarantine: 0, disposed: 0, byWh: {}, value: 0 });
    s[m.bucket] += m.qty;
    if (m.bucket === 'available') s.byWh[m.wh] = (s.byWh[m.wh] || 0) + m.qty;
  }
  for (const p of db.products) {
    const s = out[p.id];
    if (s) s.value = Math.max(0, s.available) * p.cost;
  }
  return out;
}

export function computeBalances(db: DB) {
  const cust: Record<string, number> = {};
  const sup: Record<string, number> = {};
  const add = (m: Record<string, number>, k: string | null | undefined, v: number) => { if (k) m[k] = (m[k] || 0) + v; };
  for (const s of db.sales) add(cust, s.customerId, s.total);
  for (const r of db.returns) { const s = db.sales.find((x) => x.id === r.saleId); add(cust, s?.customerId, -r.value); }
  for (const c of db.cash) {
    if (c.party?.type === 'customer') add(cust, c.party.id, c.dir === 'in' ? -c.amount : c.amount);
    if (c.party?.type === 'supplier') add(sup, c.party.id, c.dir === 'out' ? -c.amount : c.amount);
  }
  for (const s of db.suppliers) add(sup, s.id, s.opening);
  for (const p of db.purchases) add(sup, p.supplierId, p.total);
  for (const r of db.purchaseReturns) add(sup, r.supplierId, -r.value);
  let cashBal = 0;
  for (const c of db.cash) cashBal += c.dir === 'in' ? c.amount : -c.amount;
  return { cust, sup, cash: cashBal };
}

export interface Conflict { productId: string; deficit: number; saleIds: string[]; reviewed: boolean }
export function computeConflicts(db: DB, stock: Record<string, StockInfo>): Conflict[] {
  const out: Conflict[] = [];
  for (const p of db.products) {
    const st = stock[p.id];
    if (!st || p.kind === 'service') continue;
    const neg = st.available < 0 || Object.values(st.byWh).some((v) => v < 0);
    if (!neg) continue;
    const deficit = st.available < 0 ? -st.available : -Math.min(...Object.values(st.byWh));
    let remain = deficit;
    const ids: string[] = [];
    for (const s of [...db.sales].reverse()) {
      if (remain <= 0) break;
      const l = s.lines.filter((x) => x.productId === p.id && !x.noStock);
      if (l.length) { ids.push(s.id); remain -= l.reduce((a, b) => a + b.qty, 0); }
    }
    const reviewed = db.reviews.some((r) => r.productId === p.id && r.deficit >= deficit);
    out.push({ productId: p.id, deficit, saleIds: ids, reviewed });
  }
  return out;
}

export function defaultSettings(): Settings {
  return {
    deviceId: uid('dev-'), deviceName: 'الهاتف الرئيسي', code: Math.random().toString(36).slice(2, 4).toUpperCase(),
    businessName: 'مركز الصيانة', currency: 'ر.س', taxRate: 0, userId: 'staff-owner', opSeq: 0, lc: 0,
    counters: {}, seedDemo: true, created: Date.now(), defaultWh: WH0, phone: '', address: '',
  };
}
