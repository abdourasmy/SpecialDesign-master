import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Conflict, Perm, ROLE_PERMS, StockInfo, applyOp, computeBalances, computeConflicts, computeStock, defaultSettings, replay } from './engine';
import { DB, Doc, Op, Peer, Settings, Staff } from './types';
import { uid } from './format';

const KEY = 'rcm.doc.v1';
const HELD = 'rcm.held.v1';

export interface CartLine { productId: string; qty: number; price: number; disc: number }
export interface Cart { lines: CartLine[]; customerId: string | null; discount: number; note: string }
export interface HeldCart extends Cart { id: string; ts: number }
const emptyCart = (): Cart => ({ lines: [], customerId: null, discount: 0, note: '' });

export type SyncState = 'local' | 'pending' | 'synced';

interface Ctx {
  ready: boolean;
  db: DB;
  doc: Doc;
  settings: Settings;
  stock: Record<string, StockInfo>;
  bal: { cust: Record<string, number>; sup: Record<string, number>; cash: number };
  conflicts: Conflict[];
  user: Staff;
  can: (p: Perm) => boolean;
  commit: (type: string, p: any, summary: string) => Op;
  upsert: (coll: string, rec: any, summary: string) => void;
  newId: (prefix?: string) => string;
  nextNumber: (kind: string) => string;
  updateSettings: (patch: Partial<Settings>) => void;
  opSync: (opId?: string) => SyncState | 'needs_review';
  exportPackage: () => string;
  importPackage: (text: string) => { ok: boolean; message: string };
  backup: () => string;
  restore: (text: string) => { ok: boolean; message: string };
  resetAll: (seedDemo: boolean) => void;
  vector: Record<string, number>;
  cart: Cart;
  setCart: (c: Cart | ((c: Cart) => Cart)) => void;
  held: HeldCart[];
  holdCart: () => void;
  resumeHeld: (id: string) => void;
  dropHeld: (id: string) => void;
}

const StoreCtx = createContext<Ctx>(null as any);
export const useStore = () => useContext(StoreCtx);

function freshDoc(seedDemo = true): Doc {
  const s = defaultSettings();
  s.seedDemo = seedDemo;
  return { settings: s, ops: [], peers: {} };
}

function vectorOf(ops: Op[]) {
  const v: Record<string, number> = {};
  for (const o of ops) v[o.dev] = Math.max(v[o.dev] || 0, o.seq);
  return v;
}

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [ready, setReady] = useState(false);
  const docRef = useRef<Doc>(freshDoc());
  const dbRef = useRef<DB>(replay([], true));
  const [rev, setRev] = useState(0);
  const [cart, setCartState] = useState<Cart>(emptyCart());
  const [held, setHeld] = useState<HeldCart[]>([]);

  useEffect(() => {
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(KEY);
        if (raw) {
          const d: Doc = JSON.parse(raw);
          docRef.current = d;
        } else {
          docRef.current = freshDoc();
          await AsyncStorage.setItem(KEY, JSON.stringify(docRef.current));
        }
        dbRef.current = replay(docRef.current.ops, docRef.current.settings.seedDemo);
        const h = await AsyncStorage.getItem(HELD);
        if (h) setHeld(JSON.parse(h));
      } catch (e) {
        docRef.current = freshDoc();
        dbRef.current = replay([], true);
      }
      setReady(true);
      setRev((r) => r + 1);
    })();
  }, []);

  const persist = useCallback(() => {
    AsyncStorage.setItem(KEY, JSON.stringify(docRef.current)).catch(() => {});
  }, []);

  const bump = useCallback(() => setRev((r) => r + 1), []);

  const commit = useCallback((type: string, p: any, summary: string): Op => {
    const doc = docRef.current;
    const s = doc.settings;
    s.opSeq += 1;
    s.lc += 1;
    const op: Op = { id: `${s.deviceId}:${s.opSeq}`, dev: s.deviceId, seq: s.opSeq, lc: s.lc, ts: Date.now(), user: s.userId, type, p, s: summary };
    doc.ops.push(op);
    applyOp(dbRef.current, op);
    persist();
    bump();
    return op;
  }, [persist, bump]);

  const upsert = useCallback((coll: string, rec: any, summary: string) => commit('upsert', { coll, rec }, summary), [commit]);

  const newId = useCallback((prefix = '') => prefix + docRef.current.settings.code + '-' + uid(), []);

  const nextNumber = useCallback((kind: string) => {
    const s = docRef.current.settings;
    s.counters[kind] = (s.counters[kind] || 0) + 1;
    persist();
    const pre: Record<string, string> = { sale: 'INV', repair: 'REP', purchase: 'PUR', warranty: 'WAR', customer: 'C' };
    return `${pre[kind] || kind.toUpperCase()}-${s.code}-${String(s.counters[kind]).padStart(5, '0')}`;
  }, [persist]);

  const updateSettings = useCallback((patch: Partial<Settings>) => {
    Object.assign(docRef.current.settings, patch);
    persist();
    bump();
  }, [persist, bump]);

  const db = dbRef.current;
  const doc = docRef.current;
  const stock = useMemo(() => computeStock(dbRef.current), [rev]);
  const bal = useMemo(() => computeBalances(dbRef.current), [rev]);
  const conflicts = useMemo(() => computeConflicts(dbRef.current, stock), [rev, stock]);
  const vector = useMemo(() => vectorOf(docRef.current.ops), [rev]);

  const user = useMemo<Staff>(() => {
    const u = dbRef.current.staff.find((x) => x.id === docRef.current.settings.userId && x.active);
    return u || dbRef.current.staff[0];
  }, [rev]);

  const can = useCallback((perm: Perm) => ROLE_PERMS[user.role].includes(perm), [user]);

  const opSync = useCallback((opId?: string): SyncState | 'needs_review' => {
    if (!opId) return 'local';
    const d = docRef.current;
    const dev = opId.slice(0, opId.lastIndexOf(':'));
    const seq = Number(opId.slice(opId.lastIndexOf(':') + 1));
    if (dev !== d.settings.deviceId) return 'synced';
    const peers = Object.values(d.peers);
    if (!peers.length) return 'local';
    return peers.every((p) => (p.vector[dev] || 0) >= seq) ? 'synced' : 'pending';
  }, []);

  const exportPackage = useCallback(() => {
    const d = docRef.current;
    const pkg = {
      format: 'rcm-sync-1', ts: Date.now(),
      device: { id: d.settings.deviceId, name: d.settings.deviceName, code: d.settings.code },
      business: d.settings.businessName, seedDemo: d.settings.seedDemo,
      vector: vectorOf(d.ops), ops: d.ops,
    };
    return JSON.stringify(pkg);
  }, []);

  const importPackage = useCallback((text: string) => {
    try {
      const pkg = JSON.parse(text.trim());
      if (pkg.format !== 'rcm-sync-1' || !Array.isArray(pkg.ops)) return { ok: false, message: 'ملف المزامنة غير صالح' };
      const d = docRef.current;
      if (pkg.device.id === d.settings.deviceId) return { ok: false, message: 'هذه حزمة صادرة من هذا الجهاز نفسه' };
      if (!!pkg.seedDemo !== !!d.settings.seedDemo)
        return { ok: false, message: 'الجهاز الآخر بُدئ ببيانات مختلفة (تجريبية/فارغة). أعد تهيئة أحد الجهازين بنفس الخيار قبل المزامنة' };
      const known = new Set(d.ops.map((o) => o.id));
      let added = 0, dupes = 0;
      let maxLc = d.settings.lc;
      for (const o of pkg.ops as Op[]) {
        if (!o || typeof o.id !== 'string' || typeof o.lc !== 'number' || !o.dev || typeof o.seq !== 'number') continue;
        if (known.has(o.id)) { dupes++; continue; }
        known.add(o.id);
        d.ops.push(o);
        added++;
        maxLc = Math.max(maxLc, o.lc);
      }
      d.settings.lc = maxLc;
      const peer: Peer = {
        id: pkg.device.id, name: pkg.device.name, code: pkg.device.code, vector: pkg.vector || {}, lastSync: Date.now(),
        opsReceived: (d.peers[pkg.device.id]?.opsReceived || 0) + added,
      };
      d.peers[pkg.device.id] = peer;
      dbRef.current = replay(d.ops, d.settings.seedDemo);
      persist();
      bump();
      return { ok: true, message: `تم استلام ${added} عملية جديدة، وتجاهل ${dupes} عملية مكررة` };
    } catch (e) {
      return { ok: false, message: 'تعذّر قراءة النص: تأكد من نسخ الحزمة كاملة' };
    }
  }, [persist, bump]);

  const backup = useCallback(() => JSON.stringify({ format: 'rcm-backup-1', ts: Date.now(), doc: docRef.current }), []);

  const restore = useCallback((text: string) => {
    try {
      const b = JSON.parse(text.trim());
      if (b.format !== 'rcm-backup-1' || !b.doc?.settings || !Array.isArray(b.doc.ops)) return { ok: false, message: 'ملف النسخة الاحتياطية غير صالح' };
      docRef.current = b.doc;
      dbRef.current = replay(b.doc.ops, b.doc.settings.seedDemo);
      persist();
      bump();
      return { ok: true, message: `تمت الاستعادة: ${b.doc.ops.length} عملية` };
    } catch (e) {
      return { ok: false, message: 'تعذّر قراءة النسخة الاحتياطية' };
    }
  }, [persist, bump]);

  const resetAll = useCallback((seedDemo: boolean) => {
    docRef.current = freshDoc(seedDemo);
    dbRef.current = replay([], seedDemo);
    setCartState(emptyCart());
    setHeld([]);
    AsyncStorage.removeItem(HELD).catch(() => {});
    persist();
    bump();
  }, [persist, bump]);

  const setCart = useCallback((c: Cart | ((c: Cart) => Cart)) => setCartState((prev) => (typeof c === 'function' ? c(prev) : c)), []);

  const saveHeld = (h: HeldCart[]) => { setHeld(h); AsyncStorage.setItem(HELD, JSON.stringify(h)).catch(() => {}); };
  const holdCart = useCallback(() => {
    if (!cart.lines.length) return;
    saveHeld([{ ...cart, id: uid('h'), ts: Date.now() }, ...held]);
    setCartState(emptyCart());
  }, [held, cart]);
  const resumeHeld = useCallback((id: string) => {
    const h = held.find((x) => x.id === id);
    if (!h) return;
    const { id: _i, ts: _t, ...c } = h;
    setCartState(c);
    saveHeld(held.filter((x) => x.id !== id));
  }, [held]);
  const dropHeld = useCallback((id: string) => saveHeld(held.filter((x) => x.id !== id)), [held]);

  const value: Ctx = {
    ready, db, doc, settings: doc.settings, stock, bal, conflicts, user, can, commit, upsert, newId, nextNumber, updateSettings,
    opSync, exportPackage, importPackage, backup, restore, resetAll, vector, cart, setCart, held, holdCart, resumeHeld, dropHeld,
  };
  return <StoreCtx.Provider value={value}>{children}</StoreCtx.Provider>;
}

export const saleSyncState = (ctx: Ctx, saleId: string, opId?: string): SyncState | 'needs_review' => {
  const c = ctx.conflicts.find((x) => !x.reviewed && x.saleIds.includes(saleId));
  if (c) return 'needs_review';
  return ctx.opSync(opId);
};
