export type Bucket = 'available' | 'repairable' | 'quarantine' | 'disposed';

export interface Customer {
  id: string; code: string; name: string; phone: string; phone2?: string; email?: string;
  address?: string; notes?: string; category?: string; creditLimit?: number; deleted?: boolean;
  mergedInto?: string; createdAt: number;
}
export interface Model { id: string; brand: string; name: string; category: string; modelNumber?: string; deleted?: boolean }
export interface CustDevice {
  id: string; customerId: string; modelId?: string; manual?: string; serial?: string; imei?: string;
  color?: string; storage?: string; condition?: string; notes?: string; createdAt: number;
}
export interface Compat { modelId: string; verified: boolean }
export interface Product {
  id: string; sku: string; barcode?: string; name: string; category: string; kind: 'product' | 'service';
  cost: number; price: number; wholesale?: number; minStock: number; reorder?: number; unit: string;
  warrantyDays?: number; serialTracked?: boolean; compat: Compat[]; deleted?: boolean; createdAt: number;
}
export interface Warehouse { id: string; name: string; deleted?: boolean }
export interface Supplier {
  id: string; name: string; phone?: string; email?: string; address?: string; notes?: string;
  opening: number; deleted?: boolean; createdAt: number;
}
export interface Staff { id: string; name: string; role: RoleKey; phone?: string; active: boolean }
export type RoleKey = 'owner' | 'manager' | 'receptionist' | 'technician' | 'cashier' | 'storekeeper' | 'accountant';

export interface Movement {
  id: string; productId: string; wh: string; qty: number; bucket: Bucket; type: string;
  ref?: string; cost: number; note?: string; ts: number; op: string;
}
export interface Line {
  productId: string; name: string; qty: number; price: number; cost: number; disc: number; noStock?: boolean;
  warrantyDays?: number; serial?: string;
}
export interface Pay { method: string; amount: number; prepaid?: boolean }
export interface Sale {
  id: string; number: string; kind: 'sale' | 'repair'; customerId: string | null; wh: string;
  lines: Line[]; subtotal: number; discount: number; taxRate: number; tax: number; total: number;
  payments: Pay[]; paid: number; ts: number; userId: string; oversold?: boolean; repairId?: string;
  opId?: string; note?: string;
}
export interface SaleReturn {
  id: string; saleId: string; lines: { productId: string; qty: number; price: number; restock: boolean }[];
  value: number; refund: Pay | null; reason?: string; ts: number; wh: string; opId?: string;
}
export interface Purchase {
  id: string; number: string; supplierId: string; wh: string; lines: { productId: string; name: string; qty: number; cost: number }[];
  discount: number; tax: number; shipping: number; extra: number; total: number; payments: Pay[]; paid: number;
  ts: number; note?: string; opId?: string; userId: string;
}
export interface PurchaseReturn {
  id: string; purchaseId: string; supplierId: string; lines: { productId: string; qty: number; cost: number }[];
  value: number; refund: Pay | null; ts: number; wh: string; reason?: string;
}
export interface Estimate {
  id: string; diagnosis: string; recommended: string; parts: { productId: string; name: string; qty: number; price: number }[];
  labor: number; total: number; days: number; ts: number; userId: string;
  approval?: { method: string; approved: boolean; ts: number; userId: string };
}
export interface Repair {
  id: string; number: string; customerId: string; deviceId: string; problem: string;
  check: { screen: string; body: string; buttons: string; water: string; accessories: string; notes: string };
  photos?: string[]; received: number; expected: number; deposit: number; disclaimer: boolean;
  technicianId?: string; status: string; history: { status: string; ts: number; userId: string; note?: string }[];
  estimates: Estimate[]; parts: { productId: string; name: string; qty: number; price: number; cost: number }[];
  saleId?: string; deliveredTo?: string; warrantyDays?: number; opId?: string; userId: string; wh: string;
}
export interface CashEntry {
  id: string; dir: 'in' | 'out'; method: string; amount: number; category: string;
  party?: { type: 'customer' | 'supplier'; id: string | null }; ref?: string; note?: string; ts: number; userId: string;
}
export interface Damage {
  id: string; productId: string; name: string; qty: number; wh: string; category: string; reason: string;
  unitCost: number; total: number; status: 'repairable' | 'written_off' | 'recovered' | 'disposed';
  lossCost: number; responsible: string; note?: string; ts: number; userId: string; approvedBy?: string;
}
export interface Warranty {
  id: string; number: string; sourceType: 'sale' | 'repair'; sourceId: string; sourceNumber: string;
  customerId: string | null; item: string; serial?: string; start: number; expiry: number; days: number;
  covers: string; conditions: string;
}
export interface Claim { id: string; warrantyId: string; issue: string; status: 'open' | 'accepted' | 'rejected'; resolution?: string; ts: number; resolvedAt?: number }
export interface Review { id: string; productId: string; deficit: number; note: string; ts: number; userId: string }

export interface DB {
  customers: Customer[]; custDevices: CustDevice[]; models: Model[]; products: Product[]; warehouses: Warehouse[];
  suppliers: Supplier[]; staff: Staff[]; sales: Sale[]; returns: SaleReturn[]; purchases: Purchase[];
  purchaseReturns: PurchaseReturn[]; repairs: Repair[]; movements: Movement[]; cash: CashEntry[];
  damages: Damage[]; warranties: Warranty[]; claims: Claim[]; reviews: Review[];
}

export interface Op {
  id: string; dev: string; seq: number; lc: number; ts: number; user: string; type: string; p: any; s: string;
}

export interface Settings {
  deviceId: string; deviceName: string; code: string; businessName: string; currency: string; taxRate: number;
  userId: string; opSeq: number; lc: number; counters: Record<string, number>; seedDemo: boolean; created: number;
  defaultWh: string; phone: string; address: string;
}
export interface Peer { id: string; name: string; code: string; vector: Record<string, number>; lastSync: number; opsReceived: number }
export interface Doc { settings: Settings; ops: Op[]; peers: Record<string, Peer> }
