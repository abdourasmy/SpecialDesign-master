import { Platform, Share } from 'react-native';
import * as Print from 'expo-print';
import { DB, Repair, Sale, Settings } from './types';
import { fmtDateTime, money } from './format';
import { PAY_METHODS } from './engine';

const esc = (s: string) => (s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;');

const CSS = `body{font-family:Arial,Tahoma,sans-serif;direction:rtl;padding:18px;color:#111;max-width:420px;margin:auto}
h1{font-size:20px;margin:0}h2{font-size:15px;margin:14px 0 6px}small{color:#555}table{width:100%;border-collapse:collapse;font-size:13px}
th,td{border-bottom:1px solid #ddd;padding:6px 4px;text-align:right}.tot td{font-weight:bold;border-top:2px solid #111}.c{text-align:center}hr{border:0;border-top:1px dashed #999;margin:10px 0}`;

export function saleHtml(db: DB, s: Sale, st: Settings): string {
  const cust = db.customers.find((c) => c.id === s.customerId);
  const cur = st.currency;
  return `<html><head><meta charset="utf-8"><style>${CSS}</style></head><body>
<div class="c"><h1>${esc(st.businessName)}</h1><small>${esc(st.phone || '')} ${esc(st.address || '')}</small></div><hr/>
<div>فاتورة رقم: <b>${s.number}</b></div><div><small>${fmtDateTime(s.ts)}</small></div>
<div>العميل: ${esc(cust ? cust.name : 'عميل نقدي')}</div>
<h2>الأصناف</h2><table><tr><th>الصنف</th><th>الكمية</th><th>السعر</th><th>الإجمالي</th></tr>
${s.lines.map((l) => `<tr><td>${esc(l.name)}</td><td>${l.qty}</td><td>${money(l.price)}</td><td>${money(l.qty * l.price - l.disc)}</td></tr>`).join('')}
</table>
<table style="margin-top:8px">
<tr><td>المجموع الفرعي</td><td>${money(s.subtotal, cur)}</td></tr>
${s.discount ? `<tr><td>خصم</td><td>${money(s.discount, cur)}</td></tr>` : ''}
${s.tax ? `<tr><td>ضريبة (${s.taxRate}%)</td><td>${money(s.tax, cur)}</td></tr>` : ''}
<tr class="tot"><td>الإجمالي</td><td>${money(s.total, cur)}</td></tr>
${s.payments.map((p) => `<tr><td>دفعة (${PAY_METHODS[p.method] || p.method})</td><td>${money(p.amount, cur)}</td></tr>`).join('')}
<tr><td>المتبقي</td><td>${money(s.total - s.paid, cur)}</td></tr></table>
<hr/><div class="c"><small>شكراً لتعاملكم معنا</small></div></body></html>`;
}

export function saleText(db: DB, s: Sale, st: Settings): string {
  const cust = db.customers.find((c) => c.id === s.customerId);
  return [
    st.businessName, `فاتورة ${s.number}`, fmtDateTime(s.ts), `العميل: ${cust ? cust.name : 'عميل نقدي'}`, '------------',
    ...s.lines.map((l) => `${l.name} ×${l.qty} = ${money(l.qty * l.price - l.disc)}`), '------------',
    `الإجمالي: ${money(s.total, st.currency)}`, `المدفوع: ${money(s.paid, st.currency)}`, `المتبقي: ${money(s.total - s.paid, st.currency)}`,
  ].join('\n');
}

export function repairHtml(db: DB, r: Repair, st: Settings): string {
  const cust = db.customers.find((c) => c.id === r.customerId);
  const dev = db.custDevices.find((d) => d.id === r.deviceId);
  const model = db.models.find((m) => m.id === dev?.modelId);
  const dname = model ? `${model.brand} ${model.name}` : dev?.manual || 'جهاز';
  return `<html><head><meta charset="utf-8"><style>${CSS}</style></head><body>
<div class="c"><h1>${esc(st.businessName)}</h1><small>إيصال استلام جهاز للصيانة</small></div><hr/>
<div>رقم الصيانة: <b>${r.number}</b></div><div><small>${fmtDateTime(r.received)}</small></div>
<div>العميل: ${esc(cust?.name || '')} — ${esc(cust?.phone || '')}</div>
<div>الجهاز: ${esc(dname)} ${dev?.imei ? '— IMEI ' + esc(dev.imei) : ''}</div>
<div>العطل المبلغ عنه: ${esc(r.problem)}</div>
<div>الملحقات المستلمة: ${esc(r.check.accessories || 'لا يوجد')}</div>
<div>حالة الجهاز: شاشة (${esc(r.check.screen)})، هيكل (${esc(r.check.body)})، أزرار (${esc(r.check.buttons)})، ماء (${esc(r.check.water)})</div>
<div>التسليم المتوقع: ${fmtDateTime(r.expected)}</div><div>العربون: ${money(r.deposit, st.currency)}</div><hr/>
<small>يقر العميل بموافقته على أن المركز غير مسؤول عن فقدان البيانات أثناء الصيانة، ويجب إبراز هذا الإيصال عند التسليم.</small>
</body></html>`;
}

export async function printHtml(html: string) {
  if (Platform.OS === 'web') {
    const w = window.open('', '_blank');
    if (w) {
      w.document.write(html);
      w.document.close();
      w.focus();
      setTimeout(() => w.print(), 300);
      return;
    }
  }
  await Print.printAsync({ html });
}

export async function shareText(text: string, title = 'مشاركة') {
  if (Platform.OS === 'web') {
    const nav: any = typeof navigator !== 'undefined' ? navigator : null;
    if (nav?.share) {
      try { await nav.share({ title, text }); return true; } catch (e) { return false; }
    }
    if (nav?.clipboard) { await nav.clipboard.writeText(text); return 'copied'; }
    return false;
  }
  await Share.share({ message: text, title });
  return true;
}
