export const money = (n: number, cur = '') => {
  const v = Math.round((n || 0) * 100) / 100;
  const s = v.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
  return cur ? `${s} ${cur}` : s;
};

const pad = (n: number) => String(n).padStart(2, '0');

export const fmtDate = (ts: number) => {
  const d = new Date(ts);
  return `${d.getFullYear()}/${pad(d.getMonth() + 1)}/${pad(d.getDate())}`;
};
export const fmtTime = (ts: number) => {
  const d = new Date(ts);
  return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
};
export const fmtDateTime = (ts: number) => `${fmtDate(ts)}  ${fmtTime(ts)}`;

export const startOfDay = (ts: number = Date.now()) => {
  const d = new Date(ts);
  d.setHours(0, 0, 0, 0);
  return d.getTime();
};
export const DAY = 86400000;

export const uid = (prefix = '') =>
  prefix + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

export const num = (s: string | number | undefined | null): number => {
  if (s === undefined || s === null) return 0;
  const t = String(s)
    .replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)))
    .replace(/٫/g, '.')
    .replace(/,/g, '.');
  const v = parseFloat(t);
  return isNaN(v) ? 0 : v;
};

export const normalizeDigits = (s: string) =>
  (s || '').replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)));
