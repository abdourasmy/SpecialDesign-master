import React from 'react';
import { ScrollView, View, Pressable } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useTheme, R } from '../lib/theme';
import { useStore } from '../lib/store';
import { Badge, Card, SectionTitle, Stat, T, row, Empty, IconName } from '../components/ui';
import { DAY, fmtDateTime, money, startOfDay } from '../lib/format';
import { CLOSED_STATUSES, REPAIR_STATUS } from '../lib/engine';

export default function DashboardScreen({ navigation, goTab }: any) {
  const th = useTheme();
  const { db, settings, stock, bal, conflicts, doc, user, can } = useStore();
  const cur = settings.currency;
  const today = startOfDay();
  const todaySales = db.sales.filter((s) => s.ts >= today);
  const salesTotal = todaySales.reduce((a, s) => a + s.total, 0);
  const retToday = db.returns.filter((r) => r.ts >= today).reduce((a, r) => a + r.value, 0);
  const profit = todaySales.reduce((a, s) => a + s.lines.reduce((x, l) => x + (l.price * l.qty - l.disc - l.cost * l.qty), 0) - s.discount, 0);
  const receivables = Object.values(bal.cust).filter((v) => v > 0).reduce((a, b) => a + b, 0);
  const open = db.repairs.filter((r) => !CLOSED_STATUSES.includes(r.status));
  const ready = db.repairs.filter((r) => r.status === 'ready').length;
  const late = open.filter((r) => r.expected < Date.now()).length;
  const low = db.products.filter((p) => p.kind === 'product' && !p.deleted && (stock[p.id]?.available || 0) <= p.minStock);
  const days = Array.from({ length: 7 }, (_, i) => {
    const st = today - (6 - i) * DAY;
    const v = db.sales.filter((s) => s.ts >= st && s.ts < st + DAY).reduce((a, s) => a + s.total, 0);
    return { st, v };
  });
  const max = Math.max(1, ...days.map((d) => d.v));
  const dn = ['أحد', 'اثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة', 'سبت'];
  const unreviewed = conflicts.filter((c) => !c.reviewed);
  const peers = Object.keys(doc.peers).length;
  const recent = [...doc.ops].slice(-6).reverse();

  const qa: { label: string; icon: IconName; onPress: () => void; perm: any }[] = [
    { label: 'بيع جديد', icon: 'cart', onPress: () => goTab('pos'), perm: 'sales' },
    { label: 'استلام جهاز', icon: 'phone-portrait', onPress: () => navigation.navigate('NewRepair'), perm: 'repairs' },
    { label: 'شراء', icon: 'download', onPress: () => navigation.navigate('NewPurchase'), perm: 'purchases' },
    { label: 'مصروف', icon: 'wallet', onPress: () => navigation.navigate('Cash'), perm: 'finance' },
  ];

  return (
    <SafeAreaView style={{ flex: 1 }} edges={['top']}>
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 30 }} showsVerticalScrollIndicator={false}>
        <View style={{ backgroundColor: th.hero, borderRadius: R.xl, padding: 18, gap: 14 }}>
          <View style={[row, { justifyContent: 'space-between' }]}>
            <View style={{ flex: 1 }}>
              <T v="small" color="#8FB3C4">مرحباً، {user.name}</T>
              <T v="h1" color="#fff" numberOfLines={1}>{settings.businessName}</T>
            </View>
            <Pressable onPress={() => navigation.navigate('Sync')} style={[row, { gap: 6, backgroundColor: 'rgba(255,255,255,0.12)', paddingHorizontal: 10, paddingVertical: 7, borderRadius: 20 }]}>
              <Ionicons name={peers ? 'sync' : 'phone-portrait'} size={14} color="#7DD3E8" />
              <T v="small" color="#D5EEF5">{peers ? `${peers + 1} أجهزة` : 'جهاز مستقل'}</T>
            </Pressable>
          </View>
          <View>
            <T v="small" color="#8FB3C4">مبيعات اليوم</T>
            <T v="h1" color="#fff" style={{ fontSize: 32 }}>{money(salesTotal - retToday, cur)}</T>
            <T v="small" color="#8FB3C4">{todaySales.length} فاتورة · ربح تقديري {money(profit, cur)}</T>
          </View>
          <View style={[row, { gap: 10 }]}>
            {qa.filter((q) => can(q.perm)).map((q) => (
              <Pressable key={q.label} onPress={q.onPress} style={{ flex: 1, alignItems: 'center', gap: 6, backgroundColor: 'rgba(255,255,255,0.1)', borderRadius: 14, paddingVertical: 12 }}>
                <Ionicons name={q.icon} size={22} color={th.accent} />
                <T v="small" color="#E6F3F8" style={{ textAlign: 'center' }}>{q.label}</T>
              </Pressable>
            ))}
          </View>
        </View>

        {unreviewed.length ? (
          <Card onPress={() => navigation.navigate('Sync')} style={{ marginTop: 14, backgroundColor: th.dangerSoft, borderColor: th.danger }}>
            <View style={[row, { gap: 10 }]}>
              <Ionicons name="warning" size={26} color={th.danger} />
              <View style={{ flex: 1 }}>
                <T v="bold" color={th.danger}>تعارض مخزون يحتاج مراجعة</T>
                <T v="small" color={th.danger}>{unreviewed.length} منتج بكمية سالبة بعد المزامنة — لم يُحذف أي بيع</T>
              </View>
              <Ionicons name="chevron-back" size={18} color={th.danger} />
            </View>
          </Card>
        ) : null}

        <View style={[row, { flexWrap: 'wrap', gap: 10, marginTop: 14 }]}>
          <Stat label="رصيد الصندوق" value={money(bal.cash, cur)} icon="cash" tone="success" />
          <Stat label="ذمم العملاء" value={money(receivables, cur)} icon="people" tone="warn" />
          <Stat label="إصلاحات مفتوحة" value={String(open.length)} icon="construct" tone="primary" sub={`${ready} جاهز · ${late} متأخر`} />
          <Stat label="نواقص المخزون" value={String(low.length)} icon="alert-circle" tone={low.length ? 'danger' : 'success'} sub="تحت الحد الأدنى" />
        </View>

        <SectionTitle title="المبيعات آخر 7 أيام" />
        <Card>
          <View style={[row, { height: 120, alignItems: 'flex-end', gap: 8 }]}>
            {days.map((d, i) => (
              <View key={i} style={{ flex: 1, alignItems: 'center', justifyContent: 'flex-end', height: '100%', gap: 4 }}>
                <T v="small" style={{ fontSize: 9 }}>{d.v ? money(d.v) : ''}</T>
                <View style={{ width: '70%', height: Math.max(4, (d.v / max) * 80), borderRadius: 6, backgroundColor: i === 6 ? th.accent : th.primary, opacity: d.v ? 1 : 0.25 }} />
                <T v="small" style={{ textAlign: 'center' }}>{dn[new Date(d.st).getDay()]}</T>
              </View>
            ))}
          </View>
        </Card>

        <SectionTitle title="مسار الصيانة" right={<T v="sub" color={th.primary} onPress={() => goTab('repairs')}>عرض الكل</T>} />
        <Card>
          {open.length === 0 ? (
            <T v="sub">لا توجد أجهزة قيد الصيانة حالياً</T>
          ) : (
            Object.keys(REPAIR_STATUS).filter((k) => !CLOSED_STATUSES.includes(k)).map((k) => {
              const n = open.filter((r) => r.status === k).length;
              if (!n) return null;
              return (
                <View key={k} style={[row, { justifyContent: 'space-between', paddingVertical: 6 }]}>
                  <Badge text={REPAIR_STATUS[k].label} tone={REPAIR_STATUS[k].tone} icon={REPAIR_STATUS[k].icon as any} />
                  <T v="bold">{n}</T>
                </View>
              );
            })
          )}
        </Card>

        {low.length ? (
          <>
            <SectionTitle title="تنبيهات المخزون" />
            <Card>
              {low.slice(0, 5).map((p) => (
                <Pressable key={p.id} onPress={() => navigation.navigate('ProductDetail', { id: p.id })} style={[row, { justifyContent: 'space-between', paddingVertical: 7 }]}>
                  <T style={{ flex: 1 }} numberOfLines={1}>{p.name}</T>
                  <Badge text={`${stock[p.id]?.available || 0} ${p.unit}`} tone={(stock[p.id]?.available || 0) <= 0 ? 'danger' : 'warn'} />
                </Pressable>
              ))}
            </Card>
          </>
        ) : null}

        <SectionTitle title="آخر العمليات" right={<T v="sub" color={th.primary} onPress={() => navigation.navigate('Audit')}>سجل التدقيق</T>} />
        <Card>
          {recent.length === 0 ? <Empty icon="time-outline" title="لا توجد عمليات بعد" sub="ابدأ ببيع أو استلام جهاز" /> : recent.map((o) => (
            <View key={o.id} style={[row, { gap: 10, paddingVertical: 7 }]}>
              <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: th.primary }} />
              <View style={{ flex: 1 }}>
                <T numberOfLines={1}>{o.s}</T>
                <T v="small">{fmtDateTime(o.ts)}</T>
              </View>
            </View>
          ))}
        </Card>
      </ScrollView>
    </SafeAreaView>
  );
}
