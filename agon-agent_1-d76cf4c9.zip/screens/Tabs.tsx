import React, { useState } from 'react';
import { Pressable, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useTheme } from '../lib/theme';
import { useStore } from '../lib/store';
import { CLOSED_STATUSES } from '../lib/engine';
import { row } from '../components/ui';
import DashboardScreen from './Dashboard';
import PosScreen from './Pos';
import { RepairsScreen } from './Repairs';
import { InventoryScreen } from './Inventory';
import MoreScreen from './More';

const TABS = [
  { key: 'home', label: 'الرئيسية', icon: 'grid', iconOff: 'grid-outline' },
  { key: 'pos', label: 'البيع', icon: 'cart', iconOff: 'cart-outline' },
  { key: 'repairs', label: 'الصيانة', icon: 'construct', iconOff: 'construct-outline' },
  { key: 'stock', label: 'المخزون', icon: 'cube', iconOff: 'cube-outline' },
  { key: 'more', label: 'المزيد', icon: 'menu', iconOff: 'menu-outline' },
] as const;

export default function TabsScreen({ navigation }: any) {
  const th = useTheme();
  const ins = useSafeAreaInsets();
  const { db, cart, conflicts } = useStore();
  const [tab, setTab] = useState<string>('home');
  const [mounted, setMounted] = useState<Record<string, boolean>>({ home: true });

  const go = (k: string) => {
    setMounted((m) => ({ ...m, [k]: true }));
    setTab(k);
  };
  const openRepairs = db.repairs.filter((r) => !CLOSED_STATUSES.includes(r.status)).length;
  const badges: Record<string, number> = {
    pos: cart.lines.reduce((a, l) => a + l.qty, 0),
    repairs: openRepairs,
    stock: conflicts.filter((c) => !c.reviewed).length,
  };

  const screens: Record<string, React.ReactNode> = {
    home: <DashboardScreen navigation={navigation} goTab={go} />,
    pos: <PosScreen navigation={navigation} />,
    repairs: <RepairsScreen navigation={navigation} />,
    stock: <InventoryScreen navigation={navigation} />,
    more: <MoreScreen navigation={navigation} />,
  };

  return (
    <View style={{ flex: 1, backgroundColor: th.bg }}>
      {TABS.map((t) =>
        mounted[t.key] ? (
          <View key={t.key} style={{ flex: 1, display: tab === t.key ? 'flex' : 'none' }}>{screens[t.key]}</View>
        ) : null,
      )}
      <View style={[row, { backgroundColor: th.card, borderTopWidth: 1, borderTopColor: th.border, paddingBottom: Math.max(ins.bottom, 6), paddingTop: 6 }]}>
        {TABS.map((t) => {
          const active = tab === t.key;
          const b = badges[t.key];
          return (
            <Pressable key={t.key} onPress={() => go(t.key)} style={{ flex: 1, alignItems: 'center', gap: 2, paddingVertical: 4 }}>
              <View>
                <View style={{ backgroundColor: active ? th.primarySoft : 'transparent', paddingHorizontal: 16, paddingVertical: 3, borderRadius: 14 }}>
                  <Ionicons name={(active ? t.icon : t.iconOff) as any} size={22} color={active ? th.primary : th.sub} />
                </View>
                {b ? (
                  <View style={{ position: 'absolute', top: -3, right: 4, minWidth: 18, height: 18, borderRadius: 9, backgroundColor: t.key === 'stock' ? th.danger : th.accent, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 4 }}>
                    <Text style={{ fontSize: 10, fontWeight: '800', color: t.key === 'stock' ? '#fff' : '#1F1300' }}>{b}</Text>
                  </View>
                ) : null}
              </View>
              <Text style={{ fontSize: 11, fontWeight: active ? '800' : '600', color: active ? th.primary : th.sub }}>{t.label}</Text>
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}
