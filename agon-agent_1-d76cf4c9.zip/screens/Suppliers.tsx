import React, { useEffect, useState } from 'react';
import { FlatList, ScrollView, View } from 'react-native';
import { useTheme } from '../lib/theme';
import { saleSyncState, useStore } from '../lib/store';
import { Avatar, Badge, Btn, Card, Chip, ChipRow, Divider, Empty, Fab, Field, Guard, IconButton, KV, Picker, Screen, SearchBar, SectionTitle, Sheet, Stepper, SyncBadge, T, row, useDialog } from '../components/ui';
import { fmtDate, fmtDateTime, money, num } from '../lib/format';
import { PAY_METHODS } from '../lib/engine';
import { Pay, Purchase, Supplier } from '../lib/types';

function SupplierForm({ visible, onClose, supplier }: { visible: boolean; onClose: () => void; supplier?: Supplier }) {
  const dlg = useDialog();
  const { upsert, newId } = useStore();
  const [f, setF] = useState({ name: '', phone: '', email: '', address: '', notes: '', opening: '' });
  useEffect(() => { if (visible) setF({ name: supplier?.name || '', phone: supplier?.phone || '', email: supplier?.email || '', address: supplier?.address || '', notes: supplier?.notes || '', opening: supplier ? String(supplier.opening) : '' }); }, [visible]);
  const set = (k: string) => (t: string) => setF((p) => ({ ...p, [k]: t }));
  const save = () => {
    if (!f.name.trim()) { dlg.alert('اسم المورد مطلوب'); return; }
    const rec: Supplier = { id: supplier?.id || newId('sup-'), name: f.name.trim(), phone: f.phone.trim(), email: f.email.trim(), address: f.address.trim(), notes: f.notes, opening: supplier ? supplier.opening : num(f.opening), createdAt: supplier?.createdAt || Date.now() };
    upsert('suppliers', rec, `${supplier ? 'تعديل' : 'إضافة'} المورد ${rec.name}`);
    dlg.toast('تم حفظ المورد');
    onClose();
  };
  return (
    <Sheet visible={visible} title={supplier ? 'تعديل مورد' : 'مورد جديد'} onClose={onClose} tall footer={<Btn title="حفظ" icon="checkmark" onPress={save} />}>
      <Field label="اسم المورد *" value={f.name} onChangeText={set('name')} />
      <Field label="الهاتف" value={f.phone} onChangeText={set('phone')} keyboardType="phone-pad" />
      <Field label="البريد الإلكتروني" value={f.email} onChangeText={set('email')} keyboardType="email-address" autoCapitalize="none" />
      <Field label="العنوان" value={f.address} onChangeText={set('address')} />
      {!supplier ? <Field label="رصيد افتتاحي (مستحق للمورد)" value={f.opening} onChangeText={set('opening')} keyboardType="decimal-pad" /> : null}
      <Field label="ملاحظات" value={f.notes} onChangeText={set('notes')} multiline />
    </Sheet>
  );
}

export function SuppliersScreen({ navigation }: any) {
  const th = useTheme();
  const { db, bal, settings } = useStore();
  const [q, setQ] = useState('');
  const [form, setForm] = useState(false);
  const list = db.suppliers.filter((s) => !s.deleted && (!q || s.name.includes(q) || (s.phone || '').includes(q)));
  return (
    <Screen title="الموردون" subtitle={`${list.length} مورد`} onBack={() => navigation.goBack()}>
      <Guard perm="purchases">
        <SearchBar value={q} onChangeText={setQ} />
        <FlatList
          data={list}
          keyExtractor={(s) => s.id}
          contentContainerStyle={{ paddingBottom: 100, paddingTop: 6 }}
          ListEmptyComponent={<Empty icon="business-outline" title="لا يوجد موردون" sub="أضف مورداً لتسجيل المشتريات" />}
          renderItem={({ item: s }) => {
            const b = bal.sup[s.id] || 0;
            return (
              <Card onPress={() => navigation.navigate('SupplierDetail', { id: s.id })} style={{ marginBottom: 8 }}>
                <View style={[row, { gap: 12 }]}>
                  <Avatar name={s.name} tone="info" />
                  <View style={{ flex: 1 }}><T v="bold">{s.name}</T><T v="small">{s.phone}</T></View>
                  {Math.abs(b) > 0.001 ? <Badge text={b > 0 ? `له ${money(b)}` : `عليه ${money(-b)}`} tone={b > 0 ? 'warn' : 'success'} /> : null}
                </View>
              </Card>
            );
          }}
        />
        <Fab icon="add" label="مورد" onPress={() => setForm(true)} />
        <SupplierForm visible={form} onClose={() => setForm(false)} />
      </Guard>
    </Screen>
  );
}

export function SupplierDetailScreen({ navigation, route }: any) {
  const th = useTheme();
  const dlg = useDialog();
  const { db, bal, settings, commit, newId } = useStore();
  const s = db.suppliers.find((x) => x.id === route.params.id);
  const [edit, setEdit] = useState(false);
  const [pay, setPay] = useState(false);
  const [amt, setAmt] = useState('');
  const [method, setMethod] = useState('cash');
  if (!s) return <Screen title="مورد" onBack={() => navigation.goBack()}><Empty title="غير موجود" /></Screen>;
  const b = bal.sup[s.id] || 0;
  const purchases = [...db.purchases].reverse().filter((p) => p.supplierId === s.id);
  const rets = db.purchaseReturns.filter((r) => r.supplierId === s.id);
  const pays = [...db.cash].reverse().filter((c) => c.party?.type === 'supplier' && c.party.id === s.id);
  type St = { ts: number; label: string; amount: number };
  const stmt: St[] = [
    ...(s.opening ? [{ ts: 0, label: 'رصيد افتتاحي', amount: s.opening }] : []),
    ...purchases.map((p) => ({ ts: p.ts, label: `فاتورة شراء ${p.number}`, amount: p.total })),
    ...rets.map((r) => ({ ts: r.ts, label: 'مرتجع مشتريات', amount: -r.value })),
    ...pays.map((c) => ({ ts: c.ts, label: c.dir === 'out' ? `دفعة (${PAY_METHODS[c.method] || c.method})` : 'استرداد من المورد', amount: c.dir === 'out' ? -c.amount : c.amount })),
  ].sort((a, c) => a.ts - c.ts);
  let run = 0;
  const rows = stmt.map((x) => ({ ...x, run: (run += x.amount) }));
  const doPay = () => {
    const a = num(amt);
    if (a <= 0) { dlg.alert('أدخل مبلغاً صحيحاً'); return; }
    commit('cash.add', { entry: { id: newId('cash-'), dir: 'out', method, amount: a, category: 'supplier_payment', party: { type: 'supplier', id: s.id }, note: 'دفعة للمورد' } }, `دفعة ${money(a, settings.currency)} للمورد ${s.name}`);
    setPay(false); setAmt('');
    dlg.toast('تم تسجيل الدفعة');
  };
  return (
    <Screen title={s.name} subtitle={s.phone} onBack={() => navigation.goBack()} right={<IconButton icon="create-outline" onPress={() => setEdit(true)} />}>
      <ScrollView contentContainerStyle={{ paddingBottom: 40 }} showsVerticalScrollIndicator={false}>
        <Card>
          <T v="sub">الرصيد</T>
          <T v="h1" color={b > 0.001 ? th.warn : th.success}>{Math.abs(b) < 0.001 ? 'لا يوجد' : b > 0 ? `مستحق له ${money(b, settings.currency)}` : `رصيد لنا ${money(-b, settings.currency)}`}</T>
          <View style={[row, { gap: 8, marginTop: 10 }]}>
            <Btn flex small title="دفعة" icon="cash" variant="success" onPress={() => { setAmt(b > 0 ? String(Math.round(b * 100) / 100) : ''); setPay(true); }} />
            <Btn flex small title="فاتورة شراء" icon="download" onPress={() => navigation.navigate('NewPurchase', { supplierId: s.id })} />
          </View>
        </Card>
        <SectionTitle title="كشف الحساب" />
        <Card>
          {rows.length === 0 ? <T v="sub">لا توجد حركات</T> : [...rows].reverse().map((x, i) => (
            <View key={i} style={[row, { justifyContent: 'space-between', paddingVertical: 6, gap: 8 }]}>
              <View style={{ flex: 1 }}><T>{x.label}</T><T v="small">{x.ts ? fmtDate(x.ts) : ''} · الرصيد {money(x.run)}</T></View>
              <T v="bold" color={x.amount > 0 ? th.warn : th.success}>{x.amount > 0 ? '+' : ''}{money(x.amount)}</T>
            </View>
          ))}
        </Card>
      </ScrollView>
      <SupplierForm visible={edit} onClose={() => setEdit(false)} supplier={s} />
      <Sheet visible={pay} title="دفعة للمورد" onClose={() => setPay(false)} footer={<Btn title="تأكيد الدفع" icon="checkmark" variant="success" onPress={doPay} />}>
        <Field label="المبلغ" value={amt} onChangeText={setAmt} keyboardType="decimal-pad" />
        <ChipRow>{Object.entries(PAY_METHODS).map(([k, v]) => <Chip key={k} label={v} active={method === k} onPress={() => setMethod(k)} />)}</ChipRow>
      </Sheet>
    </Screen>
  );
}

export function NewPurchaseScreen({ navigation, route }: any) {
  const th = useTheme();
  const dlg = useDialog();
  const { db, settings, commit, newId, nextNumber, user } = useStore();
  const [supplierId, setSupplierId] = useState<string | null>(route.params?.supplierId || null);
  const [wh, setWh] = useState(settings.defaultWh);
  const [lines, setLines] = useState<{ productId: string; name: string; qty: number; cost: string }[]>([]);
  const [add, setAdd] = useState<string | null>(null);
  const [discount, setDiscount] = useState('');
  const [tax, setTax] = useState('');
  const [shipping, setShipping] = useState('');
  const [extra, setExtra] = useState('');
  const [pay, setPay] = useState('');
  const [method, setMethod] = useState('cash');
  const [note, setNote] = useState('');
  const sub = lines.reduce((a, l) => a + l.qty * num(l.cost), 0);
  const total = Math.max(0, sub - num(discount) + num(tax) + num(shipping) + num(extra));

  const addLine = (id: string | null) => {
    const p = db.products.find((x) => x.id === id);
    if (!p) return;
    setLines((ls) => (ls.some((l) => l.productId === p.id) ? ls.map((l) => (l.productId === p.id ? { ...l, qty: l.qty + 1 } : l)) : [...ls, { productId: p.id, name: p.name, qty: 1, cost: String(p.cost) }]));
    setAdd(null);
  };
  const save = () => {
    if (!supplierId) { dlg.alert('اختر المورد'); return; }
    if (!lines.length) { dlg.alert('أضف صنفاً واحداً على الأقل'); return; }
    const paid = Math.min(total, num(pay));
    const payments: Pay[] = paid > 0 ? [{ method, amount: paid }] : [];
    const id = newId('pur-');
    const number = nextNumber('purchase');
    const pur: Purchase = {
      id, number, supplierId, wh, lines: lines.map((l) => ({ productId: l.productId, name: l.name, qty: l.qty, cost: num(l.cost) })),
      discount: num(discount), tax: num(tax), shipping: num(shipping), extra: num(extra), total, payments, paid, ts: Date.now(), note, userId: user.id,
    };
    commit('purchase.create', { pur }, `شراء ${number} من ${db.suppliers.find((s) => s.id === supplierId)?.name} بقيمة ${money(total, settings.currency)}`);
    dlg.toast(`تم استلام ${number} وتحديث المخزون`);
    navigation.replace('Purchases');
  };
  return (
    <Screen title="فاتورة شراء" onBack={() => navigation.goBack()}>
      <Guard perm="purchases">
        <ScrollView contentContainerStyle={{ paddingBottom: 40 }} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
          <Card>
            <Picker label="المورد" value={supplierId} options={db.suppliers.filter((s) => !s.deleted).map((s) => ({ id: s.id, label: s.name, sub: s.phone }))} onSelect={setSupplierId} />
            <Picker label="مستودع الاستلام" value={wh} options={db.warehouses.filter((w) => !w.deleted).map((w) => ({ id: w.id, label: w.name }))} onSelect={(id) => id && setWh(id)} searchable={false} />
          </Card>
          <SectionTitle title="الأصناف" />
          {lines.map((l, i) => (
            <Card key={l.productId} style={{ marginBottom: 8, padding: 12 }}>
              <View style={[row, { justifyContent: 'space-between' }]}>
                <T v="bold" style={{ flex: 1 }} numberOfLines={1}>{l.name}</T>
                <IconButton icon="trash-outline" color={th.danger} size={16} onPress={() => setLines(lines.filter((_, k) => k !== i))} />
              </View>
              <View style={[row, { justifyContent: 'space-between', marginTop: 6 }]}>
                <Stepper value={l.qty} min={1} onChange={(n) => setLines(lines.map((x, k) => (k === i ? { ...x, qty: n } : x)))} />
                <View style={{ width: 110 }}><Field label="" value={l.cost} onChangeText={(t) => setLines(lines.map((x, k) => (k === i ? { ...x, cost: t } : x)))} keyboardType="decimal-pad" placeholder="التكلفة" style={{ marginBottom: 0 }} /></View>
                <T v="bold">{money(l.qty * num(l.cost))}</T>
              </View>
            </Card>
          ))}
          <Picker label="إضافة صنف" value={add} options={db.products.filter((p) => !p.deleted && p.kind === 'product').map((p) => ({ id: p.id, label: p.name, sub: p.sku, right: money(p.cost) }))} onSelect={addLine} placeholder="ابحث واختر صنفاً..." />
          <SectionTitle title="التكاليف والدفع" />
          <Card>
            <View style={[row, { gap: 10 }]}>
              <Field style={{ flex: 1 }} label="خصم" value={discount} onChangeText={setDiscount} keyboardType="decimal-pad" />
              <Field style={{ flex: 1 }} label="ضريبة" value={tax} onChangeText={setTax} keyboardType="decimal-pad" />
            </View>
            <View style={[row, { gap: 10 }]}>
              <Field style={{ flex: 1 }} label="شحن" value={shipping} onChangeText={setShipping} keyboardType="decimal-pad" />
              <Field style={{ flex: 1 }} label="تكاليف إضافية" value={extra} onChangeText={setExtra} keyboardType="decimal-pad" />
            </View>
            <Divider />
            <KV k="الإجمالي" v={money(total, settings.currency)} bold />
            <Field label="المدفوع للمورد الآن" value={pay} onChangeText={setPay} keyboardType="decimal-pad" placeholder="0" />
            <ChipRow>{Object.entries(PAY_METHODS).map(([k, v]) => <Chip key={k} label={v} active={method === k} onPress={() => setMethod(k)} />)}</ChipRow>
            <KV k="المتبقي للمورد" v={money(Math.max(0, total - num(pay)), settings.currency)} color={th.warn} />
            <Field label="ملاحظات" value={note} onChangeText={setNote} />
          </Card>
          <View style={{ height: 12 }} />
          <Btn title="اعتماد واستلام البضاعة" icon="checkmark-circle" variant="success" onPress={save} />
        </ScrollView>
      </Guard>
    </Screen>
  );
}

export function PurchasesScreen({ navigation }: any) {
  const th = useTheme();
  const dlg = useDialog();
  const ctx = useStore();
  const { db, settings, commit, newId } = ctx;
  const [sel, setSel] = useState<Purchase | null>(null);
  const [qty, setQty] = useState<Record<number, number>>({});
  const [refund, setRefund] = useState('');
  const list = [...db.purchases].reverse();
  const retQty = (pid: string, pu: Purchase) => db.purchaseReturns.filter((r) => r.purchaseId === pu.id).reduce((a, r) => a + r.lines.filter((l) => l.productId === pid).reduce((x, l) => x + l.qty, 0), 0);
  const value = sel ? sel.lines.reduce((a, l, i) => a + (qty[i] || 0) * l.cost, 0) : 0;
  const doReturn = () => {
    if (!sel) return;
    const lines = sel.lines.map((l, i) => ({ productId: l.productId, qty: qty[i] || 0, cost: l.cost })).filter((l) => l.qty > 0);
    if (!lines.length) { dlg.alert('اختر الكمية المرتجعة'); return; }
    const rf = Math.min(value, refund === '' ? 0 : num(refund));
    const ret = { id: newId('pret-'), purchaseId: sel.id, supplierId: sel.supplierId, lines, value, refund: rf > 0 ? { method: 'cash', amount: rf } : null, ts: Date.now(), wh: sel.wh };
    commit('purchase.return', { ret }, `مرتجع مشتريات على ${sel.number} بقيمة ${money(value, settings.currency)}`);
    setSel(null); setQty({}); setRefund('');
    dlg.toast('تم تسجيل المرتجع وخصمه من المخزون');
  };
  return (
    <Screen title="فواتير الشراء" onBack={() => navigation.goBack()}>
      <Guard perm="purchases">
        <FlatList
          data={list}
          keyExtractor={(p) => p.id}
          contentContainerStyle={{ paddingBottom: 100, paddingTop: 6 }}
          ListEmptyComponent={<Empty icon="download-outline" title="لا توجد فواتير شراء" sub="سجّل فاتورة شراء لاستلام البضاعة" />}
          renderItem={({ item: p }) => (
            <Card onPress={() => { setSel(p); setQty({}); setRefund(''); }} style={{ marginBottom: 8 }}>
              <View style={[row, { justifyContent: 'space-between' }]}><T v="bold">{p.number}</T><T v="h3" color={th.primary}>{money(p.total, settings.currency)}</T></View>
              <T v="sub">{db.suppliers.find((s) => s.id === p.supplierId)?.name} · {fmtDateTime(p.ts)}</T>
              <View style={[row, { gap: 6, marginTop: 6 }]}>
                <SyncBadge state={ctx.opSync(p.opId)} />
                {p.total - p.paid > 0.001 ? <Badge text={`متبقي ${money(p.total - p.paid)}`} tone="warn" /> : <Badge text="مسددة" tone="success" />}
              </View>
            </Card>
          )}
        />
        <Fab icon="add" label="شراء" onPress={() => navigation.navigate('NewPurchase')} />
        <Sheet visible={!!sel} title={sel?.number || ''} onClose={() => setSel(null)} tall footer={<Btn title={`مرتجع (${money(value, settings.currency)})`} icon="return-down-back" variant="danger" onPress={doReturn} disabled={value <= 0} />}>
          {sel ? (
            <>
              {sel.lines.map((l, i) => {
                const left = l.qty - retQty(l.productId, sel);
                return (
                  <View key={i} style={[row, { justifyContent: 'space-between', paddingVertical: 8 }]}>
                    <View style={{ flex: 1 }}><T v="bold">{l.name}</T><T v="small">{l.qty} × {money(l.cost)} · قابل للإرجاع {left}</T></View>
                    <Stepper value={qty[i] || 0} min={0} max={left} onChange={(n) => setQty({ ...qty, [i]: n })} />
                  </View>
                );
              })}
              <Divider />
              <KV k="الإجمالي" v={money(sel.total, settings.currency)} bold />
              <KV k="المدفوع" v={money(sel.paid, settings.currency)} />
              <Field label="مبلغ مسترد نقداً من المورد (اختياري، الباقي يخفض رصيده)" value={refund} onChangeText={setRefund} keyboardType="decimal-pad" />
            </>
          ) : null}
        </Sheet>
      </Guard>
    </Screen>
  );
}
