import React, { useMemo, useState } from 'react';
import { FlatList, Pressable, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useTheme, R } from '../lib/theme';
import { useStore } from '../lib/store';
import { Badge, Btn, Card, Chip, ChipRow, Empty, Field, Guard, IconButton, KV, Picker, SearchBar, Sheet, Stepper, T, row, useDialog, Divider } from '../components/ui';
import Scanner from '../components/Scanner';
import { money, normalizeDigits, num } from '../lib/format';
import { PAY_METHODS } from '../lib/engine';
import { Pay, Product, Sale, Warranty } from '../lib/types';

export function compatFor(db: ReturnType<typeof useStore>['db'], stock: ReturnType<typeof useStore>['stock'], modelId: string) {
  return db.products
    .filter((p) => !p.deleted && p.compat.some((c) => c.modelId === modelId))
    .map((p) => ({ p, verified: p.compat.find((c) => c.modelId === modelId)!.verified, avail: stock[p.id]?.available || 0 }))
    .sort((a, b) => Number(b.verified) - Number(a.verified) || Number(b.avail > 0) - Number(a.avail > 0));
}

export default function PosScreen({ navigation }: any) {
  return (
    <SafeAreaView style={{ flex: 1 }} edges={['top']}>
      <Guard perm="sales"><PosInner navigation={navigation} /></Guard>
    </SafeAreaView>
  );
}

function PosInner({ navigation }: any) {
  const th = useTheme();
  const dlg = useDialog();
  const ctx = useStore();
  const { db, stock, cart, setCart, held, holdCart, resumeHeld, dropHeld, settings, doc } = ctx;
  const [q, setQ] = useState('');
  const [cat, setCat] = useState('all');
  const [modelId, setModelId] = useState<string | null>(null);
  const [checkout, setCheckout] = useState(false);
  const [heldOpen, setHeldOpen] = useState(false);
  const [scan, setScan] = useState(false);

  const products = db.products.filter((p) => !p.deleted);
  const cats = useMemo(() => Array.from(new Set(products.map((p) => p.category))), [db.products.length]);
  const suggestions = modelId ? compatFor(db, stock, modelId) : [];
  const filtered = products.filter((p) => {
    if (cat !== 'all' && p.category !== cat) return false;
    if (!q) return true;
    const s = normalizeDigits(q).toLowerCase();
    return p.name.toLowerCase().includes(s) || p.sku.toLowerCase().includes(s) || (p.barcode || '').includes(s);
  });
  const count = cart.lines.reduce((a, l) => a + l.qty, 0);
  const subtotal = cart.lines.reduce((a, l) => a + l.qty * l.price - l.disc, 0);

  const add = (p: Product) => {
    setCart((c) => {
      const i = c.lines.findIndex((l) => l.productId === p.id);
      if (i >= 0) return { ...c, lines: c.lines.map((l, k) => (k === i ? { ...l, qty: l.qty + 1 } : l)) };
      return { ...c, lines: [...c.lines, { productId: p.id, qty: 1, price: p.price, disc: 0 }] };
    });
  };
  const byBarcode = (code: string): boolean => {
    const p = products.find((x) => x.barcode === code.trim() || x.sku.toLowerCase() === code.trim().toLowerCase());
    if (p) { add(p); dlg.toast(`أُضيف: ${p.name}`); setQ(''); return true; }
    return false;
  };

  const renderProduct = (p: Product, verified?: boolean) => {
    const av = stock[p.id]?.available || 0;
    const inCart = cart.lines.find((l) => l.productId === p.id)?.qty || 0;
    const physical = p.kind === 'product';
    return (
      <Card key={p.id} style={{ marginBottom: 8, padding: 12 }}>
        <View style={[row, { gap: 12 }]}>
          <View style={{ width: 46, height: 46, borderRadius: 13, backgroundColor: th.primarySoft, alignItems: 'center', justifyContent: 'center' }}>
            <Ionicons name={p.kind === 'service' ? 'build' : 'cube'} size={22} color={th.primary} />
          </View>
          <View style={{ flex: 1, gap: 3 }}>
            <T v="bold" numberOfLines={2}>{p.name}</T>
            <View style={[row, { gap: 6, flexWrap: 'wrap' }]}>
              <T v="small">{p.sku}</T>
              {physical ? <Badge text={av > 0 ? `متوفر ${av}` : av === 0 ? 'نفد' : `عجز ${-av}`} tone={av > p.minStock ? 'success' : av > 0 ? 'warn' : 'danger'} /> : <Badge text="خدمة" tone="info" />}
              {verified !== undefined ? <Badge text={verified ? 'توافق موثّق' : 'توافق يدوي'} tone={verified ? 'success' : 'warn'} icon={verified ? 'shield-checkmark' : 'help-circle'} /> : null}
            </View>
          </View>
          <View style={{ alignItems: 'flex-end', gap: 6 }}>
            <T v="h3" color={th.primary}>{money(p.price, settings.currency)}</T>
            <Pressable onPress={() => add(p)} style={[row, { gap: 4, backgroundColor: inCart ? th.accent : th.primary, paddingHorizontal: 12, paddingVertical: 7, borderRadius: 10 }]}>
              <Ionicons name={inCart ? 'checkmark' : 'add'} size={16} color={inCart ? '#1F1300' : '#fff'} />
              <T v="small" color={inCart ? '#1F1300' : '#fff'} style={{ fontWeight: '800' }}>{inCart ? `في السلة ${inCart}` : 'إضافة'}</T>
            </Pressable>
          </View>
        </View>
      </Card>
    );
  };

  const modelOpts = db.models.filter((m) => !m.deleted).map((m) => ({ id: m.id, label: `${m.brand} ${m.name}`, sub: m.category }));
  const model = db.models.find((m) => m.id === modelId);

  return (
    <View style={{ flex: 1, paddingHorizontal: 16 }}>
      <View style={[row, { justifyContent: 'space-between', paddingVertical: 12 }]}>
        <View>
          <T v="h1">نقطة البيع</T>
          <T v="small">لا يُخصم المخزون إلا عند إتمام البيع</T>
        </View>
        <View style={[row, { gap: 8 }]}>
          <IconButton icon="scan" onPress={() => setScan(true)} />
          <Pressable onPress={() => setHeldOpen(true)} style={{ position: 'relative' }}>
            <IconButton icon="pause-circle-outline" onPress={() => setHeldOpen(true)} />
            {held.length ? <View style={{ position: 'absolute', top: -4, right: -4, backgroundColor: th.accent, borderRadius: 9, minWidth: 18, height: 18, alignItems: 'center', justifyContent: 'center' }}><T v="small" color="#1F1300" style={{ fontWeight: '800' }}>{held.length}</T></View> : null}
          </Pressable>
        </View>
      </View>

      <SearchBar value={q} onChangeText={setQ} placeholder="اسم المنتج أو الرمز أو الباركود" onSubmit={() => { if (q && byBarcode(q)) return; }} />

      <FlatList
        data={filtered}
        keyExtractor={(p) => p.id}
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={{ paddingBottom: count ? 100 : 30 }}
        ListHeaderComponent={
          <View>
            <Picker label="الجهاز (لاقتراح الملحقات المتوافقة)" value={modelId} options={modelOpts} onSelect={setModelId} allowClear placeholder="اختر موديل الجهاز..." icon="phone-portrait-outline" />
            {modelId ? (
              <View style={{ marginBottom: 10 }}>
                <View style={[row, { gap: 6, marginBottom: 8 }]}>
                  <Ionicons name="sparkles" size={16} color={th.accent} />
                  <T v="h3">متوافق مع {model?.brand} {model?.name}</T>
                </View>
                {suggestions.length === 0 ? <Card><T v="sub">لا توجد منتجات مرتبطة بهذا الموديل. يمكنك ربطها من «الأجهزة والتوافق».</T></Card> : suggestions.map((s) => renderProduct(s.p, s.verified))}
                <Divider />
                <T v="h3" style={{ marginBottom: 6 }}>كل المنتجات</T>
              </View>
            ) : null}
            <ChipRow>
              <Chip label="الكل" active={cat === 'all'} onPress={() => setCat('all')} />
              {cats.map((c) => <Chip key={c} label={c} active={cat === c} onPress={() => setCat(c)} />)}
            </ChipRow>
            <View style={{ height: 8 }} />
          </View>
        }
        renderItem={({ item }) => renderProduct(item)}
        ListEmptyComponent={<Empty icon="search-outline" title="لا توجد منتجات مطابقة" sub="أضف منتجات من تبويب المخزون" />}
      />

      {count ? (
        <Pressable onPress={() => setCheckout(true)} style={[row, { position: 'absolute', bottom: 14, left: 16, right: 16, backgroundColor: th.primary, borderRadius: R.lg, padding: 14, justifyContent: 'space-between', shadowColor: '#000', shadowOpacity: 0.25, shadowRadius: 10, elevation: 6 }]}>
          <View style={[row, { gap: 10 }]}>
            <View style={{ backgroundColor: 'rgba(255,255,255,0.2)', borderRadius: 12, minWidth: 34, height: 34, alignItems: 'center', justifyContent: 'center' }}>
              <T v="bold" color="#fff">{count}</T>
            </View>
            <T v="bold" color="#fff">عرض السلة وإتمام البيع</T>
          </View>
          <T v="h3" color="#fff">{money(subtotal, settings.currency)}</T>
        </Pressable>
      ) : null}

      <Scanner visible={scan} onClose={() => setScan(false)} onScan={(code) => { if (byBarcode(code)) setScan(false); else dlg.toast('باركود غير معروف: ' + code, 'danger'); }} />

      <Sheet visible={heldOpen} title="الفواتير المعلّقة" onClose={() => setHeldOpen(false)}>
        {held.length === 0 ? <Empty icon="pause-circle-outline" title="لا توجد فواتير معلّقة" sub="علّق السلة الحالية لخدمة عميل آخر ثم استأنفها لاحقاً" /> : null}
        {held.map((h) => (
          <Card key={h.id} style={{ marginBottom: 8 }}>
            <T v="bold">{h.lines.length} أصناف · {money(h.lines.reduce((a, l) => a + l.qty * l.price - l.disc, 0), settings.currency)}</T>
            <T v="small">{db.customers.find((c) => c.id === h.customerId)?.name || 'عميل نقدي'}</T>
            <View style={[row, { gap: 8, marginTop: 8 }]}>
              <Btn small title="استئناف" icon="play" onPress={() => {
                if (cart.lines.length) { dlg.alert('السلة الحالية غير فارغة', 'علّقها أو أفرغها أولاً.'); return; }
                resumeHeld(h.id); setHeldOpen(false);
              }} />
              <Btn small title="حذف" variant="danger" icon="trash" onPress={() => dropHeld(h.id)} />
            </View>
          </Card>
        ))}
      </Sheet>

      <Checkout visible={checkout} onClose={() => setCheckout(false)} navigation={navigation} />
    </View>
  );
}

function Checkout({ visible, onClose, navigation }: { visible: boolean; onClose: () => void; navigation: any }) {
  const th = useTheme();
  const dlg = useDialog();
  const ctx = useStore();
  const { db, stock, cart, setCart, settings, doc, bal, holdCart, commit, nextNumber, newId } = ctx;
  const [pays, setPays] = useState<{ method: string; amount: string }[]>([]);
  const [discStr, setDiscStr] = useState('');
  const [taxOn, setTaxOn] = useState(settings.taxRate > 0);

  const lines = cart.lines.map((l) => ({ ...l, p: db.products.find((x) => x.id === l.productId)! })).filter((l) => l.p);
  const subtotal = lines.reduce((a, l) => a + l.qty * l.price - l.disc, 0);
  const discount = Math.min(subtotal, num(discStr));
  const taxRate = taxOn ? settings.taxRate : 0;
  const tax = Math.round((subtotal - discount) * taxRate) / 100;
  const total = Math.round((subtotal - discount + tax) * 100) / 100;
  const paidSum = pays.reduce((a, p) => a + num(p.amount), 0);
  const remaining = Math.max(0, total - paidSum);
  const change = Math.max(0, paidSum - total);
  const customer = db.customers.find((c) => c.id === cart.customerId);
  const peers = Object.keys(doc.peers).length;

  const setLine = (i: number, patch: any) => setCart((c) => ({ ...c, lines: c.lines.map((l, k) => (k === i ? { ...l, ...patch } : l)).filter((l) => l.qty > 0) }));

  const finalize = async () => {
    if (!lines.length) return;
    // Offline overselling policy: warn, never block.
    const warns: string[] = [];
    for (const l of lines) {
      if (l.p.kind !== 'product') continue;
      const local = stock[l.p.id]?.byWh[settings.defaultWh] || 0;
      if (l.qty > local) {
        const share = Math.ceil(Math.max(0, local) / (peers + 1));
        warns.push(`${l.p.name}: المطلوب ${l.qty} والمتاح محلياً ${Math.max(0, local)}${peers ? ` (حصة هذا الجهاز التقديرية ${share})` : ''}`);
      }
    }
    if (warns.length) {
      const ok = await dlg.confirm('تحذير: الكمية تتجاوز المتاح محلياً', warns.join('\n') + '\n\nيمكن إتمام البيع، لكنه سيُعلَّم «يحتاج مراجعة» إذا ظهر عجز في المخزون بعد المزامنة. لن يُحذف أي بيع تلقائياً.', { confirmText: 'إتمام البيع رغم ذلك' });
      if (!ok) return;
    }
    let payments: Pay[] = pays.map((p) => ({ method: p.method, amount: num(p.amount) })).filter((p) => p.amount > 0);
    let excess = Math.round((paidSum - total) * 100) / 100;
    if (excess > 0) {
      for (let i = payments.length - 1; i >= 0 && excess > 0; i--) {
        if (payments[i].method !== 'cash') continue;
        const cut = Math.min(excess, payments[i].amount);
        payments[i] = { ...payments[i], amount: payments[i].amount - cut };
        excess -= cut;
      }
      if (excess > 0.001) { dlg.alert('مبلغ زائد', 'المبلغ المدفوع غير نقدي ويتجاوز الإجمالي. عدّل الدفعات.'); return; }
      payments = payments.filter((p) => p.amount > 0);
    }
    const paid = payments.reduce((a, p) => a + p.amount, 0);
    const owed = Math.round((total - paid) * 100) / 100;
    if (owed > 0.001) {
      if (!customer) { dlg.alert('دفع جزئي يتطلب عميلاً', 'اختر عميلاً مسجلاً لتسجيل المبلغ المتبقي كذمة، أو أكمل الدفع.'); return; }
      const lim = customer.creditLimit || 0;
      const cb = bal.cust[customer.id] || 0;
      if (lim > 0 && cb + owed > lim) { dlg.alert('تجاوز حد الائتمان', `رصيد العميل ${money(cb, settings.currency)} + المتبقي ${money(owed, settings.currency)} يتجاوز الحد ${money(lim, settings.currency)}.`); return; }
    }
    const id = newId('sale-');
    const number = nextNumber('sale');
    const sale: Sale = {
      id, number, kind: 'sale', customerId: customer?.id || null, wh: settings.defaultWh,
      lines: lines.map((l) => ({ productId: l.p.id, name: l.p.name, qty: l.qty, price: l.price, cost: l.p.cost, disc: l.disc, warrantyDays: l.p.warrantyDays })),
      subtotal, discount, taxRate, tax, total, payments, paid, ts: Date.now(), userId: ctx.user.id, oversold: warns.length > 0, note: cart.note,
    };
    const warranties: Warranty[] = lines.filter((l) => (l.p.warrantyDays || 0) > 0).map((l, i) => ({
      id: id + ':w' + i, number: nextNumber('warranty'), sourceType: 'sale', sourceId: id, sourceNumber: number, customerId: customer?.id || null,
      item: l.p.name, start: sale.ts, days: l.p.warrantyDays!, expiry: sale.ts + l.p.warrantyDays! * 86400000, covers: 'عيوب التصنيع', conditions: 'لا يشمل سوء الاستخدام أو الكسر أو السوائل',
    }));
    commit('sale.final', { sale, warranties }, `بيع ${number} بقيمة ${money(total, settings.currency)}`);
    setCart({ lines: [], customerId: null, discount: 0, note: '' });
    setPays([]); setDiscStr('');
    onClose();
    dlg.toast(`تم حفظ الفاتورة ${number} محلياً`);
    navigation.navigate('SaleDetail', { id });
  };

  const custOpts = db.customers.filter((c) => !c.deleted).map((c) => ({ id: c.id, label: c.name, sub: c.phone, right: bal.cust[c.id] ? money(bal.cust[c.id]) : undefined }));

  return (
    <Sheet visible={visible} title="السلة والدفع" onClose={onClose} tall
      footer={
        <View style={{ gap: 8 }}>
          <View style={[row, { gap: 8 }]}>
            <Btn flex title="إتمام البيع" icon="checkmark-circle" variant="success" onPress={finalize} disabled={!lines.length} />
            <Btn title="تعليق" icon="pause" variant="soft" onPress={() => { holdCart(); onClose(); dlg.toast('تم تعليق الفاتورة'); }} />
          </View>
        </View>
      }>
      {lines.length === 0 ? <Empty icon="cart-outline" title="السلة فارغة" /> : null}
      {lines.map((l, i) => {
        const local = stock[l.p.id]?.byWh[settings.defaultWh] || 0;
        const over = l.p.kind === 'product' && l.qty > local;
        return (
          <Card key={l.productId} style={{ marginBottom: 8, padding: 12 }}>
            <View style={[row, { justifyContent: 'space-between', gap: 8 }]}>
              <View style={{ flex: 1 }}>
                <T v="bold" numberOfLines={2}>{l.p.name}</T>
                {over ? <Badge text={`يتجاوز المتاح (${Math.max(0, local)})`} tone="warn" icon="warning" /> : null}
              </View>
              <T v="bold" color={th.primary}>{money(l.qty * l.price - l.disc)}</T>
            </View>
            <View style={[row, { justifyContent: 'space-between', marginTop: 8 }]}>
              <Stepper value={l.qty} min={0} onChange={(n) => setLine(i, { qty: n })} />
              <View style={[row, { gap: 8 }]}>
                <View style={{ width: 90 }}>
                  <Field label="" placeholder="السعر" keyboardType="decimal-pad" value={String(l.price)} onChangeText={(t) => setLine(i, { price: num(t) })} style={{ marginBottom: 0 }} />
                </View>
                <View style={{ width: 80 }}>
                  <Field label="" placeholder="خصم" keyboardType="decimal-pad" value={l.disc ? String(l.disc) : ''} onChangeText={(t) => setLine(i, { disc: num(t) })} style={{ marginBottom: 0 }} />
                </View>
              </View>
            </View>
          </Card>
        );
      })}

      <Picker label="العميل" value={cart.customerId} options={custOpts} onSelect={(id) => setCart((c) => ({ ...c, customerId: id }))} allowClear placeholder="عميل نقدي (بدون حساب)" icon="person-outline" />
      {customer && (bal.cust[customer.id] || 0) !== 0 ? <T v="small" style={{ marginTop: -6, marginBottom: 10 }} color={th.warn}>رصيد العميل الحالي: {money(bal.cust[customer.id], settings.currency)}</T> : null}

      <Field label="خصم على الفاتورة" keyboardType="decimal-pad" value={discStr} onChangeText={setDiscStr} placeholder="0" />
      {settings.taxRate > 0 ? <Pressable onPress={() => setTaxOn(!taxOn)} style={[row, { gap: 8, marginBottom: 10 }]}><Ionicons name={taxOn ? 'checkbox' : 'square-outline'} size={22} color={th.primary} /><T>تطبيق ضريبة {settings.taxRate}%</T></Pressable> : null}

      <Card style={{ marginBottom: 12 }}>
        <KV k="المجموع الفرعي" v={money(subtotal, settings.currency)} />
        {discount > 0 ? <KV k="الخصم" v={'- ' + money(discount, settings.currency)} color={th.danger} /> : null}
        {tax > 0 ? <KV k={`الضريبة ${taxRate}%`} v={money(tax, settings.currency)} /> : null}
        <Divider />
        <KV k="الإجمالي" v={money(total, settings.currency)} bold />
      </Card>

      <T v="h3" style={{ marginBottom: 8 }}>الدفعات</T>
      {pays.map((p, i) => (
        <View key={i} style={{ marginBottom: 8 }}>
          <ChipRow>
            {Object.entries(PAY_METHODS).map(([k, v]) => <Chip key={k} label={v} active={p.method === k} onPress={() => setPays(pays.map((x, j) => (j === i ? { ...x, method: k } : x)))} />)}
          </ChipRow>
          <View style={[row, { gap: 8, marginTop: 6 }]}>
            <View style={{ flex: 1 }}><Field label="" keyboardType="decimal-pad" value={p.amount} onChangeText={(t) => setPays(pays.map((x, j) => (j === i ? { ...x, amount: t } : x)))} placeholder="المبلغ" style={{ marginBottom: 0 }} /></View>
            <IconButton icon="trash-outline" color={th.danger} onPress={() => setPays(pays.filter((_, j) => j !== i))} />
          </View>
        </View>
      ))}
      <View style={[row, { gap: 8, marginBottom: 10 }]}>
        <Btn small title="دفع كامل نقداً" icon="cash" variant="soft" onPress={() => setPays([{ method: 'cash', amount: String(total) }])} />
        <Btn small title="إضافة دفعة" icon="add" variant="ghost" onPress={() => setPays([...pays, { method: pays.length ? 'card' : 'cash', amount: pays.length ? String(Math.max(0, Math.round(remaining * 100) / 100)) : '' }])} />
      </View>
      <Card style={{ backgroundColor: remaining > 0 ? th.warnSoft : th.successSoft, borderColor: 'transparent' }}>
        <KV k="المدفوع" v={money(paidSum, settings.currency)} />
        {remaining > 0 ? <KV k="المتبقي (ذمة على العميل)" v={money(remaining, settings.currency)} color={th.warn} bold /> : null}
        {change > 0 ? <KV k="الباقي للعميل" v={money(change, settings.currency)} color={th.success} bold /> : null}
      </Card>
    </Sheet>
  );
}
