import React, { useState } from 'react';
import { FlatList, Pressable, ScrollView, TextInput, View } from 'react-native';
import * as Clipboard from 'expo-clipboard';
import { useTheme, R } from '../lib/theme';
import { useStore } from '../lib/store';
import { Avatar, Badge, Btn, Card, Chip, ChipRow, Divider, Empty, Fab, Field, Guard, KV, Screen, SectionTitle, Sheet, SyncBadge, T, row, useDialog } from '../components/ui';
import { fmtDateTime, num } from '../lib/format';
import { ROLE_LABEL, ROLE_PERMS, Perm } from '../lib/engine';
import { RoleKey } from '../lib/types';
import { shareText } from '../lib/invoice';

const PERM_LABEL: Record<Perm, string> = {
  dashboard: 'اللوحة', sales: 'المبيعات', repairs: 'عرض الصيانة', 'repairs.manage': 'إدارة الصيانة', inventory: 'المخزون', 'inventory.edit': 'تعديل المخزون',
  purchases: 'المشتريات', finance: 'المالية', reports: 'التقارير', customers: 'العملاء', staff: 'الموظفون', sync: 'المزامنة',
  settings: 'الإعدادات', damage: 'التالف', warranty: 'الضمان',
};

export function StaffScreen({ navigation }: any) {
  const th = useTheme();
  const dlg = useDialog();
  const { db, user, settings, updateSettings, upsert, newId } = useStore();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const [role, setRole] = useState<RoleKey>('cashier');
  const [matrix, setMatrix] = useState<RoleKey | null>(null);
  const add = () => {
    if (!name.trim()) { dlg.alert('الاسم مطلوب'); return; }
    upsert('staff', { id: newId('stf-'), name: name.trim(), role, active: true }, `إضافة موظف ${name.trim()}`);
    setOpen(false); setName('');
  };
  const toggle = (id: string, active: boolean) => {
    if (id === user.id && !active === false) { dlg.alert('لا يمكن تعطيل المستخدم الحالي'); return; }
    upsert('staff', { id, active }, active ? 'تفعيل موظف' : 'تعطيل موظف');
  };
  return (
    <Screen title="الموظفون والصلاحيات" subtitle={`المستخدم الحالي: ${user.name}`} onBack={() => navigation.goBack()}>
      <Guard perm="staff">
        <FlatList
          data={db.staff}
          keyExtractor={(s) => s.id}
          contentContainerStyle={{ paddingBottom: 100, paddingTop: 6 }}
          ListFooterComponent={
            <View>
              <SectionTitle title="مصفوفة الصلاحيات" />
              <ChipRow>{(Object.keys(ROLE_LABEL) as RoleKey[]).map((r) => <Chip key={r} label={ROLE_LABEL[r]} active={matrix === r} onPress={() => setMatrix(matrix === r ? null : r)} />)}</ChipRow>
              {matrix ? (
                <Card style={{ marginTop: 8 }}>
                  <View style={[row, { flexWrap: 'wrap', gap: 6 }]}>
                    {(Object.keys(PERM_LABEL) as Perm[]).map((p) => <Badge key={p} text={PERM_LABEL[p]} tone={ROLE_PERMS[matrix].includes(p) ? 'success' : 'muted'} icon={ROLE_PERMS[matrix].includes(p) ? 'checkmark' : 'close'} />)}
                  </View>
                </Card>
              ) : null}
              <T v="small" style={{ marginTop: 12, lineHeight: 18 }}>ملاحظة: تبديل المستخدم هنا لا يتطلب رمز PIN في هذا الإصدار، فلا تعتمده كحماية أمنية ضد موظف من نفس الهاتف. تُسجّل كل عملية باسم المستخدم المختار في سجل التدقيق.</T>
            </View>
          }
          renderItem={({ item: s }) => (
            <Card style={{ marginBottom: 8, opacity: s.active ? 1 : 0.55 }}>
              <View style={[row, { gap: 12 }]}>
                <Avatar name={s.name} tone={s.id === user.id ? 'success' : 'primary'} />
                <View style={{ flex: 1 }}>
                  <T v="bold">{s.name}</T>
                  <T v="small">{ROLE_LABEL[s.role]}{s.id === user.id ? ' · المستخدم الحالي' : ''}</T>
                </View>
              </View>
              <View style={[row, { gap: 8, marginTop: 8 }]}>
                {s.active && s.id !== user.id ? <Btn flex small title="تبديل إلى هذا المستخدم" icon="swap-horizontal" variant="soft" onPress={() => { updateSettings({ userId: s.id }); dlg.toast(`المستخدم الحالي: ${s.name}`); }} /> : null}
                {s.id !== 'staff-owner' ? <Btn small title={s.active ? 'تعطيل' : 'تفعيل'} variant={s.active ? 'danger' : 'success'} onPress={() => toggle(s.id, !s.active)} disabled={s.id === user.id} /> : null}
              </View>
            </Card>
          )}
        />
        <Fab icon="person-add" label="موظف" onPress={() => setOpen(true)} />
        <Sheet visible={open} title="موظف جديد" onClose={() => setOpen(false)} footer={<Btn title="إضافة" icon="checkmark" onPress={add} />}>
          <Field label="الاسم" value={name} onChangeText={setName} />
          <T v="sub" style={{ marginBottom: 6, fontWeight: '600' }}>الدور</T>
          <ChipRow>{(Object.keys(ROLE_LABEL) as RoleKey[]).filter((r) => r !== 'owner').map((r) => <Chip key={r} label={ROLE_LABEL[r]} active={role === r} onPress={() => setRole(r)} />)}</ChipRow>
        </Sheet>
      </Guard>
    </Screen>
  );
}

export function AuditScreen({ navigation }: any) {
  const th = useTheme();
  const ctx = useStore();
  const { doc, db, settings } = ctx;
  const list = [...doc.ops].sort((a, b) => b.ts - a.ts).slice(0, 300);
  return (
    <Screen title="سجل التدقيق" subtitle={`${doc.ops.length} عملية مسجلة`} onBack={() => navigation.goBack()}>
      <FlatList
        data={list}
        keyExtractor={(o) => o.id}
        contentContainerStyle={{ paddingVertical: 10, paddingBottom: 40 }}
        ListEmptyComponent={<Empty icon="list-outline" title="السجل فارغ" sub="كل عملية تجريها ستُسجّل هنا بشكل دائم" />}
        renderItem={({ item: o }) => (
          <Card style={{ marginBottom: 6, padding: 11 }}>
            <T v="bold">{o.s}</T>
            <View style={[row, { justifyContent: 'space-between', marginTop: 4, gap: 6 }]}>
              <T v="small">{fmtDateTime(o.ts)} · {db.staff.find((s) => s.id === o.user)?.name || o.user} · {o.dev === settings.deviceId ? 'هذا الجهاز' : ctx.doc.peers[o.dev]?.name || 'جهاز آخر'}</T>
              <SyncBadge state={ctx.opSync(o.id)} />
            </View>
            <T v="small" color={th.sub}>{o.type} · #{o.seq}</T>
          </Card>
        )}
      />
    </Screen>
  );
}

export function SettingsScreen({ navigation }: any) {
  const th = useTheme();
  const dlg = useDialog();
  const { settings, updateSettings, backup, restore, resetAll, doc, db } = useStore();
  const [f, setF] = useState({ businessName: settings.businessName, currency: settings.currency, taxRate: String(settings.taxRate), deviceName: settings.deviceName, code: settings.code, phone: settings.phone, address: settings.address });
  const [bk, setBk] = useState<string | null>(null);
  const [rs, setRs] = useState(false);
  const [text, setText] = useState('');
  const set = (k: string) => (t: string) => setF((p) => ({ ...p, [k]: t }));
  const save = () => {
    const code = f.code.trim().toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 4);
    if (!f.businessName.trim() || !code) { dlg.alert('اسم المنشأة ورمز الجهاز مطلوبان'); return; }
    updateSettings({ businessName: f.businessName.trim(), currency: f.currency.trim() || 'ر.س', taxRate: Math.max(0, num(f.taxRate)), deviceName: f.deviceName.trim() || 'هاتف', code, phone: f.phone.trim(), address: f.address.trim() });
    setF((p) => ({ ...p, code }));
    dlg.toast('تم حفظ الإعدادات');
  };
  const doReset = async (seed: boolean) => {
    const ok = await dlg.confirm('حذف كل البيانات من هذا الجهاز', seed ? 'ستُحذف كل العمليات وتعود البيانات التجريبية الأولية.' : 'ستُحذف كل العمليات ويبدأ النظام فارغاً (مع قائمة الموديلات فقط). أنشئ نسخة احتياطية أولاً.', { confirmText: 'مسح نهائي', danger: true });
    if (!ok) return;
    resetAll(seed);
    navigation.navigate('Tabs');
    dlg.toast('تمت إعادة التهيئة');
  };
  const doRestore = () => {
    const r = restore(text);
    if (r.ok) { dlg.toast(r.message); setRs(false); setText(''); } else dlg.alert('فشلت الاستعادة', r.message);
  };
  return (
    <Screen title="الإعدادات والنسخ الاحتياطي" onBack={() => navigation.goBack()}>
      <Guard perm="settings">
        <ScrollView contentContainerStyle={{ paddingBottom: 40 }} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
          <SectionTitle title="بيانات المنشأة" />
          <Card>
            <Field label="اسم المنشأة" value={f.businessName} onChangeText={set('businessName')} />
            <Field label="الهاتف" value={f.phone} onChangeText={set('phone')} keyboardType="phone-pad" />
            <Field label="العنوان" value={f.address} onChangeText={set('address')} />
            <View style={[row, { gap: 10 }]}>
              <Field style={{ flex: 1 }} label="العملة" value={f.currency} onChangeText={set('currency')} />
              <Field style={{ flex: 1 }} label="ضريبة القيمة المضافة %" value={f.taxRate} onChangeText={set('taxRate')} keyboardType="decimal-pad" />
            </View>
          </Card>
          <SectionTitle title="هذا الجهاز" />
          <Card>
            <Field label="اسم الجهاز" value={f.deviceName} onChangeText={set('deviceName')} />
            <Field label="رمز الجهاز (يظهر في أرقام الفواتير)" value={f.code} onChangeText={set('code')} autoCapitalize="characters" hint="حرفان إلى 4 أحرف إنجليزية/أرقام، مختلف لكل هاتف لمنع تشابه الأرقام" />
            <KV k="معرّف الجهاز" v={settings.deviceId} />
          </Card>
          <View style={{ height: 12 }} />
          <Btn title="حفظ الإعدادات" icon="checkmark" onPress={save} />

          <SectionTitle title="النسخ الاحتياطي والاستعادة" />
          <Card>
            <T v="sub" style={{ lineHeight: 21 }}>النسخة تتضمن كل سجل العمليات ({doc.ops.length}) والإعدادات والأجهزة المرتبطة. تُحفظ بشكل غير مشفرة؛ احتفظ بها في مكان آمن.</T>
            <View style={[row, { gap: 8, marginTop: 10 }]}>
              <Btn flex title="إنشاء نسخة" icon="save" onPress={() => setBk(backup())} />
              <Btn flex title="استعادة" icon="refresh" variant="soft" onPress={() => { setText(''); setRs(true); }} />
            </View>
          </Card>

          <SectionTitle title="منطقة الخطر" />
          <Card style={{ borderColor: th.danger }}>
            <T v="sub" style={{ marginBottom: 10 }}>مسح كل البيانات المحلية لهذا الجهاز وبدء نظام جديد.</T>
            <View style={[row, { gap: 8 }]}>
              <Btn flex small title="بدء فارغ" icon="trash" variant="danger" onPress={() => doReset(false)} />
              <Btn flex small title="بيانات تجريبية" icon="flask" variant="ghost" onPress={() => doReset(true)} />
            </View>
          </Card>
        </ScrollView>
        <Sheet visible={bk !== null} title="النسخة الاحتياطية" onClose={() => setBk(null)} tall footer={<View style={[row, { gap: 8 }]}><Btn flex title="نسخ" icon="copy" onPress={async () => { if (bk) { await Clipboard.setStringAsync(bk); dlg.toast('تم نسخ النسخة'); } }} /><Btn flex title="مشاركة" icon="share-social" variant="soft" onPress={async () => { if (bk) await shareText(bk, 'نسخة احتياطية'); }} /></View>}>
          <TextInput value={bk || ''} editable={false} multiline style={{ backgroundColor: th.input, borderRadius: R.md, borderWidth: 1, borderColor: th.border, padding: 10, height: 260, color: th.text, fontSize: 11, textAlign: 'left', writingDirection: 'ltr' }} />
        </Sheet>
        <Sheet visible={rs} title="استعادة نسخة" onClose={() => setRs(false)} tall footer={<View style={[row, { gap: 8 }]}><Btn flex title="استعادة (يستبدل البيانات الحالية)" icon="refresh" variant="danger" onPress={doRestore} disabled={!text.trim()} /><Btn title="لصق" icon="clipboard" variant="soft" onPress={async () => setText(await Clipboard.getStringAsync())} /></View>}>
          <TextInput value={text} onChangeText={setText} multiline placeholder="{ ... }" placeholderTextColor={th.sub} style={{ backgroundColor: th.input, borderRadius: R.md, borderWidth: 1, borderColor: th.border, padding: 10, height: 260, color: th.text, fontSize: 11, textAlign: 'left', writingDirection: 'ltr', textAlignVertical: 'top' }} />
        </Sheet>
      </Guard>
    </Screen>
  );
}
