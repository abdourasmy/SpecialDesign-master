import React, { useState } from 'react';
import { FlatList, ScrollView, View, Pressable } from 'react-native';
import { useTheme } from '../lib/theme';
import { useStore } from '../lib/store';
import { Badge, Btn, Card, Chip, ChipRow, Empty, Fab, Field, Guard, IconButton, Picker, Screen, SearchBar, SectionTitle, Sheet, T, row, useDialog } from '../components/ui';
import { money } from '../lib/format';

const CATS = ['هاتف', 'لوحي', 'حاسوب محمول', 'حاسوب مكتبي', 'أخرى'];

export function ModelsScreen({ navigation }: any) {
  const th = useTheme();
  const dlg = useDialog();
  const { db, upsert, newId, can } = useStore();
  const [q, setQ] = useState('');
  const [cat, setCat] = useState('all');
  const [open, setOpen] = useState(false);
  const [brand, setBrand] = useState('');
  const [name, setName] = useState('');
  const [category, setCategory] = useState('هاتف');
  const [mn, setMn] = useState('');
  const list = db.models.filter((m) => !m.deleted && (cat === 'all' || m.category === cat) && (!q || `${m.brand} ${m.name}`.toLowerCase().includes(q.toLowerCase())));
  const brands = Array.from(new Set(db.models.map((m) => m.brand)));
  const save = () => {
    if (!brand.trim() || !name.trim()) { dlg.alert('الماركة والموديل مطلوبان'); return; }
    if (db.models.some((m) => !m.deleted && m.brand.toLowerCase() === brand.trim().toLowerCase() && m.name.toLowerCase() === name.trim().toLowerCase())) { dlg.alert('موجود مسبقاً', 'هذا الموديل مسجل بالفعل.'); return; }
    const rec = { id: newId('mdl-'), brand: brand.trim(), name: name.trim(), category, modelNumber: mn.trim() };
    upsert('models', rec, `إضافة موديل ${rec.brand} ${rec.name}`);
    setOpen(false); setBrand(''); setName(''); setMn('');
    navigation.navigate('ModelDetail', { id: rec.id });
  };
  return (
    <Screen title="الأجهزة والتوافق" subtitle="ربط الموديلات بالملحقات وقطع الغيار" onBack={() => navigation.goBack()}>
      <Guard perm="inventory">
        <SearchBar value={q} onChangeText={setQ} placeholder="ابحث عن موديل" />
        <ChipRow>
          <Chip label="الكل" active={cat === 'all'} onPress={() => setCat('all')} />
          {CATS.map((c) => <Chip key={c} label={c} active={cat === c} onPress={() => setCat(c)} />)}
        </ChipRow>
        <FlatList
          data={list}
          keyExtractor={(m) => m.id}
          contentContainerStyle={{ paddingVertical: 10, paddingBottom: 100 }}
          ListEmptyComponent={<Empty icon="phone-portrait-outline" title="لا توجد موديلات" />}
          renderItem={({ item: m }) => {
            const n = db.products.filter((p) => !p.deleted && p.compat.some((c) => c.modelId === m.id)).length;
            return (
              <Card onPress={() => navigation.navigate('ModelDetail', { id: m.id })} style={{ marginBottom: 8 }}>
                <View style={[row, { justifyContent: 'space-between' }]}>
                  <View><T v="bold">{m.brand} {m.name}</T><T v="small">{m.category}{m.modelNumber ? ' · ' + m.modelNumber : ''}</T></View>
                  <Badge text={`${n} منتج متوافق`} tone={n ? 'success' : 'muted'} />
                </View>
              </Card>
            );
          }}
        />
        {can('inventory.edit') ? <Fab icon="add" label="موديل" onPress={() => setOpen(true)} /> : null}
        <Sheet visible={open} title="موديل جديد" onClose={() => setOpen(false)} tall footer={<Btn title="حفظ" icon="checkmark" onPress={save} />}>
          <Field label="الماركة *" value={brand} onChangeText={setBrand} placeholder="Apple" />
          <ChipRow>{brands.slice(0, 12).map((b) => <Chip key={b} label={b} active={brand === b} onPress={() => setBrand(b)} />)}</ChipRow>
          <View style={{ height: 12 }} />
          <Field label="الموديل *" value={name} onChangeText={setName} placeholder="iPhone 16" />
          <Field label="رقم الموديل" value={mn} onChangeText={setMn} />
          <T v="sub" style={{ marginBottom: 6, fontWeight: '600' }}>الفئة</T>
          <ChipRow>{CATS.map((c) => <Chip key={c} label={c} active={category === c} onPress={() => setCategory(c)} />)}</ChipRow>
        </Sheet>
      </Guard>
    </Screen>
  );
}

export function ModelDetailScreen({ navigation, route }: any) {
  const th = useTheme();
  const { db, stock, settings, upsert, can } = useStore();
  const m = db.models.find((x) => x.id === route.params.id);
  const [add, setAdd] = useState<string | null>(null);
  if (!m) return <Screen title="موديل" onBack={() => navigation.goBack()}><Empty title="غير موجود" /></Screen>;
  const linked = db.products.filter((p) => !p.deleted && p.compat.some((c) => c.modelId === m.id));
  const unlinked = db.products.filter((p) => !p.deleted && !p.compat.some((c) => c.modelId === m.id));
  const edit = can('inventory.edit');
  const setCompat = (pid: string, fn: (c: any[]) => any[]) => {
    const p = db.products.find((x) => x.id === pid)!;
    upsert('products', { id: pid, compat: fn(p.compat) }, `تحديث توافق ${p.name} مع ${m.brand} ${m.name}`);
  };
  const owners = db.custDevices.filter((d) => d.modelId === m.id).length;
  return (
    <Screen title={`${m.brand} ${m.name}`} subtitle={`${m.category} · ${owners} جهاز مسجل لدى العملاء`} onBack={() => navigation.goBack()}>
      <ScrollView contentContainerStyle={{ paddingBottom: 40 }} showsVerticalScrollIndicator={false}>
        <SectionTitle title={`المنتجات المتوافقة (${linked.length})`} />
        {linked.length === 0 ? <Card><T v="sub">لم تُربط منتجات بهذا الموديل بعد.</T></Card> : linked.map((p) => {
          const c = p.compat.find((x) => x.modelId === m.id)!;
          return (
            <Card key={p.id} style={{ marginBottom: 8, padding: 12 }}>
              <View style={[row, { gap: 8 }]}>
                <Pressable style={{ flex: 1 }} onPress={() => navigation.navigate('ProductDetail', { id: p.id })}>
                  <T v="bold" numberOfLines={1}>{p.name}</T>
                  <T v="small">{p.category} · {money(p.price, settings.currency)} · متوفر {stock[p.id]?.available || 0}</T>
                </Pressable>
                <Pressable disabled={!edit} onPress={() => setCompat(p.id, (cs) => cs.map((x) => (x.modelId === m.id ? { ...x, verified: !x.verified } : x)))}>
                  <Badge text={c.verified ? 'موثّق' : 'يدوي'} tone={c.verified ? 'success' : 'warn'} icon={c.verified ? 'shield-checkmark' : 'help-circle'} />
                </Pressable>
                {edit ? <IconButton icon="close" size={16} onPress={() => setCompat(p.id, (cs) => cs.filter((x) => x.modelId !== m.id))} /> : null}
              </View>
            </Card>
          );
        })}
        {edit ? (
          <>
            <SectionTitle title="إضافة منتج متوافق" />
            <Picker label="المنتج" value={add} options={unlinked.map((p) => ({ id: p.id, label: p.name, sub: p.category }))} onSelect={(id) => { if (id) { setCompat(id, (cs) => [...cs, { modelId: m.id, verified: false }]); setAdd(null); } }} placeholder="اختر منتجاً لربطه..." />
            <T v="small">يُسجّل الربط الجديد «يدوي» حتى تضغط على الشارة لتوثيقه. لا يُفترض التوافق بين الأجيال المتقاربة.</T>
          </>
        ) : null}
      </ScrollView>
    </Screen>
  );
}
