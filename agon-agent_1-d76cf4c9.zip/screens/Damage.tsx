import React, { useEffect, useState } from 'react';
import { FlatList, View } from 'react-native';
import { useTheme } from '../lib/theme';
import { useStore } from '../lib/store';
import { Badge, Btn, Card, Chip, ChipRow, Divider, Empty, Fab, Field, Guard, KV, Picker, Screen, SectionTitle, Sheet, Stat, Stepper, T, row, useDialog } from '../components/ui';
import { fmtDateTime, money, num } from '../lib/format';
import { DAMAGE_CATS } from '../lib/engine';
import { Damage } from '../lib/types';

const STATUS: Record<string, { t: string; tone: string }> = {
  repairable: { t: 'قابل للإصلاح (مستبعد من البيع)', tone: 'warn' },
  written_off: { t: 'مشطوب', tone: 'danger' },
  recovered: { t: 'تم استرداده للمخزون', tone: 'success' },
  disposed: { t: 'تم إتلافه', tone: 'danger' },
};

export function DamageForm({ visible, onClose, productId }: { visible: boolean; onClose: () => void; productId?: string }) {
  const dlg = useDialog();
  const { db, stock, commit, newId, settings, user } = useStore();
  const [pid, setPid] = useState<string | null>(null);
  const [qty, setQty] = useState(1);
  const [wh, setWh] = useState(settings.defaultWh);
  const [cat, setCat] = useState('damaged');
  const [reason, setReason] = useState('');
  const [resp, setResp] = useState<string | null>(user.id);
  const [note, setNote] = useState('');
  useEffect(() => { if (visible) { setPid(productId || null); setQty(1); setReason(''); setNote(''); setCat('damaged'); setResp(user.id); } }, [visible]);
  const p = db.products.find((x) => x.id === pid);
  const avail = pid ? stock[pid]?.byWh[wh] || 0 : 0;
  const save = () => {
    if (!p) { dlg.alert('اختر المنتج'); return; }
    if (!reason.trim()) { dlg.alert('السبب مطلوب'); return; }
    if (qty > avail) { dlg.alert('الكمية أكبر من المتاح', `المتاح في المستودع: ${Math.max(0, avail)}`); return; }
    const d: Damage = {
      id: newId('dmg-'), productId: p.id, name: p.name, qty, wh, category: cat, reason: reason.trim(), unitCost: p.cost, total: Math.round(p.cost * qty * 100) / 100,
      status: 'written_off', lossCost: 0, responsible: db.staff.find((s) => s.id === resp)?.name || user.name, note, ts: Date.now(), userId: user.id, approvedBy: user.name,
    };
    commit('damage.create', { d }, `${DAMAGE_CATS[cat]}: ${qty} × ${p.name}`);
    dlg.toast('تم تسجيل السجل وخصم الكمية من المتاح');
    onClose();
  };
  return (
    <Sheet visible={visible} title="تسجيل تالف / هالك" onClose={onClose} tall footer={<Btn title="تسجيل" icon="checkmark" variant="danger" onPress={save} />}>
      <Picker label="المنتج" value={pid} options={db.products.filter((x) => !x.deleted && x.kind === 'product').map((x) => ({ id: x.id, label: x.name, right: String(stock[x.id]?.available || 0) }))} onSelect={setPid} />
      <Picker label="المستودع" value={wh} options={db.warehouses.filter((w) => !w.deleted).map((w) => ({ id: w.id, label: w.name }))} onSelect={(id) => id && setWh(id)} searchable={false} />
      <T v="sub" style={{ marginBottom: 6, fontWeight: '600' }}>الفئة</T>
      <ChipRow>{Object.entries(DAMAGE_CATS).map(([k, v]) => <Chip key={k} label={v} active={cat === k} onPress={() => setCat(k)} />)}</ChipRow>
      <View style={{ height: 10 }} />
      <View style={[row, { justifyContent: 'space-between', marginBottom: 12 }]}>
        <View><T>الكمية</T>{pid ? <T v="small">المتاح {avail}</T> : null}</View>
        <Stepper value={qty} min={1} onChange={setQty} />
      </View>
      {p ? <Card style={{ marginBottom: 12 }}><KV k="تكلفة الوحدة" v={money(p.cost, settings.currency)} /><KV k="إجمالي التكلفة" v={money(p.cost * qty, settings.currency)} bold /></Card> : null}
      <Field label="السبب *" value={reason} onChangeText={setReason} placeholder="مثال: سقط أثناء العرض" />
      <Picker label="الشخص المسؤول" value={resp} options={db.staff.filter((s) => s.active).map((s) => ({ id: s.id, label: s.name }))} onSelect={setResp} searchable={false} />
      <Field label="ملاحظات" value={note} onChangeText={setNote} multiline />
      <T v="small">{cat === 'repairable' ? 'القابل للإصلاح يُنقل إلى مخزون «تالف قابل للإصلاح» ولا تُحتسب خسارته حتى إتلافه أو تُحتسب تكلفة الإصلاح عند الاسترداد.' : 'تُحتسب الخسارة مرة واحدة عند التسجيل، ولا تُحتسب مجدداً.'}</T>
    </Sheet>
  );
}

export default function DamageScreen({ navigation }: any) {
  const th = useTheme();
  const dlg = useDialog();
  const { db, settings, commit, can } = useStore();
  const [form, setForm] = useState(false);
  const [f, setF] = useState('all');
  const [rec, setRec] = useState<Damage | null>(null);
  const [rc, setRc] = useState('');
  const list = [...db.damages].reverse().filter((d) => f === 'all' || d.status === f);
  const totalLoss = db.damages.reduce((a, d) => a + d.lossCost, 0);
  const repairQty = db.damages.filter((d) => d.status === 'repairable').reduce((a, d) => a + d.qty, 0);
  const disposedQty = db.damages.filter((d) => d.status !== 'repairable' && d.status !== 'recovered').reduce((a, d) => a + d.qty, 0);
  const byCat: Record<string, number> = {};
  db.damages.forEach((d) => { byCat[d.category] = (byCat[d.category] || 0) + d.lossCost; });
  const byProd: Record<string, number> = {};
  db.damages.forEach((d) => { byProd[d.name] = (byProd[d.name] || 0) + d.qty; });
  const top = Object.entries(byProd).sort((a, b) => b[1] - a[1]).slice(0, 3);

  const dispose = async (d: Damage) => {
    const ok = await dlg.confirm('إتلاف نهائي', `سيتم شطب ${d.qty} × ${d.name} وتسجيل خسارة ${money(d.total, settings.currency)}.`, { confirmText: 'إتلاف', danger: true });
    if (ok) { commit('damage.resolve', { id: d.id, action: 'dispose' }, `إتلاف ${d.name}`); dlg.toast('تم الإتلاف وتسجيل الخسارة'); }
  };
  const recover = () => {
    if (!rec) return;
    commit('damage.resolve', { id: rec.id, action: 'recover', recoveryCost: num(rc) }, `استرداد ${rec.name} للمخزون`);
    setRec(null); setRc('');
    dlg.toast('تمت إعادة الكمية للمخزون المتاح');
  };

  return (
    <Screen title="التالف والهالك" onBack={() => navigation.goBack()}>
      <Guard perm="damage">
        <FlatList
          data={list}
          keyExtractor={(d) => d.id}
          contentContainerStyle={{ paddingBottom: 100 }}
          ListHeaderComponent={
            <View>
              <View style={[row, { gap: 10, flexWrap: 'wrap' }]}>
                <Stat label="إجمالي الخسائر" value={money(totalLoss, settings.currency)} icon="trending-down" tone="danger" />
                <Stat label="قابل للإصلاح" value={String(repairQty)} icon="build" tone="warn" />
                <Stat label="مشطوب" value={String(disposedQty)} icon="trash" tone="muted" />
                <Stat label="سجلات" value={String(db.damages.length)} icon="list" tone="info" />
              </View>
              {Object.keys(byCat).length ? (
                <>
                  <SectionTitle title="الخسائر حسب السبب" />
                  <Card>
                    {Object.entries(byCat).map(([k, v]) => <KV key={k} k={DAMAGE_CATS[k]} v={money(v, settings.currency)} />)}
                    {top.length ? <><Divider /><T v="sub">الأكثر تعرضاً للتلف: {top.map(([n, q]) => `${n} (${q})`).join('، ')}</T></> : null}
                  </Card>
                </>
              ) : null}
              <View style={{ height: 12 }} />
              <ChipRow>
                <Chip label="الكل" active={f === 'all'} onPress={() => setF('all')} />
                <Chip label="قابل للإصلاح" active={f === 'repairable'} onPress={() => setF('repairable')} />
                <Chip label="مشطوب" active={f === 'written_off'} onPress={() => setF('written_off')} />
                <Chip label="مسترد" active={f === 'recovered'} onPress={() => setF('recovered')} />
                <Chip label="متلف" active={f === 'disposed'} onPress={() => setF('disposed')} />
              </ChipRow>
              <View style={{ height: 8 }} />
            </View>
          }
          ListEmptyComponent={<Empty icon="shield-checkmark-outline" title="لا توجد سجلات" sub="سجّل التالف أو الهالك لتتبع الخسائر" />}
          renderItem={({ item: d }) => (
            <Card style={{ marginBottom: 8 }}>
              <View style={[row, { justifyContent: 'space-between', gap: 8 }]}>
                <T v="bold" style={{ flex: 1 }}>{d.name} × {d.qty}</T>
                <Badge text={DAMAGE_CATS[d.category]} tone="danger" />
              </View>
              <T v="sub">{d.reason}</T>
              <T v="small">{fmtDateTime(d.ts)} · المسؤول: {d.responsible} · تكلفة {money(d.total, settings.currency)}</T>
              <View style={[row, { justifyContent: 'space-between', marginTop: 6 }]}>
                <Badge text={STATUS[d.status].t} tone={STATUS[d.status].tone} />
                {d.lossCost > 0 ? <T v="small" color={th.danger}>خسارة {money(d.lossCost, settings.currency)}</T> : null}
              </View>
              {d.status === 'repairable' && can('damage') ? (
                <View style={[row, { gap: 8, marginTop: 8 }]}>
                  <Btn flex small title="استرداد للمخزون" icon="arrow-undo" variant="success" onPress={() => { setRec(d); setRc(''); }} />
                  <Btn flex small title="إتلاف نهائي" icon="trash" variant="danger" onPress={() => dispose(d)} />
                </View>
              ) : null}
            </Card>
          )}
        />
        <Fab icon="add" label="تسجيل" onPress={() => setForm(true)} />
        <DamageForm visible={form} onClose={() => setForm(false)} />
        <Sheet visible={!!rec} title="استرداد قطعة مُصلحة" onClose={() => setRec(null)} footer={<Btn title="تأكيد الاسترداد" icon="checkmark" variant="success" onPress={recover} />}>
          <T style={{ marginBottom: 10 }}>{rec?.name} × {rec?.qty}</T>
          <Field label="تكلفة الإصلاح (تُسجَّل مصروفاً من الصندوق)" value={rc} onChangeText={setRc} keyboardType="decimal-pad" placeholder="0" />
        </Sheet>
      </Guard>
    </Screen>
  );
}
