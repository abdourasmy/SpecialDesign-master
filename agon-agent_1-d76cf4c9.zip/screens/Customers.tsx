import React, { useState } from 'react';
import { FlatList, Linking, ScrollView, View } from 'react-native';
import { useTheme } from '../lib/theme';
import { useStore } from '../lib/store';
import { Avatar, Badge, Btn, Card, Chip, ChipRow, Divider, Empty, Fab, Field, Guard, IconButton, KV, Picker, Screen, SearchBar, SectionTitle, Sheet, T, row, useDialog } from '../components/ui';
import { CustomerForm, DeviceForm, deviceName } from '../components/Forms';
import { fmtDate, money, normalizeDigits, num } from '../lib/format';
import { PAY_METHODS, REPAIR_STATUS } from '../lib/engine';
import { compatFor } from './Pos';

export function CustomersScreen({ navigation }: any) {
  const th = useTheme();
  const { db, bal, settings } = useStore();
  const [q, setQ] = useState('');
  const [form, setForm] = useState(false);
  const [f, setF] = useState('all');
  const s = normalizeDigits(q).toLowerCase();
  const list = db.customers.filter((c) => {
    if (c.deleted) return false;
    if (f === 'debt' && !((bal.cust[c.id] || 0) > 0.001)) return false;
    if (!s) return true;
    const devs = db.custDevices.filter((d) => d.customerId === c.id);
    return c.name.toLowerCase().includes(s) || c.phone.includes(s) || (c.phone2 || '').includes(s) || c.code.toLowerCase().includes(s) || devs.some((d) => (d.imei || '').includes(s) || (d.serial || '').toLowerCase().includes(s));
  });
  return (
    <Screen title="العملاء" subtitle={`${db.customers.filter((c) => !c.deleted).length} عميل`} onBack={() => navigation.goBack()}>
      <Guard perm="customers">
        <SearchBar value={q} onChangeText={setQ} placeholder="الاسم، الهاتف، IMEI، الرقم التسلسلي، الرمز" />
        <ChipRow>
          <Chip label="الكل" active={f === 'all'} onPress={() => setF('all')} />
          <Chip label="عليهم مستحقات" active={f === 'debt'} onPress={() => setF('debt')} />
        </ChipRow>
        <FlatList
          data={list}
          keyExtractor={(c) => c.id}
          contentContainerStyle={{ paddingVertical: 10, paddingBottom: 100 }}
          ListEmptyComponent={<Empty icon="people-outline" title="لا يوجد عملاء" sub="أضف عميلاً جديداً بالزر أدناه" />}
          renderItem={({ item: c }) => {
            const b = bal.cust[c.id] || 0;
            return (
              <Card onPress={() => navigation.navigate('CustomerDetail', { id: c.id })} style={{ marginBottom: 8 }}>
                <View style={[row, { gap: 12 }]}>
                  <Avatar name={c.name} />
                  <View style={{ flex: 1 }}>
                    <T v="bold">{c.name}</T>
                    <T v="small">{c.phone} · {c.code}</T>
                  </View>
                  {Math.abs(b) > 0.001 ? <Badge text={b > 0 ? `عليه ${money(b)}` : `له ${money(-b)}`} tone={b > 0 ? 'warn' : 'success'} /> : null}
                </View>
              </Card>
            );
          }}
        />
        <Fab icon="person-add" label="عميل" onPress={() => setForm(true)} />
        <CustomerForm visible={form} onClose={() => setForm(false)} onSaved={(c) => navigation.navigate('CustomerDetail', { id: c.id })} />
      </Guard>
    </Screen>
  );
}

export function CustomerDetailScreen({ navigation, route }: any) {
  const th = useTheme();
  const dlg = useDialog();
  const { db, bal, settings, commit, newId, user, stock, setCart } = useStore();
  const c = db.customers.find((x) => x.id === route.params.id);
  const [tab, setTab] = useState('devices');
  const [edit, setEdit] = useState(false);
  const [devForm, setDevForm] = useState<{ open: boolean; dev?: any }>({ open: false });
  const [pay, setPay] = useState(false);
  const [amt, setAmt] = useState('');
  const [method, setMethod] = useState('cash');
  const [merge, setMerge] = useState(false);
  const [sugg, setSugg] = useState<string | null>(null);
  if (!c) return <Screen title="عميل" onBack={() => navigation.goBack()}><Empty title="غير موجود" /></Screen>;
  const b = bal.cust[c.id] || 0;
  const devs = db.custDevices.filter((d) => d.customerId === c.id);
  const sales = [...db.sales].reverse().filter((s) => s.customerId === c.id);
  const repairs = [...db.repairs].reverse().filter((r) => r.customerId === c.id);
  const sugModel = db.custDevices.find((d) => d.id === sugg)?.modelId;

  const collect = () => {
    const a = num(amt);
    if (a <= 0) { dlg.alert('أدخل مبلغاً صحيحاً'); return; }
    commit('cash.add', { entry: { id: newId('cash-'), dir: 'in', method, amount: a, category: 'collection', party: { type: 'customer', id: c.id }, note: 'تحصيل من العميل' } }, `تحصيل ${money(a, settings.currency)} من ${c.name}`);
    setPay(false); setAmt('');
    dlg.toast('تم تسجيل التحصيل');
  };

  const doMerge = async (toId: string | null) => {
    if (!toId) return;
    const target = db.customers.find((x) => x.id === toId)!;
    const ok = await dlg.confirm('دمج العملاء', `سيتم نقل كل سجلات «${c.name}» إلى «${target.name}» وإخفاء السجل المكرر. العملية مسجلة في سجل التدقيق.`, { confirmText: 'دمج', danger: true });
    if (!ok) return;
    commit('customer.merge', { fromId: c.id, toId }, `دمج العميل ${c.name} في ${target.name}`);
    setMerge(false);
    navigation.replace('CustomerDetail', { id: toId });
  };

  return (
    <Screen title={c.name} subtitle={c.code} onBack={() => navigation.goBack()} right={<IconButton icon="create-outline" onPress={() => setEdit(true)} />}>
      <ScrollView contentContainerStyle={{ paddingBottom: 40 }} showsVerticalScrollIndicator={false}>
        <Card>
          <View style={[row, { gap: 12 }]}>
            <Avatar name={c.name} size={54} />
            <View style={{ flex: 1 }}>
              <T v="h3">{c.phone}</T>
              {c.phone2 ? <T v="sub">{c.phone2}</T> : null}
              {c.address ? <T v="small">{c.address}</T> : null}
            </View>
            <IconButton icon="call" color={th.success} onPress={() => Linking.openURL('tel:' + c.phone)} />
          </View>
          <Divider />
          <KV k="الرصيد" v={Math.abs(b) < 0.001 ? 'لا يوجد' : b > 0 ? `عليه ${money(b, settings.currency)}` : `له ${money(-b, settings.currency)}`} color={b > 0.001 ? th.warn : th.success} bold />
          {c.creditLimit ? <KV k="حد الائتمان" v={money(c.creditLimit, settings.currency)} /> : null}
          {c.category ? <KV k="التصنيف" v={c.category} /> : null}
          {c.notes ? <KV k="ملاحظات" v={c.notes} /> : null}
          <View style={[row, { gap: 8, marginTop: 8 }]}>
            <Btn flex small title="تحصيل دفعة" icon="cash" variant="success" onPress={() => { setAmt(b > 0 ? String(Math.round(b * 100) / 100) : ''); setPay(true); }} />
            <Btn flex small title="استلام جهاز" icon="construct" variant="soft" onPress={() => navigation.navigate('NewRepair', { customerId: c.id })} />
            <Btn small title="دمج" icon="git-merge" variant="ghost" onPress={() => setMerge(true)} />
          </View>
        </Card>

        <View style={{ height: 12 }} />
        <ChipRow>
          <Chip label={`الأجهزة (${devs.length})`} active={tab === 'devices'} onPress={() => setTab('devices')} />
          <Chip label={`الصيانة (${repairs.length})`} active={tab === 'repairs'} onPress={() => setTab('repairs')} />
          <Chip label={`المشتريات (${sales.length})`} active={tab === 'sales'} onPress={() => setTab('sales')} />
        </ChipRow>
        <View style={{ height: 8 }} />

        {tab === 'devices' ? (
          <>
            {devs.length === 0 ? <Empty icon="phone-portrait-outline" title="لا توجد أجهزة مسجلة" /> : null}
            {devs.map((d) => (
              <Card key={d.id} style={{ marginBottom: 8 }}>
                <View style={[row, { justifyContent: 'space-between' }]}>
                  <T v="bold">{deviceName(db, d)}</T>
                  <IconButton icon="create-outline" size={16} onPress={() => setDevForm({ open: true, dev: d })} />
                </View>
                <T v="small">{[d.imei && 'IMEI ' + d.imei, d.serial && 'S/N ' + d.serial, d.color, d.storage].filter(Boolean).join(' · ')}</T>
                <T v="small">إصلاحات سابقة: {db.repairs.filter((r) => r.deviceId === d.id).length}</T>
                {d.modelId ? <View style={{ marginTop: 6 }}><Btn small title={sugg === d.id ? 'إخفاء الملحقات' : 'ملحقات متوافقة'} icon="sparkles" variant="soft" onPress={() => setSugg(sugg === d.id ? null : d.id)} /></View> : null}
                {sugg === d.id && sugModel ? (
                  <View style={{ marginTop: 8 }}>
                    {compatFor(db, stock, sugModel).slice(0, 6).map(({ p, verified, avail }) => (
                      <View key={p.id} style={[row, { justifyContent: 'space-between', paddingVertical: 5 }]}>
                        <View style={{ flex: 1 }}><T numberOfLines={1}>{p.name}</T><T v="small">{verified ? 'موثّق' : 'يدوي'} · متوفر {avail}</T></View>
                        <Btn small title={money(p.price)} icon="add" variant="ghost" onPress={() => { setCart((cc) => ({ ...cc, customerId: c.id, lines: cc.lines.some((l) => l.productId === p.id) ? cc.lines.map((l) => (l.productId === p.id ? { ...l, qty: l.qty + 1 } : l)) : [...cc.lines, { productId: p.id, qty: 1, price: p.price, disc: 0 }] })); dlg.toast('أُضيف إلى سلة البيع'); }} />
                      </View>
                    ))}
                    {compatFor(db, stock, sugModel).length === 0 ? <T v="small">لا توجد ملحقات مرتبطة بهذا الموديل</T> : null}
                  </View>
                ) : null}
              </Card>
            ))}
            <Btn title="إضافة جهاز" icon="add" variant="ghost" onPress={() => setDevForm({ open: true })} />
          </>
        ) : null}

        {tab === 'repairs' ? (repairs.length === 0 ? <Empty icon="construct-outline" title="لا توجد عمليات صيانة" /> : repairs.map((r) => (
          <Card key={r.id} onPress={() => navigation.navigate('RepairDetail', { id: r.id })} style={{ marginBottom: 8 }}>
            <View style={[row, { justifyContent: 'space-between' }]}><T v="bold">{r.number}</T><Badge text={REPAIR_STATUS[r.status].label} tone={REPAIR_STATUS[r.status].tone} /></View>
            <T v="sub">{deviceName(db, db.custDevices.find((d) => d.id === r.deviceId))} · {fmtDate(r.received)}</T>
            <T v="small" numberOfLines={1}>{r.problem}</T>
          </Card>
        ))) : null}

        {tab === 'sales' ? (sales.length === 0 ? <Empty icon="receipt-outline" title="لا توجد مشتريات" /> : sales.map((s) => (
          <Card key={s.id} onPress={() => navigation.navigate('SaleDetail', { id: s.id })} style={{ marginBottom: 8 }}>
            <View style={[row, { justifyContent: 'space-between' }]}><T v="bold">{s.number}</T><T v="bold" color={th.primary}>{money(s.total, settings.currency)}</T></View>
            <T v="small">{fmtDate(s.ts)}{s.total - s.paid > 0.001 ? ` · متبقي ${money(s.total - s.paid)}` : ''}</T>
          </Card>
        ))) : null}
      </ScrollView>

      <CustomerForm visible={edit} onClose={() => setEdit(false)} customer={c} />
      <DeviceForm visible={devForm.open} device={devForm.dev} customerId={c.id} onClose={() => setDevForm({ open: false })} />
      <Sheet visible={pay} title="تحصيل دفعة" onClose={() => setPay(false)} footer={<Btn title="تأكيد التحصيل" icon="checkmark" variant="success" onPress={collect} />}>
        <Field label="المبلغ" value={amt} onChangeText={setAmt} keyboardType="decimal-pad" />
        <ChipRow>{Object.entries(PAY_METHODS).map(([k, v]) => <Chip key={k} label={v} active={method === k} onPress={() => setMethod(k)} />)}</ChipRow>
      </Sheet>
      <Sheet visible={merge} title="دمج مع عميل آخر" onClose={() => setMerge(false)} tall>
        <T v="sub" style={{ marginBottom: 10 }}>اختر العميل الذي ستُنقل إليه جميع السجلات.</T>
        <Picker label="العميل الهدف" value={null} options={db.customers.filter((x) => !x.deleted && x.id !== c.id).map((x) => ({ id: x.id, label: x.name, sub: x.phone }))} onSelect={doMerge} />
      </Sheet>
    </Screen>
  );
}
