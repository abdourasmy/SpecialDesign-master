import React, { useMemo, useState } from 'react';
import { FlatList, Pressable, ScrollView, View } from 'react-native';
import QRCode from 'react-native-qrcode-svg';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useTheme } from '../lib/theme';
import { useStore } from '../lib/store';
import { Badge, Btn, Card, Chip, ChipRow, Divider, Empty, Fab, Field, Guard, IconButton, KV, Picker, Screen, SearchBar, SectionTitle, Sheet, Stepper, Switch2, T, row, useDialog } from '../components/ui';
import { CustomerForm, DeviceForm, deviceName } from '../components/Forms';
import { DAY, fmtDate, fmtDateTime, money, normalizeDigits, num } from '../lib/format';
import { CLOSED_STATUSES, PAY_METHODS, REPAIR_STATUS, TRANSITIONS } from '../lib/engine';
import { Estimate, Repair, Sale, Warranty } from '../lib/types';
import { printHtml, repairHtml, shareText } from '../lib/invoice';
import { compatFor } from './Pos';
import { SafeAreaView } from 'react-native-safe-area-context';

export function RepairsScreen({ navigation }: any) {
  const th = useTheme();
  const { db, can } = useStore();
  const [q, setQ] = useState('');
  const [f, setF] = useState('open');
  const s = normalizeDigits(q).toLowerCase();
  const list = [...db.repairs].reverse().filter((r) => {
    if (f === 'open' && CLOSED_STATUSES.includes(r.status)) return false;
    if (f === 'late' && (CLOSED_STATUSES.includes(r.status) || r.expected > Date.now())) return false;
    if (f !== 'open' && f !== 'all' && f !== 'late' && r.status !== f) return false;
    if (!s) return true;
    const c = db.customers.find((x) => x.id === r.customerId);
    const d = db.custDevices.find((x) => x.id === r.deviceId);
    return r.number.toLowerCase().includes(s) || (c?.name || '').toLowerCase().includes(s) || (c?.phone || '').includes(s) || (d?.imei || '').includes(s) || (d?.serial || '').toLowerCase().includes(s);
  });
  return (
    <SafeAreaView style={{ flex: 1 }} edges={['top']}>
      <View style={{ flex: 1, paddingHorizontal: 16 }}>
        <View style={{ paddingVertical: 12 }}>
          <T v="h1">الصيانة</T>
          <T v="small">{db.repairs.filter((r) => !CLOSED_STATUSES.includes(r.status)).length} جهاز قيد المعالجة</T>
        </View>
        <Guard perm="repairs">
          <SearchBar value={q} onChangeText={setQ} placeholder="رقم الصيانة، العميل، الهاتف، IMEI" />
          <ChipRow>
            <Chip label="المفتوحة" active={f === 'open'} onPress={() => setF('open')} />
            <Chip label="متأخرة" active={f === 'late'} onPress={() => setF('late')} icon="alarm-outline" />
            <Chip label="جاهزة" active={f === 'ready'} onPress={() => setF('ready')} />
            <Chip label="بانتظار الموافقة" active={f === 'awaiting_approval'} onPress={() => setF('awaiting_approval')} />
            <Chip label="بانتظار القطع" active={f === 'waiting_parts'} onPress={() => setF('waiting_parts')} />
            <Chip label="الكل" active={f === 'all'} onPress={() => setF('all')} />
          </ChipRow>
          <FlatList
            data={list}
            keyExtractor={(r) => r.id}
            contentContainerStyle={{ paddingVertical: 10, paddingBottom: 100 }}
            ListEmptyComponent={<Empty icon="construct-outline" title="لا توجد أوامر صيانة" sub="استلم جهازاً جديداً لبدء أمر صيانة" />}
            renderItem={({ item: r }) => {
              const c = db.customers.find((x) => x.id === r.customerId);
              const st = REPAIR_STATUS[r.status];
              const late = !CLOSED_STATUSES.includes(r.status) && r.expected < Date.now();
              return (
                <Card onPress={() => navigation.navigate('RepairDetail', { id: r.id })} style={{ marginBottom: 8 }}>
                  <View style={[row, { justifyContent: 'space-between' }]}>
                    <T v="bold">{r.number}</T>
                    <Badge text={st.label} tone={st.tone} icon={st.icon as any} />
                  </View>
                  <T v="body" style={{ marginTop: 4 }}>{deviceName(db, db.custDevices.find((d) => d.id === r.deviceId))}</T>
                  <T v="sub" numberOfLines={1}>{r.problem}</T>
                  <View style={[row, { justifyContent: 'space-between', marginTop: 6 }]}>
                    <T v="small">{c?.name} · {c?.phone}</T>
                    <T v="small" color={late ? th.danger : th.sub}>{late ? 'متأخر · ' : 'التسليم '}{fmtDate(r.expected)}</T>
                  </View>
                </Card>
              );
            }}
          />
          {can('repairs.manage') || can('repairs') ? <Fab icon="add" label="استلام جهاز" onPress={() => navigation.navigate('NewRepair')} /> : null}
        </Guard>
      </View>
    </SafeAreaView>
  );
}

const COND = ['سليم', 'خدوش', 'مكسور', 'لا يعمل'];
const ACCS = ['شريحة SIM', 'بطاقة SD', 'جراب', 'شاحن', 'كابل', 'علبة الجهاز'];

export function NewRepairScreen({ navigation, route }: any) {
  const th = useTheme();
  const dlg = useDialog();
  const { db, commit, newId, nextNumber, settings, user } = useStore();
  const [customerId, setCustomerId] = useState<string | null>(route.params?.customerId || null);
  const [deviceId, setDeviceId] = useState<string | null>(null);
  const [problem, setProblem] = useState('');
  const [screen, setScreen] = useState('سليم');
  const [body, setBody] = useState('سليم');
  const [buttons, setButtons] = useState('سليم');
  const [water, setWater] = useState('لا يوجد');
  const [accs, setAccs] = useState<string[]>([]);
  const [accNote, setAccNote] = useState('');
  const [notes, setNotes] = useState('');
  const [deposit, setDeposit] = useState('');
  const [method, setMethod] = useState('cash');
  const [days, setDays] = useState(3);
  const [tech, setTech] = useState<string | null>(null);
  const [ack, setAck] = useState(false);
  const [custForm, setCustForm] = useState(false);
  const [devForm, setDevForm] = useState(false);

  const custOpts = db.customers.filter((c) => !c.deleted).map((c) => ({ id: c.id, label: c.name, sub: c.phone }));
  const devs = db.custDevices.filter((d) => d.customerId === customerId);
  const techs = db.staff.filter((s) => s.active && ['technician', 'manager', 'owner'].includes(s.role));

  const save = () => {
    if (!customerId) { dlg.alert('اختر العميل أو أضف عميلاً جديداً'); return; }
    if (!deviceId) { dlg.alert('اختر الجهاز أو سجّل جهازاً جديداً'); return; }
    if (!problem.trim()) { dlg.alert('اكتب العطل المبلغ عنه'); return; }
    if (!ack) { dlg.alert('إقرار العميل مطلوب', 'يجب تأكيد قبول العميل لإخلاء مسؤولية فقدان البيانات.'); return; }
    const id = newId('rep-');
    const number = nextNumber('repair');
    const dep = Math.max(0, num(deposit));
    const repair: Repair = {
      id, number, customerId, deviceId, problem: problem.trim(),
      check: { screen, body, buttons, water, accessories: [...accs, accNote.trim()].filter(Boolean).join('، '), notes },
      received: Date.now(), expected: Date.now() + days * DAY, deposit: dep, disclaimer: true, technicianId: tech || undefined,
      status: 'received', history: [{ status: 'received', ts: Date.now(), userId: user.id, note: 'استلام الجهاز' }], estimates: [], parts: [], userId: user.id, wh: settings.defaultWh,
    };
    commit('repair.create', { repair, method }, `استلام جهاز للصيانة ${number}`);
    dlg.toast(`تم إنشاء أمر الصيانة ${number}`);
    navigation.replace('RepairDetail', { id });
  };

  const condRow = (label: string, v: string, set: (s: string) => void, opts = COND) => (
    <View style={{ marginBottom: 10 }}>
      <T v="sub" style={{ marginBottom: 5, fontWeight: '600' }}>{label}</T>
      <ChipRow>{opts.map((o) => <Chip key={o} label={o} active={v === o} onPress={() => set(o)} />)}</ChipRow>
    </View>
  );

  return (
    <Screen title="استلام جهاز" subtitle="أمر صيانة جديد" onBack={() => navigation.goBack()}>
      <ScrollView contentContainerStyle={{ paddingBottom: 40 }} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
        <Card>
          <Picker label="العميل" value={customerId} options={custOpts} onSelect={(id) => { setCustomerId(id); setDeviceId(null); }} placeholder="اختر عميلاً..." icon="person-outline" />
          <Btn small title="عميل جديد" icon="person-add" variant="soft" onPress={() => setCustForm(true)} />
          <View style={{ height: 14 }} />
          {customerId ? (
            <>
              <Picker label="الجهاز" value={deviceId} options={devs.map((d) => ({ id: d.id, label: deviceName(db, d), sub: [d.imei, d.serial].filter(Boolean).join(' · ') }))} onSelect={setDeviceId} placeholder={devs.length ? 'اختر جهاز العميل...' : 'لا توجد أجهزة، سجّل جهازاً'} icon="phone-portrait-outline" />
              <Btn small title="جهاز جديد" icon="add" variant="soft" onPress={() => setDevForm(true)} />
            </>
          ) : <T v="small">اختر العميل أولاً لعرض أجهزته</T>}
        </Card>

        <SectionTitle title="العطل والفحص الأولي" />
        <Card>
          <Field label="العطل المبلغ عنه *" value={problem} onChangeText={setProblem} multiline placeholder="مثال: الشاشة لا تعمل بعد السقوط" />
          {condRow('الشاشة', screen, setScreen)}
          {condRow('الهيكل والخلفية', body, setBody)}
          {condRow('الأزرار والمنافذ', buttons, setButtons, ['سليمة', 'بعضها معطل', 'متضررة'])}
          {condRow('مؤشرات المياه', water, setWater, ['لا يوجد', 'يوجد أثر', 'مشبّع بالماء'])}
          <T v="sub" style={{ marginBottom: 5, fontWeight: '600' }}>الملحقات المستلمة</T>
          <ChipRow>{ACCS.map((a) => <Chip key={a} label={a} active={accs.includes(a)} onPress={() => setAccs(accs.includes(a) ? accs.filter((x) => x !== a) : [...accs, a])} />)}</ChipRow>
          <View style={{ height: 10 }} />
          <Field label="ملحقات أخرى" value={accNote} onChangeText={setAccNote} />
          <Field label="ملاحظات العميل" value={notes} onChangeText={setNotes} multiline />
        </Card>

        <SectionTitle title="الموعد والعربون" />
        <Card>
          <T v="sub" style={{ marginBottom: 5, fontWeight: '600' }}>مدة الإصلاح المتوقعة</T>
          <ChipRow>{[1, 2, 3, 5, 7, 14].map((d) => <Chip key={d} label={d === 1 ? 'يوم' : `${d} أيام`} active={days === d} onPress={() => setDays(d)} />)}</ChipRow>
          <T v="small" style={{ marginTop: 6, marginBottom: 12 }}>التسليم المتوقع: {fmtDate(Date.now() + days * DAY)}</T>
          <Field label={`عربون مستلم (${settings.currency})`} value={deposit} onChangeText={setDeposit} keyboardType="decimal-pad" placeholder="0" />
          {num(deposit) > 0 ? <ChipRow>{Object.entries(PAY_METHODS).map(([k, v]) => <Chip key={k} label={v} active={method === k} onPress={() => setMethod(k)} />)}</ChipRow> : null}
          <View style={{ height: 12 }} />
          <Picker label="الفني المسؤول" value={tech} options={techs.map((t) => ({ id: t.id, label: t.name }))} onSelect={setTech} allowClear searchable={false} placeholder="غير محدد" />
        </Card>

        <View style={{ height: 12 }} />
        <Card style={{ borderColor: th.warn }}>
          <Switch2 value={ack} onChange={setAck} label="أقرّ العميل بأن المركز غير مسؤول عن فقدان البيانات أثناء الصيانة، ووافق على شروط الاستلام." />
        </Card>
        <View style={{ height: 14 }} />
        <Btn title="حفظ وإنشاء أمر الصيانة" icon="checkmark-circle" onPress={save} />
      </ScrollView>
      <CustomerForm visible={custForm} onClose={() => setCustForm(false)} onSaved={(c) => { setCustomerId(c.id); setDeviceId(null); }} />
      {customerId ? <DeviceForm visible={devForm} customerId={customerId} onClose={() => setDevForm(false)} onSaved={(d) => setDeviceId(d.id)} /> : null}
    </Screen>
  );
}

export function RepairDetailScreen({ navigation, route }: any) {
  const th = useTheme();
  const dlg = useDialog();
  const ctx = useStore();
  const { db, settings, commit, newId, nextNumber, can, user, stock, bal } = ctx;
  const r = db.repairs.find((x) => x.id === route.params.id);
  const [estOpen, setEstOpen] = useState(false);
  const [partOpen, setPartOpen] = useState(false);
  const [delOpen, setDelOpen] = useState(false);
  const [decide, setDecide] = useState<{ estId: string; approved: boolean } | null>(null);
  const [method, setMethod] = useState('حضوري');
  const [note, setNote] = useState('');
  // estimate form
  const [diag, setDiag] = useState('');
  const [rec, setRec] = useState('');
  const [labor, setLabor] = useState('');
  const [eDays, setEDays] = useState('1');
  const [eParts, setEParts] = useState<Estimate['parts']>([]);
  const [pickPart, setPickPart] = useState<string | null>(null);
  // part
  const [partId, setPartId] = useState<string | null>(null);
  const [partQty, setPartQty] = useState(1);
  // deliver
  const [finalLabor, setFinalLabor] = useState('');
  const [payNow, setPayNow] = useState('');
  const [payMethod, setPayMethod] = useState('cash');
  const [recipient, setRecipient] = useState('');
  const [warDays, setWarDays] = useState('30');

  if (!r) return <Screen title="صيانة" onBack={() => navigation.goBack()}><Empty title="أمر الصيانة غير موجود" /></Screen>;
  const cust = db.customers.find((c) => c.id === r.customerId);
  const dev = db.custDevices.find((d) => d.id === r.deviceId);
  const st = REPAIR_STATUS[r.status];
  const closed = CLOSED_STATUSES.includes(r.status);
  const manage = can('repairs.manage');
  const next = TRANSITIONS[r.status] || [];
  const approvedEst = [...r.estimates].reverse().find((e) => e.approval?.approved);
  const lastEst = r.estimates[r.estimates.length - 1];
  const partsTotal = r.parts.reduce((a, p) => a + p.qty * p.price, 0);
  const deposits = db.cash.filter((c) => c.ref === r.id && c.category === 'repair_deposit').reduce((a, c) => a + c.amount, 0);
  const techName = db.staff.find((s) => s.id === r.technicianId)?.name;
  const physical = db.products.filter((p) => !p.deleted && p.kind === 'product');
  const compat = dev?.modelId ? compatFor(db, stock, dev.modelId) : [];
  const compatIds = new Set(compat.map((c) => c.p.id));

  const changeStatus = async (s: string) => {
    if (s === 'delivered') {
      setFinalLabor(String(approvedEst ? approvedEst.labor : r.status === 'ready' ? (lastEst?.labor ?? 0) : 0));
      setPayNow(''); setRecipient(cust?.name || ''); setDelOpen(true);
      return;
    }
    const label = REPAIR_STATUS[s].label;
    const needConfirm = ['cancelled', 'abandoned', 'unrepairable', 'rejected'].includes(s);
    if (needConfirm) {
      const ok = await dlg.confirm(`تغيير الحالة إلى «${label}»`, 'سيُسجَّل التغيير في سجل الحالة ولا يمكن التراجع عنه.', { confirmText: 'تأكيد', danger: true });
      if (!ok) return;
    }
    if (s === 'awaiting_approval' && r.estimates.length === 0) { dlg.alert('أضف تقدير تكلفة أولاً', 'لا يمكن طلب موافقة العميل بدون تقدير.'); return; }
    commit('repair.status', { id: r.id, status: s }, `${r.number}: ${label}`);
  };

  const addEstPart = () => {
    const p = db.products.find((x) => x.id === pickPart);
    if (!p) return;
    setEParts((arr) => {
      const i = arr.findIndex((x) => x.productId === p.id);
      return i >= 0 ? arr.map((x, k) => (k === i ? { ...x, qty: x.qty + 1 } : x)) : [...arr, { productId: p.id, name: p.name, qty: 1, price: p.price }];
    });
    setPickPart(null);
  };
  const estTotal = eParts.reduce((a, p) => a + p.qty * p.price, 0) + num(labor);

  const saveEst = () => {
    if (!diag.trim()) { dlg.alert('اكتب التشخيص الفني'); return; }
    const est: Estimate = { id: newId('est-'), diagnosis: diag.trim(), recommended: rec.trim(), parts: eParts, labor: num(labor), total: estTotal, days: Math.max(1, num(eDays)), ts: Date.now(), userId: user.id };
    commit('repair.estimate', { id: r.id, est }, `${r.number}: تقدير جديد ${money(estTotal, settings.currency)}`);
    setEstOpen(false); setDiag(''); setRec(''); setLabor(''); setEParts([]);
    dlg.toast('تم حفظ التقدير (النسخ السابقة محفوظة)');
  };

  const doDecide = () => {
    if (!decide) return;
    commit('repair.decide', { id: r.id, estId: decide.estId, approved: decide.approved, method }, `${r.number}: ${decide.approved ? 'موافقة' : 'رفض'} العميل على التقدير`);
    setDecide(null);
  };

  const addPart = async (pid: string | null, qty: number) => {
    const p = db.products.find((x) => x.id === pid);
    if (!p) { dlg.alert('اختر القطعة'); return; }
    const avail = stock[p.id]?.byWh[r.wh] || 0;
    if (qty > avail) {
      const ok = await dlg.confirm('الكمية تتجاوز المتاح', `المتاح محلياً ${Math.max(0, avail)} فقط. سيُسجَّل الصرف وقد يظهر عجز يحتاج مراجعة.`, { confirmText: 'صرف رغم ذلك' });
      if (!ok) return;
    }
    commit('repair.part', { id: r.id, productId: p.id, name: p.name, qty, price: p.price, cost: p.cost }, `${r.number}: صرف ${qty} × ${p.name}`);
    setPartOpen(false); setPartId(null); setPartQty(1);
  };
  const returnPart = (pid: string) => {
    const part = r.parts.find((x) => x.productId === pid);
    if (!part) return;
    commit('repair.part', { id: r.id, productId: pid, name: part.name, qty: -1, price: part.price, cost: part.cost }, `${r.number}: إرجاع قطعة ${part.name} للمخزون`);
  };

  const labN = num(finalLabor);
  const total = partsTotal + labN;
  const due = Math.max(0, total - deposits);
  const refundDue = Math.max(0, deposits - total);
  const payN = payNow === '' ? due : num(payNow);

  const deliver = () => {
    if (!recipient.trim()) { dlg.alert('اسم المستلم مطلوب'); return; }
    const pn = Math.min(payN, due);
    if (due - pn > 0.001 && !cust) { dlg.alert('لا يمكن ترك رصيد'); return; }
    const sid = newId('sale-');
    const number = nextNumber('sale');
    const lines = r.parts.map((p) => ({ productId: p.productId, name: p.name, qty: p.qty, price: p.price, cost: p.cost, disc: 0, noStock: true }));
    if (labN > 0) lines.push({ productId: 'labor', name: 'أجور الصيانة (يد عاملة)', qty: 1, price: labN, cost: 0, disc: 0, noStock: true });
    const payments = [] as Sale['payments'];
    const prepaid = Math.min(deposits, total);
    if (prepaid > 0) payments.push({ method: 'cash', amount: prepaid, prepaid: true });
    if (pn > 0) payments.push({ method: payMethod, amount: pn });
    const sale: Sale | null = total > 0 ? {
      id: sid, number, kind: 'repair', customerId: r.customerId, wh: r.wh, lines, subtotal: total, discount: 0, taxRate: 0, tax: 0, total,
      payments, paid: payments.reduce((a, p) => a + p.amount, 0), ts: Date.now(), userId: user.id, repairId: r.id,
    } : null;
    const wd = Math.max(0, Math.round(num(warDays)));
    const warranties: Warranty[] = [];
    if (sale && wd > 0 && ['ready'].includes(r.status)) {
      warranties.push({
        id: sid + ':w', number: nextNumber('warranty'), sourceType: 'repair', sourceId: r.id, sourceNumber: r.number, customerId: r.customerId,
        item: `إصلاح ${deviceName(db, dev)}`, serial: dev?.imei || dev?.serial, start: Date.now(), days: wd, expiry: Date.now() + wd * DAY,
        covers: r.parts.length ? 'القطع المستبدلة: ' + r.parts.map((p) => p.name).join('، ') : 'العطل المُصلَح', conditions: 'لا يشمل الكسر أو السوائل أو سوء الاستخدام',
      });
    }
    commit('repair.deliver', { id: r.id, sale, warranties, recipient: recipient.trim(), warrantyDays: wd }, `${r.number}: تسليم الجهاز${sale ? ' بفاتورة ' + number : ''}`);
    setDelOpen(false);
    dlg.toast('تم تسليم الجهاز');
  };

  const receipt = () => printHtml(repairHtml(db, r, settings));

  return (
    <Screen title={r.number} subtitle={deviceName(db, dev)} onBack={() => navigation.goBack()} right={<IconButton icon="print-outline" onPress={receipt} />}>
      <ScrollView contentContainerStyle={{ paddingBottom: 50 }} showsVerticalScrollIndicator={false}>
        <Card>
          <View style={[row, { justifyContent: 'space-between', alignItems: 'flex-start' }]}>
            <View style={{ flex: 1, gap: 8 }}>
              <Badge text={st.label} tone={st.tone} icon={st.icon as any} />
              <Pressable onPress={() => cust && navigation.navigate('CustomerDetail', { id: cust.id })}>
                <T v="h3">{cust?.name}</T>
                <T v="sub">{cust?.phone}</T>
              </Pressable>
              <T v="small">استلام {fmtDateTime(r.received)}</T>
              <T v="small" color={!closed && r.expected < Date.now() ? th.danger : th.sub}>التسليم المتوقع {fmtDate(r.expected)}</T>
            </View>
            <View style={{ backgroundColor: '#fff', padding: 8, borderRadius: 12 }}>
              <QRCode value={`RCM|${r.number}`} size={84} />
            </View>
          </View>
        </Card>

        {!closed && manage ? (
          <>
            <SectionTitle title="تحديث الحالة" />
            <ChipRow>
              {next.map((s) => <Chip key={s} label={REPAIR_STATUS[s].label} icon={REPAIR_STATUS[s].icon as any} onPress={() => changeStatus(s)} />)}
            </ChipRow>
            {r.status === 'awaiting_approval' && lastEst && !lastEst.approval ? (
              <View style={[row, { gap: 8, marginTop: 10 }]}>
                <Btn flex title="موافقة العميل" icon="checkmark-circle" variant="success" onPress={() => setDecide({ estId: lastEst.id, approved: true })} />
                <Btn flex title="رفض العميل" icon="close-circle" variant="danger" onPress={() => setDecide({ estId: lastEst.id, approved: false })} />
              </View>
            ) : null}
          </>
        ) : null}
        
        <SectionTitle title="تفاصيل الجهاز والعطل" />
        <Card>
          <KV k="الجهاز" v={deviceName(db, dev)} />
          {dev?.imei ? <KV k="IMEI" v={dev.imei} /> : null}
          {dev?.serial ? <KV k="الرقم التسلسلي" v={dev.serial} /> : null}
          <KV k="العطل" v={r.problem} />
          <Divider />
          <KV k="الشاشة" v={r.check.screen} />
          <KV k="الهيكل" v={r.check.body} />
          <KV k="الأزرار والمنافذ" v={r.check.buttons} />
          <KV k="المياه" v={r.check.water} />
          <KV k="الملحقات المستلمة" v={r.check.accessories || 'لا يوجد'} />
          {r.check.notes ? <KV k="ملاحظات" v={r.check.notes} /> : null}
          <KV k="الفني" v={techName || 'غير محدد'} />
          <KV k="العربون" v={money(deposits, settings.currency)} />
        </Card>

        <SectionTitle title="تقدير التكلفة" right={!closed && manage ? <Btn small title="تقدير جديد" icon="add" variant="soft" onPress={() => setEstOpen(true)} /> : undefined} />
        {r.estimates.length === 0 ? <Card><T v="sub">لا توجد تقديرات بعد</T></Card> : [...r.estimates].reverse().map((e, idx) => (
          <Card key={e.id} style={{ marginBottom: 8, opacity: idx === 0 ? 1 : 0.75 }}>
            <View style={[row, { justifyContent: 'space-between' }]}>
              <T v="bold">{money(e.total, settings.currency)}</T>
              {e.approval ? <Badge text={e.approval.approved ? `موافقة (${e.approval.method})` : 'مرفوض'} tone={e.approval.approved ? 'success' : 'danger'} /> : <Badge text={idx === 0 ? 'بانتظار القرار' : 'نسخة سابقة'} tone="warn" />}
            </View>
            <T v="sub">{e.diagnosis}</T>
            {e.recommended ? <T v="small">الإصلاح المقترح: {e.recommended}</T> : null}
            <T v="small">{e.parts.map((p) => `${p.name} ×${p.qty}`).join('، ')}{e.parts.length ? ' · ' : ''}أجور {money(e.labor)} · {e.days} يوم · {fmtDate(e.ts)}</T>
          </Card>
        ))}

        <SectionTitle title="القطع المصروفة" right={!closed && manage ? <Btn small title="صرف قطعة" icon="add" variant="soft" onPress={() => setPartOpen(true)} /> : undefined} />
        <Card>
          {r.parts.length === 0 ? <T v="sub">لم تُصرف قطع من المخزون</T> : r.parts.map((p) => (
            <View key={p.productId} style={[row, { justifyContent: 'space-between', paddingVertical: 6, gap: 8 }]}>
              <View style={{ flex: 1 }}><T v="bold">{p.name}</T><T v="small">{p.qty} × {money(p.price)}</T></View>
              <T v="bold">{money(p.qty * p.price)}</T>
              {!closed && manage ? <IconButton icon="return-down-back" size={16} onPress={() => returnPart(p.productId)} /> : null}
            </View>
          ))}
          {r.parts.length ? <><Divider /><KV k="إجمالي القطع" v={money(partsTotal, settings.currency)} bold /></> : null}
        </Card>

        {compat.length > 0 && !closed ? (
          <>
            <SectionTitle title="ملحقات وقطع متوافقة مع الجهاز" />
            <Card>
              {compat.slice(0, 6).map(({ p, verified, avail }) => (
                <View key={p.id} style={[row, { justifyContent: 'space-between', paddingVertical: 6, gap: 8 }]}>
                  <View style={{ flex: 1 }}><T numberOfLines={1}>{p.name}</T><T v="small">{verified ? 'توافق موثّق' : 'توافق يدوي'} · متوفر {avail} · {money(p.price)}</T></View>
                  {manage && p.category === 'قطع غيار' ? <Btn small title="صرف" variant="ghost" onPress={() => addPart(p.id, 1)} /> : null}
                </View>
              ))}
            </Card>
          </>
        ) : null}

        <SectionTitle title="سجل الحالات" />
        <Card>
          {[...r.history].reverse().map((h, i) => (
            <View key={i} style={[row, { gap: 10, paddingVertical: 6, alignItems: 'flex-start' }]}>
              <Ionicons name={REPAIR_STATUS[h.status].icon as any} size={18} color={th.primary} />
              <View style={{ flex: 1 }}>
                <T v="bold">{REPAIR_STATUS[h.status].label}</T>
                <T v="small">{fmtDateTime(h.ts)} · {db.staff.find((s) => s.id === h.userId)?.name}{h.note ? ' · ' + h.note : ''}</T>
              </View>
            </View>
          ))}
        </Card>

        {r.saleId ? <View style={{ marginTop: 14 }}><Btn title="عرض فاتورة الصيانة" icon="receipt" variant="soft" onPress={() => navigation.navigate('SaleDetail', { id: r.saleId })} /></View> : null}
        <View style={[row, { gap: 8, marginTop: 10 }]}>
          <Btn flex title="إيصال الاستلام" icon="print" variant="ghost" onPress={receipt} />
          <Btn flex title="مشاركة" icon="share-social" variant="ghost" onPress={async () => { const x = await shareText(`${settings.businessName}\nأمر صيانة ${r.number}\n${deviceName(db, dev)}\nالحالة: ${st.label}\nالتسليم المتوقع: ${fmtDate(r.expected)}`, r.number); if (x === 'copied') dlg.toast('تم النسخ'); }} />
        </View>
      </ScrollView>

      {/* Estimate */}
      <Sheet visible={estOpen} title="تقدير تكلفة جديد" onClose={() => setEstOpen(false)} tall footer={<Btn title={`حفظ التقدير (${money(estTotal, settings.currency)})`} icon="checkmark" onPress={saveEst} />}>
        <Field label="التشخيص الفني *" value={diag} onChangeText={setDiag} multiline />
        <Field label="الإصلاح الموصى به" value={rec} onChangeText={setRec} />
        <Picker label="إضافة قطعة مطلوبة" value={pickPart} options={physical.map((p) => ({ id: p.id, label: p.name, sub: p.category, right: money(p.price) }))} onSelect={(id) => setPickPart(id)} placeholder="اختر قطعة..." />
        {pickPart ? <View style={{ marginBottom: 10 }}><Btn small title="إضافة للتقدير" icon="add" onPress={addEstPart} /></View> : null}
        {eParts.map((p, i) => (
          <View key={p.productId} style={[row, { justifyContent: 'space-between', paddingVertical: 4 }]}>
            <T style={{ flex: 1 }} numberOfLines={1}>{p.name}</T>
            <Stepper value={p.qty} min={0} onChange={(n) => setEParts((arr) => arr.map((x, k) => (k === i ? { ...x, qty: n } : x)).filter((x) => x.qty > 0))} />
          </View>
        ))}
        <View style={{ height: 8 }} />
        <View style={[row, { gap: 10 }]}>
          <Field style={{ flex: 1 }} label="أجور العمل" value={labor} onChangeText={setLabor} keyboardType="decimal-pad" />
          <Field style={{ flex: 1 }} label="المدة (أيام)" value={eDays} onChangeText={setEDays} keyboardType="number-pad" />
        </View>
      </Sheet>

      {/* Decision */}
      <Sheet visible={!!decide} title={decide?.approved ? 'تسجيل موافقة العميل' : 'تسجيل رفض العميل'} onClose={() => setDecide(null)} footer={<Btn title="تأكيد" icon="checkmark" variant={decide?.approved ? 'success' : 'danger'} onPress={doDecide} />}>
        <T v="sub" style={{ marginBottom: 8 }}>طريقة أخذ القرار</T>
        <ChipRow>{['حضوري', 'هاتفياً', 'رسالة', 'أخرى'].map((m) => <Chip key={m} label={m} active={method === m} onPress={() => setMethod(m)} />)}</ChipRow>
      </Sheet>

      {/* Add part */}
      <Sheet visible={partOpen} title="صرف قطعة من المخزون" onClose={() => setPartOpen(false)} footer={<Btn title="تأكيد الصرف" icon="checkmark" onPress={() => addPart(partId, partQty)} />}>
        <Picker label="القطعة" value={partId} options={[...physical].sort((a, b) => Number(compatIds.has(b.id)) - Number(compatIds.has(a.id))).map((p) => ({ id: p.id, label: p.name, sub: `${compatIds.has(p.id) ? 'متوافق · ' : ''}متوفر ${stock[p.id]?.byWh[r.wh] || 0}`, right: money(p.price) }))} onSelect={setPartId} />
        <View style={[row, { justifyContent: 'space-between' }]}><T>الكمية</T><Stepper value={partQty} min={1} onChange={setPartQty} /></View>
        <T v="small" style={{ marginTop: 10 }}>يُسجَّل الصرف كحركة مخزون ولا يمكن تعديلها؛ التصحيح يتم بإرجاع القطعة.</T>
      </Sheet>

      {/* Deliver */}
      <Sheet visible={delOpen} title="تسليم الجهاز" onClose={() => setDelOpen(false)} tall footer={<Btn title="تأكيد التسليم" icon="gift" variant="success" onPress={deliver} />}>
        <Card style={{ marginBottom: 12 }}>
          <KV k="قطع مصروفة" v={money(partsTotal, settings.currency)} />
          <Field label="أجور الصيانة النهائية" value={finalLabor} onChangeText={setFinalLabor} keyboardType="decimal-pad" style={{ marginTop: 6 }} />
          <KV k="الإجمالي" v={money(total, settings.currency)} bold />
          <KV k="العربون المدفوع" v={money(deposits, settings.currency)} />
          <KV k="المستحق الآن" v={money(due, settings.currency)} color={due > 0 ? th.warn : th.success} bold />
          {refundDue > 0 ? <T v="small" color={th.success}>يبقى للعميل رصيد دائن {money(refundDue, settings.currency)} (يمكن ردّه من الصندوق)</T> : null}
        </Card>
        {due > 0 ? (
          <>
            <Field label="المبلغ المدفوع الآن" value={payNow} onChangeText={setPayNow} keyboardType="decimal-pad" placeholder={String(due)} hint="ما يتبقى يُسجَّل ذمة على العميل" />
            <ChipRow>{Object.entries(PAY_METHODS).map(([k, v]) => <Chip key={k} label={v} active={payMethod === k} onPress={() => setPayMethod(k)} />)}</ChipRow>
            <View style={{ height: 12 }} />
          </>
        ) : null}
        <Field label="اسم المستلم *" value={recipient} onChangeText={setRecipient} />
        {r.status === 'ready' ? <Field label="مدة الضمان (أيام)" value={warDays} onChangeText={setWarDays} keyboardType="number-pad" hint="0 = بدون ضمان" /> : null}
      </Sheet>
    </Screen>
  );
}
