import React, { useState } from 'react';
import { FlatList, Pressable, ScrollView, View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useTheme } from '../lib/theme';
import { saleSyncState, useStore } from '../lib/store';
import { Badge, Btn, Card, Chip, ChipRow, Divider, Empty, Field, Guard, KV, Screen, SearchBar, SectionTitle, Sheet, Stepper, SyncBadge, T, row, useDialog, Switch2 } from '../components/ui';
import { fmtDateTime, money, num } from '../lib/format';
import { PAY_METHODS } from '../lib/engine';
import { printHtml, saleHtml, saleText, shareText } from '../lib/invoice';

export function SalesScreen({ navigation }: any) {
  const th = useTheme();
  const ctx = useStore();
  const { db, settings } = ctx;
  const [q, setQ] = useState('');
  const [f, setF] = useState('all');
  const list = [...db.sales].reverse().filter((s) => {
    const c = db.customers.find((x) => x.id === s.customerId);
    if (q && !(s.number.toLowerCase().includes(q.toLowerCase()) || (c?.name || '').includes(q) || (c?.phone || '').includes(q))) return false;
    if (f === 'debt') return s.total - s.paid > 0.001;
    if (f === 'review') return saleSyncState(ctx, s.id, s.opId) === 'needs_review';
    if (f === 'repair') return s.kind === 'repair';
    return true;
  });
  return (
    <Screen title="سجل المبيعات" subtitle={`${db.sales.length} فاتورة`} onBack={() => navigation.goBack()}>
      <Guard perm="sales">
        <SearchBar value={q} onChangeText={setQ} placeholder="رقم الفاتورة أو اسم العميل" />
        <ChipRow>
          <Chip label="الكل" active={f === 'all'} onPress={() => setF('all')} />
          <Chip label="غير مسددة" active={f === 'debt'} onPress={() => setF('debt')} />
          <Chip label="فواتير صيانة" active={f === 'repair'} onPress={() => setF('repair')} />
          <Chip label="تحتاج مراجعة" active={f === 'review'} onPress={() => setF('review')} />
        </ChipRow>
        <FlatList
          data={list}
          keyExtractor={(s) => s.id}
          contentContainerStyle={{ paddingVertical: 10, paddingBottom: 40 }}
          ListEmptyComponent={<Empty icon="receipt-outline" title="لا توجد فواتير" sub="ستظهر هنا فواتير البيع والصيانة" />}
          renderItem={({ item: s }) => {
            const c = db.customers.find((x) => x.id === s.customerId);
            const st = saleSyncState(ctx, s.id, s.opId);
            return (
              <Card onPress={() => navigation.navigate('SaleDetail', { id: s.id })} style={{ marginBottom: 8 }}>
                <View style={[row, { justifyContent: 'space-between' }]}>
                  <T v="bold">{s.number}</T>
                  <T v="h3" color={th.primary}>{money(s.total, settings.currency)}</T>
                </View>
                <T v="sub">{c ? c.name : 'عميل نقدي'} · {fmtDateTime(s.ts)}</T>
                <View style={[row, { gap: 6, marginTop: 6, flexWrap: 'wrap' }]}>
                  <SyncBadge state={st} />
                  {s.kind === 'repair' ? <Badge text="صيانة" tone="info" icon="construct" /> : null}
                  {s.total - s.paid > 0.001 ? <Badge text={`متبقي ${money(s.total - s.paid)}`} tone="warn" /> : <Badge text="مسددة" tone="success" />}
                </View>
              </Card>
            );
          }}
        />
      </Guard>
    </Screen>
  );
}

export function SaleDetailScreen({ navigation, route }: any) {
  const th = useTheme();
  const dlg = useDialog();
  const ctx = useStore();
  const { db, settings, commit, newId, can } = ctx;
  const sale = db.sales.find((s) => s.id === route.params.id);
  const [retOpen, setRetOpen] = useState(false);
  const [qty, setQty] = useState<Record<number, number>>({});
  const [restock, setRestock] = useState(true);
  const [method, setMethod] = useState('cash');
  const [refundStr, setRefundStr] = useState('');
  const [reason, setReason] = useState('');

  if (!sale) return <Screen title="فاتورة" onBack={() => navigation.goBack()}><Empty title="الفاتورة غير موجودة" /></Screen>;
  const cust = db.customers.find((c) => c.id === sale.customerId);
  const returns = db.returns.filter((r) => r.saleId === sale.id);
  const returnedQty = (pid: string) => returns.reduce((a, r) => a + r.lines.filter((l) => l.productId === pid).reduce((x, l) => x + l.qty, 0), 0);
  const ratio = sale.subtotal ? sale.total / sale.subtotal : 1;
  const retValue = sale.lines.reduce((a, l, i) => a + ((qty[i] || 0) * ((l.price * l.qty - l.disc) / l.qty)) * ratio, 0);
  const retTotal = returns.reduce((a, r) => a + r.value, 0);
  const st = saleSyncState(ctx, sale.id, sale.opId);
  const refundAmt = refundStr === '' ? retValue : num(refundStr);

  const doReturn = () => {
    const lines = sale.lines.map((l, i) => ({ productId: l.productId, qty: qty[i] || 0, price: l.price, restock })).filter((l) => l.qty > 0);
    if (!lines.length) { dlg.alert('اختر الكمية المرتجعة'); return; }
    const value = Math.round(retValue * 100) / 100;
    const refund = Math.min(refundAmt, value);
    const ret = {
      id: newId('ret-'), saleId: sale.id, lines, value, wh: sale.wh, reason, ts: Date.now(),
      refund: refund > 0 ? { method, amount: refund } : null,
    };
    commit('sale.return', { ret }, `مرتجع على ${sale.number} بقيمة ${money(value, settings.currency)}`);
    setRetOpen(false); setQty({}); setRefundStr(''); setReason('');
    dlg.toast('تم تسجيل المرتجع');
  };

  return (
    <Screen title={sale.number} subtitle={fmtDateTime(sale.ts)} onBack={() => navigation.goBack()}>
      <ScrollView contentContainerStyle={{ paddingBottom: 40 }} showsVerticalScrollIndicator={false}>
        <Card>
          <View style={[row, { justifyContent: 'space-between' }]}>
            <SyncBadge state={st} />
            {sale.oversold ? <Badge text="بيع بتجاوز المتاح" tone="warn" icon="warning" /> : null}
          </View>
          {st === 'needs_review' ? <T v="small" color={th.danger} style={{ marginTop: 6 }}>الفاتورة صحيحة ومحفوظة، لكن المخزون أصبح سالباً بعد دمج عمليات أجهزة أخرى. راجع شاشة المزامنة لتسوية العجز.</T> : null}
          {st === 'local' ? <T v="small" style={{ marginTop: 6 }}>محفوظة على هذا الجهاز. لا توجد أجهزة أخرى مرتبطة.</T> : null}
          {st === 'pending' ? <T v="small" style={{ marginTop: 6 }}>محفوظة محلياً ولم تؤكد الأجهزة الأخرى استلامها بعد.</T> : null}
          <Divider />
          <KV k="العميل" v={cust ? cust.name : 'عميل نقدي'} />
          <KV k="النوع" v={sale.kind === 'repair' ? 'فاتورة صيانة' : 'فاتورة بيع'} />
          <KV k="المستودع" v={db.warehouses.find((w) => w.id === sale.wh)?.name || ''} />
          <KV k="الموظف" v={db.staff.find((u) => u.id === sale.userId)?.name || ''} />
        </Card>

        <SectionTitle title="الأصناف" />
        <Card>
          {sale.lines.map((l, i) => (
            <View key={i} style={[row, { justifyContent: 'space-between', paddingVertical: 7, borderBottomWidth: i < sale.lines.length - 1 ? 1 : 0, borderBottomColor: th.border }]}>
              <View style={{ flex: 1 }}>
                <T v="bold">{l.name}</T>
                <T v="small">{l.qty} × {money(l.price)}{l.disc ? ` − خصم ${money(l.disc)}` : ''}{returnedQty(l.productId) ? ` · مرتجع ${returnedQty(l.productId)}` : ''}</T>
              </View>
              <T v="bold">{money(l.qty * l.price - l.disc)}</T>
            </View>
          ))}
        </Card>

        <SectionTitle title="الحساب" />
        <Card>
          <KV k="المجموع الفرعي" v={money(sale.subtotal, settings.currency)} />
          {sale.discount ? <KV k="خصم" v={money(sale.discount, settings.currency)} /> : null}
          {sale.tax ? <KV k={`ضريبة ${sale.taxRate}%`} v={money(sale.tax, settings.currency)} /> : null}
          <KV k="الإجمالي" v={money(sale.total, settings.currency)} bold />
          <Divider />
          {sale.payments.map((p, i) => <KV key={i} k={`دفعة (${PAY_METHODS[p.method] || p.method})`} v={money(p.amount, settings.currency)} />)}
          {retTotal > 0 ? <KV k="قيمة المرتجعات" v={money(retTotal, settings.currency)} color={th.danger} /> : null}
          <KV k="المتبقي على الفاتورة" v={money(sale.total - sale.paid, settings.currency)} color={sale.total - sale.paid > 0.001 ? th.warn : th.success} bold />
        </Card>

        {returns.length ? (
          <>
            <SectionTitle title="المرتجعات" />
            {returns.map((r) => (
              <Card key={r.id} style={{ marginBottom: 8 }}>
                <KV k={fmtDateTime(r.ts)} v={money(r.value, settings.currency)} bold />
                <T v="small">{r.lines.map((l) => `${db.products.find((p) => p.id === l.productId)?.name} ×${l.qty}${l.restock ? '' : ' (حجر)'}`).join('، ')}</T>
                {r.refund ? <T v="small">استرداد {money(r.refund.amount, settings.currency)} ({PAY_METHODS[r.refund.method]})</T> : <T v="small">رصيد دائن للعميل</T>}
              </Card>
            ))}
          </>
        ) : null}

        <View style={[row, { gap: 8, marginTop: 16, flexWrap: 'wrap' }]}>
          <Btn flex title="طباعة / PDF" icon="print" onPress={() => printHtml(saleHtml(db, sale, settings))} />
          <Btn flex title="مشاركة" icon="share-social" variant="soft" onPress={async () => { const r = await shareText(saleText(db, sale, settings), sale.number); if (r === 'copied') dlg.toast('تم نسخ الفاتورة'); }} />
        </View>
        {can('sales') ? <View style={{ marginTop: 8 }}><Btn title="مرتجع / استرداد" icon="return-down-back" variant="danger" onPress={() => setRetOpen(true)} /></View> : null}
      </ScrollView>

      <Sheet visible={retOpen} title="مرتجع مبيعات" onClose={() => setRetOpen(false)} tall footer={<Btn title={`تأكيد المرتجع (${money(retValue, settings.currency)})`} icon="checkmark" onPress={doReturn} />}>
        {sale.lines.map((l, i) => {
          const left = l.qty - returnedQty(l.productId);
          return (
            <View key={i} style={[row, { justifyContent: 'space-between', paddingVertical: 8 }]}>
              <View style={{ flex: 1 }}><T v="bold">{l.name}</T><T v="small">المتاح للإرجاع: {left}</T></View>
              <Stepper value={qty[i] || 0} min={0} max={left} onChange={(n) => setQty({ ...qty, [i]: n })} />
            </View>
          );
        })}
        <Switch2 value={restock} onChange={setRestock} label="إعادة الكمية للمخزون المتاح (وإلا تذهب للحجر)" />
        <T v="sub" style={{ marginTop: 8, marginBottom: 6 }}>طريقة الاسترداد</T>
        <ChipRow>{Object.entries(PAY_METHODS).map(([k, v]) => <Chip key={k} label={v} active={method === k} onPress={() => setMethod(k)} />)}</ChipRow>
        <View style={{ height: 10 }} />
        <Field label="مبلغ الاسترداد (اتركه فارغاً لاسترداد كامل القيمة، 0 = رصيد دائن)" keyboardType="decimal-pad" value={refundStr} onChangeText={setRefundStr} placeholder={String(Math.round(retValue * 100) / 100)} />
        <Field label="السبب" value={reason} onChangeText={setReason} placeholder="مثال: عيب في المنتج" />
      </Sheet>
    </Screen>
  );
}
