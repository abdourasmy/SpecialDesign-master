import React, { useState } from 'react';
import { FlatList, View } from 'react-native';
import QRCode from 'react-native-qrcode-svg';
import { useTheme } from '../lib/theme';
import { useStore } from '../lib/store';
import { Badge, Btn, Card, Chip, ChipRow, Divider, Empty, Field, Guard, KV, Screen, SearchBar, SectionTitle, Sheet, T, row, useDialog } from '../components/ui';
import { fmtDate, fmtDateTime, normalizeDigits } from '../lib/format';
import { Warranty } from '../lib/types';

export default function WarrantyScreen({ navigation }: any) {
  const th = useTheme();
  const dlg = useDialog();
  const { db, commit, newId, can } = useStore();
  const [q, setQ] = useState('');
  const [f, setF] = useState('all');
  const [sel, setSel] = useState<Warranty | null>(null);
  const [issue, setIssue] = useState('');
  const [resolve, setResolve] = useState<{ id: string; status: 'accepted' | 'rejected' } | null>(null);
  const [res, setRes] = useState('');
  const s = normalizeDigits(q).toLowerCase();
  const now = Date.now();
  const list = [...db.warranties].reverse().filter((w) => {
    if (f === 'active' && w.expiry < now) return false;
    if (f === 'expired' && w.expiry >= now) return false;
    if (!s) return true;
    const c = db.customers.find((x) => x.id === w.customerId);
    return w.number.toLowerCase().includes(s) || w.sourceNumber.toLowerCase().includes(s) || (w.serial || '').toLowerCase().includes(s) || (c?.phone || '').includes(s) || (c?.name || '').toLowerCase().includes(s) || w.item.toLowerCase().includes(s) || s.replace('rcm|', '') === w.sourceNumber.toLowerCase();
  });
  const claims = sel ? db.claims.filter((c) => c.warrantyId === sel.id) : [];
  const active = sel ? sel.expiry >= now : false;

  const addClaim = () => {
    if (!sel) return;
    if (!active) { dlg.alert('الضمان منتهٍ', 'يمكن تسجيل المطالبة ولكنها ستكون خارج مدة الضمان.'); }
    if (!issue.trim()) { dlg.alert('اكتب وصف المشكلة'); return; }
    commit('claim.create', { claim: { id: newId('clm-'), warrantyId: sel.id, issue: issue.trim() } }, `مطالبة ضمان على ${sel.number}`);
    setIssue('');
    dlg.toast('تم تسجيل المطالبة');
  };
  const doResolve = () => {
    if (!resolve) return;
    if (!res.trim()) { dlg.alert(resolve.status === 'rejected' ? 'سبب الرفض مطلوب' : 'اكتب الحل المتخذ'); return; }
    commit('claim.resolve', { id: resolve.id, status: resolve.status, resolution: res.trim() }, `${resolve.status === 'accepted' ? 'قبول' : 'رفض'} مطالبة ضمان`);
    setResolve(null); setRes('');
  };

  return (
    <Screen title="الضمان" subtitle={`${db.warranties.length} ضمان`} onBack={() => navigation.goBack()}>
      <Guard perm="warranty">
        <SearchBar value={q} onChangeText={setQ} placeholder="هاتف العميل، الفاتورة، IMEI، رقم الصيانة" />
        <ChipRow>
          <Chip label="الكل" active={f === 'all'} onPress={() => setF('all')} />
          <Chip label="ساري" active={f === 'active'} onPress={() => setF('active')} />
          <Chip label="منتهٍ" active={f === 'expired'} onPress={() => setF('expired')} />
        </ChipRow>
        <FlatList
          data={list}
          keyExtractor={(w) => w.id}
          contentContainerStyle={{ paddingVertical: 10, paddingBottom: 40 }}
          ListEmptyComponent={<Empty icon="shield-checkmark-outline" title="لا توجد ضمانات" sub="تُنشأ تلقائياً عند بيع منتج بضمان أو تسليم صيانة بضمان" />}
          renderItem={({ item: w }) => {
            const ok = w.expiry >= now;
            const c = db.customers.find((x) => x.id === w.customerId);
            return (
              <Card onPress={() => setSel(w)} style={{ marginBottom: 8 }}>
                <View style={[row, { justifyContent: 'space-between', gap: 8 }]}>
                  <T v="bold" style={{ flex: 1 }} numberOfLines={1}>{w.item}</T>
                  <Badge text={ok ? `ساري · ${Math.ceil((w.expiry - now) / 86400000)} يوم` : 'منتهٍ'} tone={ok ? 'success' : 'danger'} />
                </View>
                <T v="small">{w.number} · {w.sourceNumber} · {c?.name || 'عميل نقدي'}</T>
              </Card>
            );
          }}
        />
        <Sheet visible={!!sel} title={sel?.number || ''} onClose={() => setSel(null)} tall>
          {sel ? (
            <>
              <Card>
                <View style={[row, { justifyContent: 'space-between' }]}>
                  <View style={{ flex: 1 }}>
                    <T v="h3">{sel.item}</T>
                    <Badge text={active ? 'ضمان سارٍ' : 'انتهى الضمان'} tone={active ? 'success' : 'danger'} />
                  </View>
                  <View style={{ backgroundColor: '#fff', padding: 6, borderRadius: 10 }}><QRCode value={`RCM|${sel.sourceNumber}`} size={70} /></View>
                </View>
                <Divider />
                <KV k="المصدر" v={`${sel.sourceType === 'sale' ? 'فاتورة' : 'صيانة'} ${sel.sourceNumber}`} />
                <KV k="العميل" v={db.customers.find((c) => c.id === sel.customerId)?.name || 'عميل نقدي'} />
                <KV k="البداية" v={fmtDate(sel.start)} />
                <KV k="الانتهاء" v={fmtDate(sel.expiry)} />
                <KV k="المدة" v={`${sel.days} يوم`} />
                {sel.serial ? <KV k="IMEI / رقم تسلسلي" v={sel.serial} /> : null}
                <KV k="ما يغطيه" v={sel.covers} />
                <KV k="الشروط" v={sel.conditions} />
              </Card>
              <SectionTitle title="مطالبات الضمان" />
              {claims.length === 0 ? <T v="sub">لا توجد مطالبات</T> : claims.map((c) => (
                <Card key={c.id} style={{ marginBottom: 8 }}>
                  <View style={[row, { justifyContent: 'space-between' }]}>
                    <T v="bold" style={{ flex: 1 }}>{c.issue}</T>
                    <Badge text={c.status === 'open' ? 'مفتوحة' : c.status === 'accepted' ? 'مقبولة' : 'مرفوضة'} tone={c.status === 'open' ? 'warn' : c.status === 'accepted' ? 'success' : 'danger'} />
                  </View>
                  <T v="small">{fmtDateTime(c.ts)}</T>
                  {c.resolution ? <T v="sub">{c.status === 'rejected' ? 'سبب الرفض: ' : 'الحل: '}{c.resolution}</T> : null}
                  {c.status === 'open' && can('warranty') ? (
                    <View style={[row, { gap: 8, marginTop: 8 }]}>
                      <Btn flex small title="قبول" variant="success" icon="checkmark" onPress={() => { setResolve({ id: c.id, status: 'accepted' }); setRes(''); }} />
                      <Btn flex small title="رفض" variant="danger" icon="close" onPress={() => { setResolve({ id: c.id, status: 'rejected' }); setRes(''); }} />
                    </View>
                  ) : null}
                </Card>
              ))}
              {resolve ? (
                <Card style={{ marginBottom: 10 }}>
                  <Field label={resolve.status === 'rejected' ? 'سبب الرفض' : 'الحل المتخذ (إصلاح/استبدال)'} value={res} onChangeText={setRes} />
                  <Btn title="تأكيد" onPress={doResolve} />
                </Card>
              ) : null}
              <Field label="مطالبة جديدة" value={issue} onChangeText={setIssue} placeholder="وصف المشكلة" multiline />
              <Btn title="تسجيل مطالبة" icon="add" variant="soft" onPress={addClaim} />
            </>
          ) : null}
        </Sheet>
      </Guard>
    </Screen>
  );
}
