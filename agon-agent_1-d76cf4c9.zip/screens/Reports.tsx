import React, { useState } from 'react';
import { ScrollView, View } from 'react-native';
import { useTheme } from '../lib/theme';
import { useStore } from '../lib/store';
import { Btn, Card, Chip, ChipRow, Divider, Guard, KV, Screen, SectionTitle, Stat, T, row, useDialog } from '../components/ui';
import { DAY, money, startOfDay } from '../lib/format';
import { DAMAGE_CATS, PAY_METHODS } from '../lib/engine';
import { shareText } from '../lib/invoice';

export default function ReportsScreen({ navigation }: any) {
  const th = useTheme();
  const dlg = useDialog();
  const { db, stock, bal, settings } = useStore();
  const [period, setPeriod] = useState('30');
  const cur = settings.currency;
  const from = period === 'all' ? 0 : period === '0' ? startOfDay() : startOfDay() - (Number(period) - 1) * DAY;
  const inP = (ts: number) => ts >= from;

  const sales = db.sales.filter((s) => inP(s.ts));
  const rets = db.returns.filter((r) => inP(r.ts));
  const gross = sales.reduce((a, s) => a + s.total - s.tax, 0);
  const retVal = rets.reduce((a, r) => a + r.value, 0);
  const net = gross - retVal;
  const cogs = sales.reduce((a, s) => a + s.lines.reduce((x, l) => x + l.cost * l.qty, 0), 0)
    - rets.reduce((a, r) => a + r.lines.filter((l) => l.restock).reduce((x, l) => x + (db.products.find((p) => p.id === l.productId)?.cost || 0) * l.qty, 0), 0);
  const grossProfit = net - cogs;
  const expenses = db.cash.filter((c) => inP(c.ts) && c.dir === 'out' && (c.category === 'expense' || c.category === 'recovery_cost')).reduce((a, c) => a + c.amount, 0);
  const otherRev = db.cash.filter((c) => inP(c.ts) && c.dir === 'in' && c.category === 'revenue').reduce((a, c) => a + c.amount, 0);
  const losses = db.damages.filter((d) => inP(d.ts)).reduce((a, d) => a + (d.status === 'recovered' ? 0 : d.lossCost), 0);
  const netProfit = grossProfit + otherRev - expenses - losses;

  const prod: Record<string, { name: string; qty: number; rev: number }> = {};
  sales.forEach((s) => s.lines.forEach((l) => {
    if (l.productId === 'labor') return;
    const x = (prod[l.productId] ||= { name: l.name, qty: 0, rev: 0 });
    x.qty += l.qty; x.rev += l.qty * l.price - l.disc;
  }));
  const top = Object.values(prod).sort((a, b) => b.rev - a.rev).slice(0, 5);
  const byMethod: Record<string, number> = {};
  db.cash.filter((c) => inP(c.ts) && c.dir === 'in').forEach((c) => { byMethod[c.method] = (byMethod[c.method] || 0) + c.amount; });
  const delivered = db.repairs.filter((r) => r.status === 'delivered' && r.history.some((h) => h.status === 'delivered' && inP(h.ts))).length;
  const repairRev = sales.filter((s) => s.kind === 'repair').reduce((a, s) => a + s.total, 0);
  const invValue = Object.values(stock).reduce((a, s) => a + s.value, 0);
  const recv = Object.values(bal.cust).filter((v) => v > 0).reduce((a, b) => a + b, 0);
  const pay = Object.values(bal.sup).filter((v) => v > 0).reduce((a, b) => a + b, 0);
  const lossBy: Record<string, number> = {};
  db.damages.filter((d) => inP(d.ts)).forEach((d) => { if (d.lossCost) lossBy[d.category] = (lossBy[d.category] || 0) + d.lossCost; });

  const share = async () => {
    const t = [
      `${settings.businessName} — تقرير الأداء`,
      `المبيعات الصافية: ${money(net, cur)}`, `تكلفة المبيعات: ${money(cogs, cur)}`, `مجمل الربح: ${money(grossProfit, cur)}`,
      `المصروفات: ${money(expenses, cur)}`, `خسائر التالف: ${money(losses, cur)}`, `صافي الربح: ${money(netProfit, cur)}`,
    ].join('\n');
    const r = await shareText(t, 'تقرير');
    if (r === 'copied') dlg.toast('تم نسخ التقرير');
  };

  return (
    <Screen title="التقارير" onBack={() => navigation.goBack()}>
      <Guard perm="reports">
        <ChipRow>
          <Chip label="اليوم" active={period === '0'} onPress={() => setPeriod('0')} />
          <Chip label="7 أيام" active={period === '7'} onPress={() => setPeriod('7')} />
          <Chip label="30 يوم" active={period === '30'} onPress={() => setPeriod('30')} />
          <Chip label="90 يوم" active={period === '90'} onPress={() => setPeriod('90')} />
          <Chip label="الكل" active={period === 'all'} onPress={() => setPeriod('all')} />
        </ChipRow>
        <ScrollView contentContainerStyle={{ paddingBottom: 40, paddingTop: 10 }} showsVerticalScrollIndicator={false}>
          <View style={[row, { gap: 10, flexWrap: 'wrap' }]}>
            <Stat label="صافي المبيعات" value={money(net, cur)} icon="trending-up" tone="primary" sub={`${sales.length} فاتورة`} />
            <Stat label="صافي الربح" value={money(netProfit, cur)} icon="cash" tone={netProfit >= 0 ? 'success' : 'danger'} />
          </View>

          <SectionTitle title="قائمة الدخل" />
          <Card>
            <KV k="إجمالي المبيعات (بدون ضريبة)" v={money(gross, cur)} />
            <KV k="المرتجعات" v={'- ' + money(retVal, cur)} color={th.danger} />
            <KV k="تكلفة البضاعة المباعة" v={'- ' + money(cogs, cur)} color={th.danger} />
            <Divider />
            <KV k="مجمل الربح" v={money(grossProfit, cur)} bold />
            <KV k="إيرادات أخرى" v={'+ ' + money(otherRev, cur)} color={th.success} />
            <KV k="مصروفات تشغيلية" v={'- ' + money(expenses, cur)} color={th.danger} />
            <KV k="خسائر التالف والهالك" v={'- ' + money(losses, cur)} color={th.danger} />
            <Divider />
            <KV k="صافي الربح" v={money(netProfit, cur)} bold color={netProfit >= 0 ? th.success : th.danger} />
          </Card>

          <SectionTitle title="المركز المالي الحالي" />
          <Card>
            <KV k="رصيد الصندوق" v={money(bal.cash, cur)} />
            <KV k="قيمة المخزون (بالتكلفة)" v={money(invValue, cur)} />
            <KV k="ذمم العملاء (مستحقة لنا)" v={money(recv, cur)} color={th.warn} />
            <KV k="ذمم الموردين (مستحقة علينا)" v={money(pay, cur)} color={th.warn} />
            <Divider />
            <KV k="صافي المركز" v={money(bal.cash + invValue + recv - pay, cur)} bold />
          </Card>

          <SectionTitle title="أعلى المنتجات مبيعاً" />
          <Card>
            {top.length === 0 ? <T v="sub">لا توجد مبيعات في الفترة</T> : top.map((t, i) => (
              <View key={i} style={[row, { justifyContent: 'space-between', paddingVertical: 6, gap: 8 }]}>
                <View style={{ flex: 1 }}><T v="bold" numberOfLines={1}>{i + 1}. {t.name}</T><T v="small">الكمية {t.qty}</T></View>
                <T v="bold" color={th.primary}>{money(t.rev, cur)}</T>
              </View>
            ))}
          </Card>

          <SectionTitle title="الصيانة" />
          <Card>
            <KV k="أجهزة مسلمة في الفترة" v={String(delivered)} />
            <KV k="إيرادات فواتير الصيانة" v={money(repairRev, cur)} />
          </Card>

          <SectionTitle title="المقبوضات حسب طريقة الدفع" />
          <Card>{Object.keys(byMethod).length === 0 ? <T v="sub">لا توجد مقبوضات</T> : Object.entries(byMethod).map(([k, v]) => <KV key={k} k={PAY_METHODS[k] || k} v={money(v, cur)} />)}</Card>

          {Object.keys(lossBy).length ? (
            <>
              <SectionTitle title="الخسائر حسب السبب" />
              <Card>{Object.entries(lossBy).map(([k, v]) => <KV key={k} k={DAMAGE_CATS[k]} v={money(v, cur)} />)}</Card>
            </>
          ) : null}
          <View style={{ height: 16 }} />
          <Btn title="مشاركة ملخص التقرير" icon="share-social" onPress={share} />
        </ScrollView>
      </Guard>
    </Screen>
  );
}
