import React, { useState } from 'react';
import { ScrollView, TextInput, View, Platform } from 'react-native';
import * as Clipboard from 'expo-clipboard';
import { useTheme, R } from '../lib/theme';
import { useStore } from '../lib/store';
import { Badge, Btn, Card, Divider, Field, Guard, KV, Screen, SectionTitle, Sheet, T, row, useDialog, Empty } from '../components/ui';
import { fmtDateTime, money } from '../lib/format';
import { shareText } from '../lib/invoice';

export default function SyncScreen({ navigation }: any) {
  const th = useTheme();
  const dlg = useDialog();
  const ctx = useStore();
  const { doc, db, settings, conflicts, stock, commit, newId, vector, exportPackage, importPackage } = ctx;
  const [exp, setExp] = useState<string | null>(null);
  const [imp, setImp] = useState(false);
  const [text, setText] = useState('');
  const [review, setReview] = useState<{ productId: string; deficit: number } | null>(null);
  const [note, setNote] = useState('');
  const peers = Object.values(doc.peers);
  const mine = vector[settings.deviceId] || 0;
  const dupCode = peers.find((p) => p.code === settings.code);

  const doExport = () => setExp(exportPackage());
  const copy = async () => {
    if (!exp) return;
    await Clipboard.setStringAsync(exp);
    dlg.toast('تم نسخ حزمة المزامنة');
  };
  const paste = async () => setText(await Clipboard.getStringAsync());
  const doImport = () => {
    const r = importPackage(text);
    if (r.ok) { dlg.toast(r.message); setImp(false); setText(''); } else dlg.alert('تعذر الاستيراد', r.message);
  };
  const fix = async (productId: string, deficit: number) => {
    const p = db.products.find((x) => x.id === productId)!;
    const ok = await dlg.confirm('تسوية العجز بجرد', `سيتم تسجيل حركة تسوية بـ +${deficit} لـ ${p.name} بعد أن تتأكد أن الكمية موجودة فعلياً أو تم استلامها.`, { confirmText: 'تسجيل التسوية' });
    if (!ok) return;
    commit('stock.adjust', { id: newId('adj-'), productId, wh: settings.defaultWh, delta: deficit, kind: 'adjust', reason: 'تسوية تعارض مخزون بعد المزامنة' }, `تسوية تعارض ${p.name} +${deficit}`);
  };
  const markReviewed = () => {
    if (!review) return;
    commit('conflict.review', { id: newId('rev-'), productId: review.productId, deficit: review.deficit, note: note.trim() || 'تمت المراجعة' }, 'مراجعة تعارض مخزون');
    setReview(null); setNote('');
  };

  return (
    <Screen title="المزامنة والأجهزة" subtitle="عمل محلي أولاً — مزامنة لاحقة" onBack={() => navigation.goBack()}>
      <Guard perm="sync">
        <ScrollView contentContainerStyle={{ paddingBottom: 40 }} showsVerticalScrollIndicator={false}>
          <Card style={{ backgroundColor: th.hero, borderColor: th.hero }}>
            <T v="small" color="#8FB3C4">هذا الجهاز</T>
            <T v="h2" color="#fff">{settings.deviceName} · {settings.code}</T>
            <T v="small" color="#8FB3C4">{settings.deviceId}</T>
            <View style={[row, { gap: 8, marginTop: 10, flexWrap: 'wrap' }]}>
              <Badge text={`${doc.ops.length} عملية محلية`} tone="info" />
              <Badge text={`رقم تسلسلي أخير ${mine}`} tone="primary" />
              <Badge text={peers.length ? `${peers.length + 1} أجهزة مرتبطة` : 'وضع الجهاز المستقل'} tone={peers.length ? 'success' : 'warn'} />
            </View>
          </Card>

          <SectionTitle title="تبادل العمليات بين الأجهزة" />
          <Card>
            <T v="sub" style={{ lineHeight: 21 }}>
              كل هاتف يحتفظ بنسخة كاملة من البيانات وسجل عمليات غير قابل للتعديل. عند استيراد حزمة من جهاز آخر تُدمج العمليات الجديدة فقط (بدون تكرار) وتُعاد معالجتها بترتيب متساوٍ على كل الأجهزة.
            </T>
            <View style={{ height: 8 }} />
            <T v="small" color={th.warn}>
              ملاحظة مهمة: الاكتشاف التلقائي عبر Wi-Fi المحلي والمزامنة في الخلفية تتطلب وحدات أصلية لأندرويد (منفذ TCP وNSD) غير متاحة في هذا الإصدار، لذلك تعمل المزامنة هنا يدوياً عبر حزمة نصية (نسخ/لصق أو مشاركة) بنفس بروتوكول العمليات. لم يُختبر النقل اللاسلكي على أجهزة حقيقية.
            </T>
            <View style={[row, { gap: 8, marginTop: 12 }]}>
              <Btn flex title="تصدير حزمة" icon="cloud-upload" onPress={doExport} />
              <Btn flex title="استيراد حزمة" icon="cloud-download" variant="soft" onPress={() => { setText(''); setImp(true); }} />
            </View>
          </Card>

          <SectionTitle title="الأجهزة المرتبطة" />
          {peers.length === 0 ? <Card><T v="sub">لا توجد أجهزة مرتبطة. الجهاز يعمل بشكل مستقل كاملاً وكل عملياتك محفوظة محلياً.</T></Card> : peers.map((p) => {
            const missing = Math.max(0, mine - (p.vector[settings.deviceId] || 0));
            return (
              <Card key={p.id} style={{ marginBottom: 8 }}>
                <View style={[row, { justifyContent: 'space-between' }]}>
                  <T v="bold">{p.name} · {p.code}</T>
                  <Badge text={missing ? `ينقصه ${missing} عملية` : 'محدّث'} tone={missing ? 'warn' : 'success'} />
                </View>
                <T v="small">آخر تبادل: {fmtDateTime(p.lastSync)} · استُلم منه {p.opsReceived} عملية</T>
                {missing ? <T v="small" color={th.warn}>صدّر حزمة جديدة وأرسلها لهذا الجهاز ثم استورد حزمته لتأكيد الاستلام.</T> : null}
              </Card>
            );
          })}
          {dupCode ? <Card style={{ marginTop: 6, backgroundColor: th.warnSoft }}><T v="small" color={th.warn}>تحذير: رمز الجهاز ({settings.code}) مكرر مع جهاز آخر. غيّره من الإعدادات لتجنب تشابه أرقام الفواتير.</T></Card> : null}

          <SectionTitle title={`تعارضات المخزون (${conflicts.filter((c) => !c.reviewed).length})`} />
          {conflicts.length === 0 ? <Card><T v="sub">لا توجد تعارضات. لا يُحذف أي بيع أو دفعة بسبب التعارض، بل تُعلّم للمراجعة.</T></Card> : conflicts.map((c) => {
            const p = db.products.find((x) => x.id === c.productId)!;
            return (
              <Card key={c.productId} style={{ marginBottom: 8, borderColor: c.reviewed ? th.border : th.danger }}>
                <View style={[row, { justifyContent: 'space-between' }]}>
                  <T v="bold" style={{ flex: 1 }}>{p.name}</T>
                  <Badge text={c.reviewed ? 'تمت مراجعته' : `عجز ${c.deficit}`} tone={c.reviewed ? 'muted' : 'danger'} icon="warning" />
                </View>
                <T v="small">المتاح الحالي: {stock[p.id]?.available} · مبيعات مساهمة: {c.saleIds.length}</T>
                <T v="small" style={{ lineHeight: 18 }}>بُيعت كمية أكبر من المتاح فعلياً من أكثر من جهاز. المبيعات صحيحة ومحفوظة، والحل: شراء/استلام الكمية أو تأخير التسليم أو تسوية موثّقة.</T>
                <View style={[row, { gap: 8, marginTop: 8, flexWrap: 'wrap' }]}>
                  <Btn small title="شراء الكمية" icon="download" variant="soft" onPress={() => navigation.navigate('NewPurchase')} />
                  <Btn small title="تسوية بجرد" icon="clipboard" variant="ghost" onPress={() => fix(c.productId, c.deficit)} />
                  {!c.reviewed ? <Btn small title="تمت المراجعة" icon="checkmark" variant="ghost" onPress={() => { setReview({ productId: c.productId, deficit: c.deficit }); setNote(''); }} /> : null}
                </View>
              </Card>
            );
          })}

          <SectionTitle title="تشخيص" />
          <Card>
            <KV k="أجهزة معروفة في السجل" v={String(Object.keys(vector).length)} />
            {Object.entries(vector).map(([d, s]) => <KV key={d} k={d === settings.deviceId ? 'هذا الجهاز' : (doc.peers[d]?.name || d.slice(0, 12))} v={`آخر تسلسل ${s}`} />)}
            <Divider />
            <T v="small" style={{ lineHeight: 18 }}>المخزون المشترك: قد تبيع أجهزة مختلفة نفس القطعة أثناء انقطاع الاتصال. النظام لا يمنع ذلك (لأن منعه يتطلب اتصالاً دائماً)، بل يُحذّر عند تجاوز المتاح محلياً ويظهر العجز هنا بعد الدمج دون حذف أي معاملة.</T>
          </Card>
        </ScrollView>

        <Sheet visible={exp !== null} title="حزمة المزامنة" onClose={() => setExp(null)} tall footer={<View style={[row, { gap: 8 }]}><Btn flex title="نسخ" icon="copy" onPress={copy} /><Btn flex title="مشاركة" icon="share-social" variant="soft" onPress={async () => { if (exp) await shareText(exp, 'حزمة مزامنة'); }} /></View>}>
          <T v="sub" style={{ marginBottom: 8 }}>انقل هذا النص إلى الجهاز الآخر واستورده هناك ({doc.ops.length} عملية).</T>
          <TextInput value={exp || ''} editable={false} multiline selectTextOnFocus style={{ backgroundColor: th.input, borderRadius: R.md, borderWidth: 1, borderColor: th.border, padding: 10, height: 220, color: th.text, fontSize: 11, textAlign: 'left', writingDirection: 'ltr' }} />
        </Sheet>

        <Sheet visible={imp} title="استيراد حزمة" onClose={() => setImp(false)} tall footer={<View style={[row, { gap: 8 }]}><Btn flex title="دمج العمليات" icon="git-merge" onPress={doImport} disabled={!text.trim()} /><Btn title="لصق" icon="clipboard" variant="soft" onPress={paste} /></View>}>
          <T v="sub" style={{ marginBottom: 8 }}>الصق حزمة المزامنة القادمة من جهاز آخر.</T>
          <TextInput value={text} onChangeText={setText} multiline placeholder="{ ... }" placeholderTextColor={th.sub} style={{ backgroundColor: th.input, borderRadius: R.md, borderWidth: 1, borderColor: th.border, padding: 10, height: 220, color: th.text, fontSize: 11, textAlign: 'left', writingDirection: 'ltr', textAlignVertical: 'top' }} />
        </Sheet>

        <Sheet visible={!!review} title="تمت المراجعة" onClose={() => setReview(null)} footer={<Btn title="تأكيد" icon="checkmark" onPress={markReviewed} />}>
          <Field label="ملاحظة المراجعة" value={note} onChangeText={setNote} placeholder="مثال: سيتم تأخير تسليم العميل الثاني وشراء الكمية" multiline />
          <T v="small">لن تتغير الكميات. سيُسجّل أنك راجعت هذا العجز وتظل الفواتير صحيحة.</T>
        </Sheet>
      </Guard>
    </Screen>
  );
}
