import React, { useState } from 'react';
import { FlatList, View } from 'react-native';
import { useTheme } from '../lib/theme';
import { useStore } from '../lib/store';
import { Badge, Btn, Card, Chip, ChipRow, Empty, Fab, Field, Guard, KV, Picker, Screen, Sheet, Stat, T, row, useDialog } from '../components/ui';
import { fmtDateTime, money, num, startOfDay } from '../lib/format';
import { PAY_METHODS } from '../lib/engine';

export const CASH_CAT: Record<string, string> = {
  sale: 'مبيعات', sale_return: 'مرتجع مبيعات', repair_deposit: 'عربون صيانة', repair_payment: 'دفعة صيانة', purchase: 'مشتريات',
  purchase_return: 'مرتجع مشتريات', supplier_payment: 'دفعة مورد', collection: 'تحصيل من عميل', expense: 'مصروف',
  revenue: 'إيراد آخر', customer_refund: 'رد مبلغ لعميل', recovery_cost: 'تكلفة إصلاح مخزون', opening: 'رصيد افتتاحي',
};
const EXP = ['إيجار', 'رواتب', 'كهرباء وماء', 'مواصلات', 'تسويق', 'أدوات ومستلزمات', 'أخرى'];

export default function CashScreen({ navigation }: any) {
  const th = useTheme();
  const dlg = useDialog();
  const { db, bal, settings, commit, newId } = useStore();
  const [open, setOpen] = useState(false);
  const [kind, setKind] = useState<'expense' | 'revenue' | 'collection' | 'customer_refund' | 'opening'>('expense');
  const [amt, setAmt] = useState('');
  const [method, setMethod] = useState('cash');
  const [sub, setSub] = useState('إيجار');
  const [note, setNote] = useState('');
  const [cust, setCust] = useState<string | null>(null);
  const [f, setF] = useState('all');
  const today = startOfDay();
  const todayIn = db.cash.filter((c) => c.ts >= today && c.dir === 'in').reduce((a, c) => a + c.amount, 0);
  const todayOut = db.cash.filter((c) => c.ts >= today && c.dir === 'out').reduce((a, c) => a + c.amount, 0);
  const byMethod: Record<string, number> = {};
  db.cash.forEach((c) => { byMethod[c.method] = (byMethod[c.method] || 0) + (c.dir === 'in' ? c.amount : -c.amount); });
  const list = [...db.cash].reverse().filter((c) => f === 'all' || c.dir === f);

  const save = () => {
    const a = num(amt);
    if (a <= 0) { dlg.alert('أدخل مبلغاً صحيحاً'); return; }
    const needCust = kind === 'collection' || kind === 'customer_refund';
    if (needCust && !cust) { dlg.alert('اختر العميل'); return; }
    const dir = kind === 'expense' || kind === 'customer_refund' ? 'out' : 'in';
    if (dir === 'out' && method === 'cash' && a > bal.cash + 0.001) { dlg.alert('رصيد الصندوق غير كافٍ', `الرصيد الحالي ${money(bal.cash, settings.currency)}`); return; }
    const entry = {
      id: newId('cash-'), dir, method, amount: a, category: kind, note: kind === 'expense' ? `${sub}${note ? ' - ' + note : ''}` : note,
      party: needCust ? { type: 'customer', id: cust } : undefined,
    };
    commit('cash.add', { entry }, `${CASH_CAT[kind]} ${money(a, settings.currency)}${kind === 'expense' ? ' (' + sub + ')' : ''}`);
    setOpen(false); setAmt(''); setNote('');
    dlg.toast('تم التسجيل في الصندوق');
  };

  return (
    <Screen title="الصندوق والمصروفات" onBack={() => navigation.goBack()}>
      <Guard perm="finance">
        <FlatList
          data={list}
          keyExtractor={(c) => c.id}
          contentContainerStyle={{ paddingBottom: 100 }}
          ListHeaderComponent={
            <View>
              <Card style={{ backgroundColor: th.hero, borderColor: th.hero }}>
                <T v="small" color="#8FB3C4">الرصيد الحالي (كل الطرق)</T>
                <T v="h1" color="#fff" style={{ fontSize: 30 }}>{money(bal.cash, settings.currency)}</T>
                <View style={[row, { gap: 10, flexWrap: 'wrap', marginTop: 4 }]}>
                  {Object.entries(byMethod).map(([k, v]) => <Badge key={k} text={`${PAY_METHODS[k] || k}: ${money(v)}`} tone="info" />)}
                </View>
              </Card>
              <View style={[row, { gap: 10, marginTop: 10 }]}>
                <Stat label="وارد اليوم" value={money(todayIn, settings.currency)} icon="arrow-down-circle" tone="success" />
                <Stat label="صادر اليوم" value={money(todayOut, settings.currency)} icon="arrow-up-circle" tone="danger" />
              </View>
              <View style={{ height: 12 }} />
              <ChipRow>
                <Chip label="الكل" active={f === 'all'} onPress={() => setF('all')} />
                <Chip label="وارد" active={f === 'in'} onPress={() => setF('in')} />
                <Chip label="صادر" active={f === 'out'} onPress={() => setF('out')} />
              </ChipRow>
              <View style={{ height: 8 }} />
            </View>
          }
          ListEmptyComponent={<Empty icon="wallet-outline" title="لا توجد حركات" sub="سجل مصروفات وإيرادات المركز هنا" />}
          renderItem={({ item: c }) => {
            const cu = c.party?.type === 'customer' ? db.customers.find((x) => x.id === c.party!.id)?.name : c.party?.type === 'supplier' ? db.suppliers.find((x) => x.id === c.party!.id)?.name : '';
            return (
              <Card style={{ marginBottom: 6, padding: 11 }}>
                <View style={[row, { justifyContent: 'space-between', gap: 8 }]}>
                  <View style={{ flex: 1 }}>
                    <T v="bold">{CASH_CAT[c.category] || c.category}</T>
                    <T v="small">{[cu, c.note, PAY_METHODS[c.method]].filter(Boolean).join(' · ')}</T>
                    <T v="small">{fmtDateTime(c.ts)}</T>
                  </View>
                  <T v="h3" color={c.dir === 'in' ? th.success : th.danger}>{c.dir === 'in' ? '+' : '-'}{money(c.amount)}</T>
                </View>
              </Card>
            );
          }}
        />
        <Fab icon="add" label="حركة" onPress={() => setOpen(true)} />
        <Sheet visible={open} title="حركة صندوق" onClose={() => setOpen(false)} tall footer={<Btn title="حفظ" icon="checkmark" onPress={save} />}>
          <ChipRow>
            <Chip label="مصروف" active={kind === 'expense'} onPress={() => setKind('expense')} icon="arrow-up" />
            <Chip label="إيراد آخر" active={kind === 'revenue'} onPress={() => setKind('revenue')} icon="arrow-down" />
            <Chip label="تحصيل من عميل" active={kind === 'collection'} onPress={() => setKind('collection')} />
            <Chip label="رد لعميل" active={kind === 'customer_refund'} onPress={() => setKind('customer_refund')} />
            <Chip label="رصيد افتتاحي" active={kind === 'opening'} onPress={() => setKind('opening')} />
          </ChipRow>
          <View style={{ height: 12 }} />
          <Field label="المبلغ" value={amt} onChangeText={setAmt} keyboardType="decimal-pad" />
          {kind === 'expense' ? (<><T v="sub" style={{ marginBottom: 6, fontWeight: '600' }}>بند المصروف</T><ChipRow>{EXP.map((e) => <Chip key={e} label={e} active={sub === e} onPress={() => setSub(e)} />)}</ChipRow><View style={{ height: 10 }} /></>) : null}
          {kind === 'collection' || kind === 'customer_refund' ? <Picker label="العميل" value={cust} options={db.customers.filter((c) => !c.deleted).map((c) => ({ id: c.id, label: c.name, sub: c.phone, right: bal.cust[c.id] ? money(bal.cust[c.id]) : undefined }))} onSelect={setCust} /> : null}
          <T v="sub" style={{ marginBottom: 6, fontWeight: '600' }}>طريقة الدفع</T>
          <ChipRow>{Object.entries(PAY_METHODS).map(([k, v]) => <Chip key={k} label={v} active={method === k} onPress={() => setMethod(k)} />)}</ChipRow>
          <View style={{ height: 10 }} />
          <Field label="ملاحظات" value={note} onChangeText={setNote} />
        </Sheet>
      </Guard>
    </Screen>
  );
}
