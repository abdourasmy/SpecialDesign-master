import React from 'react';
import { Pressable, ScrollView, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useTheme } from '../lib/theme';
import { useStore } from '../lib/store';
import { Avatar, Card, T, row, IconName, toneColors } from '../components/ui';
import { Perm, ROLE_LABEL } from '../lib/engine';

const GROUPS: { title: string; items: { label: string; sub: string; icon: IconName; screen: string; perm: Perm; tone: string }[] }[] = [
  {
    title: 'العمليات',
    items: [
      { label: 'العملاء', sub: 'الحسابات والأجهزة والسجل', icon: 'people', screen: 'Customers', perm: 'customers', tone: 'primary' },
      { label: 'سجل المبيعات', sub: 'الفواتير والمرتجعات', icon: 'receipt', screen: 'Sales', perm: 'sales', tone: 'info' },
      { label: 'الأجهزة والتوافق', sub: 'موديلات الأجهزة والملحقات المتوافقة', icon: 'phone-portrait', screen: 'Models', perm: 'inventory', tone: 'success' },
      { label: 'الضمان', sub: 'بحث وفحص ومطالبات الضمان', icon: 'shield-checkmark', screen: 'Warranty', perm: 'warranty', tone: 'warn' },
    ],
  },
  {
    title: 'المشتريات والمخزون',
    items: [
      { label: 'الموردون', sub: 'كشوف الحساب والدفعات', icon: 'business', screen: 'Suppliers', perm: 'purchases', tone: 'primary' },
      { label: 'فواتير الشراء', sub: 'استلام بضاعة ومرتجعات', icon: 'download', screen: 'Purchases', perm: 'purchases', tone: 'info' },
      { label: 'التالف والهالك', sub: 'الخسائر والمخزون القابل للإصلاح', icon: 'trash', screen: 'Damage', perm: 'damage', tone: 'danger' },
      { label: 'حركات المخزون', sub: 'سجل لا يمكن تعديله', icon: 'swap-vertical', screen: 'Movements', perm: 'inventory', tone: 'success' },
    ],
  },
  {
    title: 'المالية',
    items: [
      { label: 'الصندوق والمصروفات', sub: 'الإيرادات والمصروفات والتحصيل', icon: 'wallet', screen: 'Cash', perm: 'finance', tone: 'success' },
      { label: 'التقارير', sub: 'الأرباح والمبيعات والخسائر', icon: 'bar-chart', screen: 'Reports', perm: 'reports', tone: 'warn' },
    ],
  },
  {
    title: 'النظام',
    items: [
      { label: 'المزامنة والأجهزة', sub: 'ربط الهواتف وحل التعارضات', icon: 'sync', screen: 'Sync', perm: 'sync', tone: 'primary' },
      { label: 'الموظفون والصلاحيات', sub: 'الأدوار وتبديل المستخدم', icon: 'id-card', screen: 'Staff', perm: 'staff', tone: 'info' },
      { label: 'سجل التدقيق', sub: 'كل عملية مسجّلة', icon: 'list', screen: 'Audit', perm: 'dashboard', tone: 'muted' },
      { label: 'الإعدادات والنسخ الاحتياطي', sub: 'بيانات المنشأة والاستعادة', icon: 'settings', screen: 'Settings', perm: 'settings', tone: 'muted' },
    ],
  },
];

export default function MoreScreen({ navigation }: any) {
  const th = useTheme();
  const { can, user, settings } = useStore();
  return (
    <SafeAreaView style={{ flex: 1 }} edges={['top']}>
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 30 }}>
        <T v="h1" style={{ marginBottom: 12 }}>المزيد</T>
        <Card style={{ marginBottom: 6 }}>
          <View style={[row, { gap: 12 }]}>
            <Avatar name={user.name} size={48} />
            <View style={{ flex: 1 }}>
              <T v="h3">{user.name}</T>
              <T v="sub">{ROLE_LABEL[user.role]} · {settings.deviceName} ({settings.code})</T>
            </View>
          </View>
        </Card>
        {GROUPS.map((g) => (
          <View key={g.title}>
            <T v="sub" style={{ marginTop: 16, marginBottom: 8, fontWeight: '700' }}>{g.title}</T>
            <Card style={{ padding: 4 }}>
              {g.items.map((it, i) => {
                const ok = can(it.perm);
                const c = toneColors(th, it.tone);
                return (
                  <Pressable key={it.screen} onPress={() => navigation.navigate(it.screen)} style={[row, { gap: 12, padding: 11, opacity: ok ? 1 : 0.45, borderTopWidth: i ? 1 : 0, borderTopColor: th.border }]}>
                    <View style={{ width: 40, height: 40, borderRadius: 12, backgroundColor: c.bg, alignItems: 'center', justifyContent: 'center' }}>
                      <Ionicons name={it.icon} size={20} color={c.fg} />
                    </View>
                    <View style={{ flex: 1 }}>
                      <T v="bold">{it.label}</T>
                      <T v="small">{ok ? it.sub : 'غير متاح لدورك الحالي'}</T>
                    </View>
                    <Ionicons name={ok ? 'chevron-back' : 'lock-closed'} size={16} color={th.sub} />
                  </Pressable>
                );
              })}
            </Card>
          </View>
        ))}
        <T v="small" style={{ textAlign: 'center', marginTop: 20 }}>مدير مركز الصيانة · يعمل بدون إنترنت · الإصدار 1.0</T>
      </ScrollView>
    </SafeAreaView>
  );
}
