import React, { useEffect, useState } from 'react';
import { FlatList, ScrollView, View, Pressable } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useTheme } from '../lib/theme';
import { useStore } from '../lib/store';
import { Badge, Btn, Card, Chip, ChipRow, Divider, Empty, Fab, Field, Guard, IconButton, KV, Picker, Screen, SearchBar, SectionTitle, Sheet, Switch2, T, row, useDialog } from '../components/ui';
import { fmtDateTime, money, normalizeDigits, num } from '../lib/format';
import { BUCKET_LABEL } from '../lib/engine';
import { Product } from '../lib/types';
import { DamageForm } from './Damage';

export const MOVE_LABEL: Record<string, string> = {
  opening: 'رصيد افتتاحي', sale: 'بيع', sale_return: 'مرتجع مبيعات', purchase: 'شراء', purchase_return: 'مرتجع مشتريات', repair_consume: 'صرف لصيانة',
  repair_return: 'إرجاع من صيانة', damage_out: 'خروج تالف', damage_in: 'دخول تالف', recovery_out: 'استرداد (خروج)', recovery_in: 'استرداد (دخول)',
  dispose_out: 'إتلاف (خروج)', dispose_in: 'إتلاف (شطب)', adjust: 'تسوية', count: 'جرد', transfer_out: 'نقل (خروج)', transfer_in: 'نقل (دخول)',
};

export function InventoryScreen({ navigation }: any) {
  const th = useTheme();
  const { db, stock, settings, can, conflicts } = useStore();
  const [q, setQ] = useState('');
  const [f, setF] = useState('all');
  const [form, setForm] = useState(false);
  const [countOpen, setCountOpen] = useState(false);
  const [whOpen, setWhOpen] = useState(false);
  const s = normalizeDigits(q).toLowerCase();
  const prods = db.products.filter((p) => !p.deleted);
  const list = prods.filter((p) => {
    const st = stock[p.id];
    const av = st?.available || 0;
    if (f === 'low' && !(p.kind === 'product' && av <= p.minStock && av > 0)) return false;
    if (f === 'out' && !(p.kind === 'product' && av <= 0)) return false;
    if (f === 'damaged' && !((st?.repairable || 0) + (st?.quarantine || 0) > 0)) return false;
    if (f === 'service' && p.kind !== 'service') return false;
    if (!s) return true;
    return p.name.toLowerCase().includes(s) || p.sku.toLowerCase().includes(s) || (p.barcode || '').includes(s) || p.category.includes(s);
  });
  const value = Object.values(stock).reduce((a, x) => a + x.value, 0);
  const unrev = conflicts.filter((c) => !c.reviewed).length;
  return (
    <SafeAreaView style={{ flex: 1 }} edges={['top']}>
      <View style={{ flex: 1, paddingHorizontal: 16 }}>
        <View style={[row, { justifyContent: 'space-between', paddingVertical: 12 }]}>
          <View>
            <T v="h1">المخزون</T>
            <T v="small">قيمة المخزون {money(value, settings.currency)} · {prods.length} صنف</T>
          </View>
          <View style={[row, { gap: 8 }]}>
            <IconButton icon="business-outline" onPress={() => setWhOpen(true)} />
            <IconButton icon="clipboard-outline" onPress={() => setCountOpen(true)} />
          </View>
        </View>
        <Guard perm="inventory">
          {unrev ? <Card onPress={() => navigation.navigate('Sync')} style={{ marginBottom: 10, backgroundColor: th.dangerSoft, borderColor: th.danger }}><T color={th.danger} v="bold">⚠ {unrev} منتج بمخزون سالب يحتاج مراجعة</T></Card> : null}
          <SearchBar value={q} onChangeText={setQ} placeholder="اسم، رمز، باركود، تصنيف" />
          <ChipRow>
            <Chip label="الكل" active={f === 'all'} onPress={() => setF('all')} />
            <Chip label="منخفض" active={f === 'low'} onPress={() => setF('low')} />
            <Chip label="نافد" active={f === 'out'} onPress={() => setF('out')} />
            <Chip label="تالف / حجر" active={f === 'damaged'} onPress={() => setF('damaged')} />
            <Chip label="خدمات" active={f === 'service'} onPress={() => setF('service')} />
          </ChipRow>
          <FlatList
            data={list}
            keyExtractor={(p) => p.id}
            contentContainerStyle={{ paddingVertical: 10, paddingBottom: 100 }}
            ListEmptyComponent={<Empty icon="cube-outline" title="لا توجد أصناف" sub="أضف منتجاً جديداً بالزر أدناه" />}
            renderItem={({ item: p }) => {
              const st = stock[p.id];
              const av = st?.available || 0;
              return (
                <Card onPress={() => navigation.navigate('ProductDetail', { id: p.id })} style={{ marginBottom: 8, padding: 12 }}>
                  <View style={[row, { gap: 12 }]}>
                    <View style={{ width: 44, height: 44, borderRadius: 12, backgroundColor: th.primarySoft, alignItems: 'center', justifyContent: 'center' }}>
                      <Ionicons name={p.kind === 'service' ? 'build' : 'cube'} size={21} color={th.primary} />
                    </View>
                    <View style={{ flex: 1 }}>
                      <T v="bold" numberOfLines={1}>{p.name}</T>
                      <T v="small">{p.sku} · {p.category} · تكلفة {money(p.cost)}</T>
                    </View>
                    <View style={{ alignItems: 'flex-end', gap: 4 }}>
                      {p.kind === 'product' ? <Badge text={`${av} ${p.unit}`} tone={av < 0 ? 'danger' : av <= 0 ? 'danger' : av <= p.minStock ? 'warn' : 'success'} /> : <Badge text="خدمة" tone="info" />}
                      <T v="small">{money(p.price, settings.currency)}</T>
                    </View>
                  </View>
                  {(st?.repairable || 0) + (st?.quarantine || 0) > 0 ? <T v="small" color={th.warn} style={{ marginTop: 4 }}>خارج البيع: {(st?.repairable || 0) + (st?.quarantine || 0)}</T> : null}
                </Card>
              );
            }}
          />
          {can('inventory.edit') ? <Fab icon="add" label="منتج" onPress={() => setForm(true)} /> : null}
          <ProductForm visible={form} onClose={() => setForm(false)} onSaved={(p) => navigation.navigate('ProductDetail', { id: p.id })} />
          <CountSheet visible={countOpen} onClose={() => setCountOpen(false)} />
          <WarehouseSheet visible={whOpen} onClose={() => setWhOpen(false)} />
        </Guard>
      </View>
    </SafeAreaView>
  );
}

export function ProductForm({ visible, onClose, product, onSaved }: { visible: boolean; onClose: () => void; product?: Product; onSaved?: (p: Product) => void }) {
  const dlg = useDialog();
  const { db, upsert, commit, newId, settings, can } = useStore();
  const [f, setF] = useState({ name: '', sku: '', barcode: '', category: '', cost: '', price: '', wholesale: '', minStock: '3', unit: 'قطعة', warranty: '', open: '' });
  const [service, setService] = useState(false);
  const [serial, setSerial] = useState(false);
  useEffect(() => {
    if (!visible) return;
    setF({ name: product?.name || '', sku: product?.sku || '', barcode: product?.barcode || '', category: product?.category || '', cost: product ? String(product.cost) : '', price: product ? String(product.price) : '', wholesale: product?.wholesale ? String(product.wholesale) : '', minStock: product ? String(product.minStock) : '3', unit: product?.unit || 'قطعة', warranty: product?.warrantyDays ? String(product.warrantyDays) : '', open: '' });
    setService(product?.kind === 'service');
    setSerial(!!product?.serialTracked);
  }, [visible]);
  const set = (k: string) => (t: string) => setF((p) => ({ ...p, [k]: t }));
  const cats = Array.from(new Set(db.products.map((p) => p.category)));
  const save = () => {
    if (!f.name.trim()) { dlg.alert('اسم المنتج مطلوب'); return; }
    if (!f.category.trim()) { dlg.alert('التصنيف مطلوب'); return; }
    const sku = f.sku.trim() || 'SKU-' + String(Date.now()).slice(-6);
    if (db.products.some((p) => p.id !== product?.id && p.sku.toLowerCase() === sku.toLowerCase())) { dlg.alert('الرمز مستخدم', 'يوجد منتج بنفس الرمز (SKU).'); return; }
    const bc = normalizeDigits(f.barcode.trim());
    if (bc && db.products.some((p) => p.id !== product?.id && p.barcode === bc)) { dlg.alert('الباركود مستخدم', 'يوجد منتج بنفس الباركود.'); return; }
    const rec: Product = {
      id: product?.id || newId('prd-'), sku, barcode: bc, name: f.name.trim(), category: f.category.trim(), kind: service ? 'service' : 'product',
      cost: num(f.cost), price: num(f.price), wholesale: num(f.wholesale), minStock: num(f.minStock), unit: f.unit.trim() || 'قطعة',
      warrantyDays: num(f.warranty), serialTracked: serial, compat: product?.compat || [], createdAt: product?.createdAt || Date.now(),
    };
    upsert('products', rec, `${product ? 'تعديل' : 'إضافة'} المنتج ${rec.name}`);
    const oq = num(f.open);
    if (!product && !service && oq > 0) commit('stock.adjust', { id: newId('adj-'), productId: rec.id, wh: settings.defaultWh, delta: oq, kind: 'opening', reason: 'رصيد افتتاحي' }, `رصيد افتتاحي ${oq} × ${rec.name}`);
    dlg.toast('تم حفظ المنتج');
    onSaved?.(rec);
    onClose();
  };
  return (
    <Sheet visible={visible} title={product ? 'تعديل منتج' : 'منتج جديد'} onClose={onClose} tall footer={<Btn title="حفظ" icon="checkmark" onPress={save} />}>
      <Field label="اسم المنتج *" value={f.name} onChangeText={set('name')} />
      <Switch2 value={service} onChange={setService} label="خدمة (بدون مخزون)" />
      <View style={[row, { gap: 10 }]}>
        <Field style={{ flex: 1 }} label="الرمز SKU" value={f.sku} onChangeText={set('sku')} placeholder="تلقائي" autoCapitalize="characters" />
        <Field style={{ flex: 1 }} label="الباركود" value={f.barcode} onChangeText={set('barcode')} keyboardType="number-pad" />
      </View>
      <Field label="التصنيف *" value={f.category} onChangeText={set('category')} placeholder="مثال: قطع غيار" />
      {cats.length ? <View style={{ marginTop: -6, marginBottom: 10 }}><ChipRow>{cats.map((c) => <Chip key={c} label={c} active={f.category === c} onPress={() => set('category')(c)} />)}</ChipRow></View> : null}
      <View style={[row, { gap: 10 }]}>
        <Field style={{ flex: 1 }} label="سعر التكلفة" value={f.cost} onChangeText={set('cost')} keyboardType="decimal-pad" />
        <Field style={{ flex: 1 }} label="سعر البيع" value={f.price} onChangeText={set('price')} keyboardType="decimal-pad" />
      </View>
      <View style={[row, { gap: 10 }]}>
        <Field style={{ flex: 1 }} label="سعر الجملة" value={f.wholesale} onChangeText={set('wholesale')} keyboardType="decimal-pad" />
        <Field style={{ flex: 1 }} label="الحد الأدنى" value={f.minStock} onChangeText={set('minStock')} keyboardType="number-pad" />
      </View>
      <View style={[row, { gap: 10 }]}>
        <Field style={{ flex: 1 }} label="الوحدة" value={f.unit} onChangeText={set('unit')} />
        <Field style={{ flex: 1 }} label="الضمان (أيام)" value={f.warranty} onChangeText={set('warranty')} keyboardType="number-pad" />
      </View>
      <Switch2 value={serial} onChange={setSerial} label="تتبّع بالرقم التسلسلي" />
      {!product && !service ? <Field label="رصيد افتتاحي" value={f.open} onChangeText={set('open')} keyboardType="number-pad" hint="يُسجَّل كحركة مخزون افتتاحية في المستودع الرئيسي" /> : null}
    </Sheet>
  );
}

function CountSheet({ visible, onClose, productId }: { visible: boolean; onClose: () => void; productId?: string }) {
  const dlg = useDialog();
  const { db, stock, commit, newId, settings } = useStore();
  const [pid, setPid] = useState<string | null>(productId || null);
  const [wh, setWh] = useState(settings.defaultWh);
  const [counted, setCounted] = useState('');
  const [reason, setReason] = useState('');
  useEffect(() => { if (visible) { setPid(productId || null); setCounted(''); setReason(''); } }, [visible]);
  const cur = pid ? stock[pid]?.byWh[wh] || 0 : 0;
  const delta = counted === '' ? 0 : num(counted) - cur;
  const save = () => {
    const p = db.products.find((x) => x.id === pid);
    if (!p) { dlg.alert('اختر المنتج'); return; }
    if (counted === '') { dlg.alert('أدخل الكمية المعدودة'); return; }
    if (delta === 0) { dlg.alert('لا يوجد فرق', 'الكمية المعدودة مطابقة للنظام.'); return; }
    if (!reason.trim()) { dlg.alert('سبب التسوية مطلوب', 'كل تصحيح للمخزون يجب أن يكون موثقاً بسبب.'); return; }
    commit('stock.adjust', { id: newId('cnt-'), productId: p.id, wh, delta, kind: 'count', reason: reason.trim() }, `جرد ${p.name}: فرق ${delta > 0 ? '+' : ''}${delta}`);
    dlg.toast('تم تسجيل حركة الجرد');
    onClose();
  };
  return (
    <Sheet visible={visible} title="جرد وتسوية مخزون" onClose={onClose} tall footer={<Btn title="تسجيل الجرد" icon="checkmark" onPress={save} />}>
      <Picker label="المنتج" value={pid} options={db.products.filter((p) => !p.deleted && p.kind === 'product').map((p) => ({ id: p.id, label: p.name, sub: p.sku }))} onSelect={setPid} />
      <Picker label="المستودع" value={wh} options={db.warehouses.filter((w) => !w.deleted).map((w) => ({ id: w.id, label: w.name }))} onSelect={(id) => id && setWh(id)} searchable={false} />
      <Card style={{ marginBottom: 12 }}><KV k="الرصيد في النظام" v={String(cur)} bold /></Card>
      <Field label="الكمية الفعلية المعدودة" value={counted} onChangeText={setCounted} keyboardType="number-pad" />
      {counted !== '' ? <Badge text={delta === 0 ? 'مطابق' : delta > 0 ? `زيادة ${delta}` : `عجز ${-delta}`} tone={delta === 0 ? 'success' : delta > 0 ? 'info' : 'danger'} /> : null}
      <View style={{ height: 10 }} />
      <Field label="السبب *" value={reason} onChangeText={setReason} placeholder="مثال: جرد دوري نهاية الشهر" />
      <T v="small">لا يمكن تعديل الكميات مباشرة؛ ينتج عن الجرد حركة تسوية دائمة في السجل.</T>
    </Sheet>
  );
}

function WarehouseSheet({ visible, onClose }: { visible: boolean; onClose: () => void }) {
  const dlg = useDialog();
  const { db, upsert, newId, stock } = useStore();
  const [name, setName] = useState('');
  const add = () => {
    if (!name.trim()) return;
    upsert('warehouses', { id: newId('wh-'), name: name.trim() }, `إضافة مستودع ${name.trim()}`);
    setName('');
    dlg.toast('تمت إضافة المستودع');
  };
  return (
    <Sheet visible={visible} title="المستودعات" onClose={onClose}>
      {db.warehouses.filter((w) => !w.deleted).map((w) => {
        const units = Object.values(stock).reduce((a, s) => a + (s.byWh[w.id] || 0), 0);
        return <Card key={w.id} style={{ marginBottom: 8 }}><View style={[row, { justifyContent: 'space-between' }]}><T v="bold">{w.name}</T><Badge text={`${units} وحدة`} tone="primary" /></View></Card>;
      })}
      <Field label="مستودع جديد" value={name} onChangeText={setName} placeholder="مثال: رف الإكسسوارات" />
      <Btn title="إضافة" icon="add" onPress={add} />
    </Sheet>
  );
}

export function ProductDetailScreen({ navigation, route }: any) {
  const th = useTheme();
  const dlg = useDialog();
  const { db, stock, settings, can, commit, upsert, newId } = useStore();
  const p = db.products.find((x) => x.id === route.params.id);
  const [edit, setEdit] = useState(false);
  const [count, setCount] = useState(false);
  const [tr, setTr] = useState(false);
  const [dmg, setDmg] = useState(false);
  const [from, setFrom] = useState<string | null>(null);
  const [to, setTo] = useState<string | null>(null);
  const [tq, setTq] = useState('1');
  const [mdl, setMdl] = useState<string | null>(null);
  if (!p) return <Screen title="منتج" onBack={() => navigation.goBack()}><Empty title="غير موجود" /></Screen>;
  const st = stock[p.id];
  const moves = [...db.movements].filter((m) => m.productId === p.id).reverse().slice(0, 25);
  const edit_ = can('inventory.edit');

  const doTransfer = () => {
    const q = num(tq);
    if (!from || !to || from === to) { dlg.alert('اختر مستودعين مختلفين'); return; }
    if (q <= 0) { dlg.alert('أدخل كمية صحيحة'); return; }
    if (q > (st?.byWh[from] || 0)) { dlg.alert('الكمية أكبر من رصيد المستودع المصدر'); return; }
    commit('stock.transfer', { id: newId('trf-'), productId: p.id, from, to, qty: q }, `نقل ${q} × ${p.name}`);
    setTr(false);
    dlg.toast('تم النقل');
  };
  const setCompat = (compat: Product['compat']) => upsert('products', { id: p.id, compat }, `تحديث توافق ${p.name}`);

  return (
    <Screen title={p.name} subtitle={`${p.sku} · ${p.category}`} onBack={() => navigation.goBack()} right={edit_ ? <IconButton icon="create-outline" onPress={() => setEdit(true)} /> : undefined}>
      <ScrollView contentContainerStyle={{ paddingBottom: 40 }} showsVerticalScrollIndicator={false}>
        <Card>
          <View style={[row, { justifyContent: 'space-between' }]}>
            <View><T v="sub">متاح للبيع</T><T v="h1" color={(st?.available || 0) <= p.minStock && p.kind === 'product' ? th.danger : th.success}>{p.kind === 'service' ? '—' : st?.available || 0}</T></View>
            <View style={{ alignItems: 'flex-end' }}><T v="sub">سعر البيع</T><T v="h2" color={th.primary}>{money(p.price, settings.currency)}</T></View>
          </View>
          <Divider />
          <KV k="تكلفة (متوسط مرجّح)" v={money(p.cost, settings.currency)} />
          {p.wholesale ? <KV k="سعر الجملة" v={money(p.wholesale, settings.currency)} /> : null}
          {p.barcode ? <KV k="الباركود" v={p.barcode} /> : null}
          <KV k="الحد الأدنى" v={String(p.minStock)} />
          {p.warrantyDays ? <KV k="الضمان" v={`${p.warrantyDays} يوم`} /> : null}
          {p.kind === 'product' ? <KV k="قيمة المخزون" v={money(st?.value || 0, settings.currency)} bold /> : null}
        </Card>

        {p.kind === 'product' ? (
          <>
            <SectionTitle title="توزيع المخزون" />
            <Card>
              {db.warehouses.filter((w) => !w.deleted).map((w) => <KV key={w.id} k={w.name} v={String(st?.byWh[w.id] || 0)} />)}
              <Divider />
              {(['repairable', 'quarantine', 'disposed'] as const).map((b) => <KV key={b} k={BUCKET_LABEL[b]} v={String(st?.[b] || 0)} color={(st?.[b] || 0) ? th.warn : undefined} />)}
            </Card>
            {edit_ ? (
              <View style={[row, { gap: 8, marginTop: 10, flexWrap: 'wrap' }]}>
                <Btn flex small title="جرد / تسوية" icon="clipboard" variant="soft" onPress={() => setCount(true)} />
                <Btn flex small title="نقل" icon="swap-horizontal" variant="soft" onPress={() => { setFrom(settings.defaultWh); setTo(null); setTq('1'); setTr(true); }} />
                <Btn flex small title="تالف" icon="trash" variant="danger" onPress={() => setDmg(true)} />
              </View>
            ) : null}
          </>
        ) : null}

        <SectionTitle title="الأجهزة المتوافقة" />
        <Card>
          {p.compat.length === 0 ? <T v="sub">غير مرتبط بأي موديل</T> : p.compat.map((c) => {
            const m = db.models.find((x) => x.id === c.modelId);
            return (
              <View key={c.modelId} style={[row, { justifyContent: 'space-between', paddingVertical: 6, gap: 8 }]}>
                <T style={{ flex: 1 }}>{m ? `${m.brand} ${m.name}` : c.modelId}</T>
                <Pressable disabled={!edit_} onPress={() => setCompat(p.compat.map((x) => (x.modelId === c.modelId ? { ...x, verified: !x.verified } : x)))}>
                  <Badge text={c.verified ? 'موثّق' : 'يدوي'} tone={c.verified ? 'success' : 'warn'} />
                </Pressable>
                {edit_ ? <IconButton icon="close" size={16} onPress={() => setCompat(p.compat.filter((x) => x.modelId !== c.modelId))} /> : null}
              </View>
            );
          })}
          {edit_ ? (
            <View style={{ marginTop: 10 }}>
              <Picker label="ربط بموديل" value={mdl} options={db.models.filter((m) => !m.deleted && !p.compat.some((c) => c.modelId === m.id)).map((m) => ({ id: m.id, label: `${m.brand} ${m.name}`, sub: m.category }))} onSelect={(id) => { if (id) { setCompat([...p.compat, { modelId: id, verified: false }]); setMdl(null); } }} placeholder="اختر موديلاً..." />
              <T v="small">الربط الجديد يُسجَّل «يدوي» — اضغط على الشارة لتوثيقه. لا يُفترض توافق الأجيال المتقاربة.</T>
            </View>
          ) : null}
        </Card>

        <SectionTitle title="آخر الحركات" right={<T v="sub" color={th.primary} onPress={() => navigation.navigate('Movements', { productId: p.id })}>الكل</T>} />
        <Card>
          {moves.length === 0 ? <T v="sub">لا توجد حركات</T> : moves.map((m) => (
            <View key={m.id} style={[row, { justifyContent: 'space-between', paddingVertical: 6, gap: 8 }]}>
              <View style={{ flex: 1 }}>
                <T v="bold">{MOVE_LABEL[m.type] || m.type}</T>
                <T v="small">{fmtDateTime(m.ts)}{m.bucket !== 'available' ? ' · ' + BUCKET_LABEL[m.bucket] : ''}</T>
              </View>
              <T v="bold" color={m.qty > 0 ? th.success : th.danger}>{m.qty > 0 ? '+' : ''}{m.qty}</T>
            </View>
          ))}
        </Card>
      </ScrollView>
      <ProductForm visible={edit} onClose={() => setEdit(false)} product={p} />
      <CountSheet visible={count} onClose={() => setCount(false)} productId={p.id} />
      <DamageForm visible={dmg} onClose={() => setDmg(false)} productId={p.id} />
      <Sheet visible={tr} title="نقل بين المستودعات" onClose={() => setTr(false)} footer={<Btn title="تنفيذ النقل" icon="checkmark" onPress={doTransfer} />}>
        <Picker label="من" value={from} options={db.warehouses.filter((w) => !w.deleted).map((w) => ({ id: w.id, label: w.name, right: String(st?.byWh[w.id] || 0) }))} onSelect={setFrom} searchable={false} />
        <Picker label="إلى" value={to} options={db.warehouses.filter((w) => !w.deleted).map((w) => ({ id: w.id, label: w.name }))} onSelect={setTo} searchable={false} />
        <Field label="الكمية" value={tq} onChangeText={setTq} keyboardType="number-pad" />
        {db.warehouses.length < 2 ? <T v="small" color={th.warn}>أضف مستودعاً ثانياً من شاشة المخزون أولاً.</T> : null}
      </Sheet>
    </Screen>
  );
}

export function MovementsScreen({ navigation, route }: any) {
  const th = useTheme();
  const { db } = useStore();
  const pid = route.params?.productId as string | undefined;
  const [f, setF] = useState('all');
  const list = [...db.movements].reverse().filter((m) => (!pid || m.productId === pid) && (f === 'all' || (f === 'in' ? m.qty > 0 : m.qty < 0))).slice(0, 300);
  return (
    <Screen title="حركات المخزون" subtitle="سجل دائم لا يمكن تعديله" onBack={() => navigation.goBack()}>
      <Guard perm="inventory">
        <ChipRow>
          <Chip label="الكل" active={f === 'all'} onPress={() => setF('all')} />
          <Chip label="وارد" active={f === 'in'} onPress={() => setF('in')} />
          <Chip label="صادر" active={f === 'out'} onPress={() => setF('out')} />
        </ChipRow>
        <FlatList
          data={list}
          keyExtractor={(m) => m.id}
          contentContainerStyle={{ paddingVertical: 10, paddingBottom: 40 }}
          ListEmptyComponent={<Empty icon="swap-vertical" title="لا توجد حركات" />}
          renderItem={({ item: m }) => {
            const p = db.products.find((x) => x.id === m.productId);
            return (
              <Card style={{ marginBottom: 6, padding: 11 }}>
                <View style={[row, { justifyContent: 'space-between', gap: 8 }]}>
                  <View style={{ flex: 1 }}>
                    <T v="bold" numberOfLines={1}>{p?.name}</T>
                    <T v="small">{MOVE_LABEL[m.type] || m.type} · {db.warehouses.find((w) => w.id === m.wh)?.name} · {BUCKET_LABEL[m.bucket]}</T>
                    <T v="small">{m.ts ? fmtDateTime(m.ts) : 'افتتاحي'}</T>
                  </View>
                  <T v="h3" color={m.qty > 0 ? th.success : th.danger}>{m.qty > 0 ? '+' : ''}{m.qty}</T>
                </View>
              </Card>
            );
          }}
        />
      </Guard>
    </Screen>
  );
}
