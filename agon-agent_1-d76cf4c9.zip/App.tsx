import React from 'react';
import { I18nManager, Platform, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useFonts } from 'expo-font';
import Ionicons from '@expo/vector-icons/Ionicons';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { NavigationContainer, DefaultTheme, DarkTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { useColorScheme } from 'react-native';
import { StoreProvider, useStore } from './lib/store';
import { DialogProvider, ListLoading } from './components/ui';
import { useTheme } from './lib/theme';
import TabsScreen from './screens/Tabs';
import { CustomersScreen, CustomerDetailScreen } from './screens/Customers';
import { RepairDetailScreen, NewRepairScreen } from './screens/Repairs';
import { SalesScreen, SaleDetailScreen } from './screens/Sales';
import { ProductDetailScreen, MovementsScreen } from './screens/Inventory';
import { SuppliersScreen, SupplierDetailScreen, NewPurchaseScreen, PurchasesScreen } from './screens/Suppliers';
import DamageScreen from './screens/Damage';
import CashScreen from './screens/Cash';
import WarrantyScreen from './screens/Warranty';
import ReportsScreen from './screens/Reports';
import SyncScreen from './screens/Sync';
import { StaffScreen, SettingsScreen, AuditScreen } from './screens/Admin';
import { ModelsScreen, ModelDetailScreen } from './screens/Models';

try {
  I18nManager.allowRTL(false);
  I18nManager.forceRTL(false);
} catch (e) {}

const Stack = createNativeStackNavigator();

function Root() {
  const { ready } = useStore();
  const th = useTheme();
  const scheme = useColorScheme();
  if (!ready) {
    return <View style={{ flex: 1, backgroundColor: th.bg, justifyContent: 'center' }}><ListLoading /></View>;
  }
  const base = scheme === 'dark' ? DarkTheme : DefaultTheme;
  return (
    <NavigationContainer theme={{ ...base, colors: { ...base.colors, background: th.bg, card: th.card, text: th.text, border: th.border, primary: th.primary } }}>
      <Stack.Navigator screenOptions={{ headerShown: false, animation: 'slide_from_left', contentStyle: { backgroundColor: th.bg } }}>
        <Stack.Screen name="Tabs" component={TabsScreen} />
        <Stack.Screen name="Customers" component={CustomersScreen} />
        <Stack.Screen name="CustomerDetail" component={CustomerDetailScreen} />
        <Stack.Screen name="RepairDetail" component={RepairDetailScreen} />
        <Stack.Screen name="NewRepair" component={NewRepairScreen} />
        <Stack.Screen name="Sales" component={SalesScreen} />
        <Stack.Screen name="SaleDetail" component={SaleDetailScreen} />
        <Stack.Screen name="ProductDetail" component={ProductDetailScreen} />
        <Stack.Screen name="Movements" component={MovementsScreen} />
        <Stack.Screen name="Suppliers" component={SuppliersScreen} />
        <Stack.Screen name="SupplierDetail" component={SupplierDetailScreen} />
        <Stack.Screen name="NewPurchase" component={NewPurchaseScreen} />
        <Stack.Screen name="Purchases" component={PurchasesScreen} />
        <Stack.Screen name="Damage" component={DamageScreen} />
        <Stack.Screen name="Cash" component={CashScreen} />
        <Stack.Screen name="Warranty" component={WarrantyScreen} />
        <Stack.Screen name="Reports" component={ReportsScreen} />
        <Stack.Screen name="Sync" component={SyncScreen} />
        <Stack.Screen name="Staff" component={StaffScreen} />
        <Stack.Screen name="Settings" component={SettingsScreen} />
        <Stack.Screen name="Audit" component={AuditScreen} />
        <Stack.Screen name="Models" component={ModelsScreen} />
        <Stack.Screen name="ModelDetail" component={ModelDetailScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default function App() {
  const [fontsLoaded] = useFonts({ ...Ionicons.font });
  const scheme = useColorScheme();
  if (!fontsLoaded) return null;
  return (
    <GestureHandlerRootView style={{ flex: 1, backgroundColor: scheme === 'dark' ? '#000' : '#E5E9F0', alignItems: 'center' }}>
      <View style={{ flex: 1, width: '100%', maxWidth: Platform.OS === 'web' ? 560 : undefined }}>
        <SafeAreaProvider>
          <StoreProvider>
            <DialogProvider>
              <Root />
              <StatusBar style={scheme === 'dark' ? 'light' : 'dark'} />
            </DialogProvider>
          </StoreProvider>
        </SafeAreaProvider>
      </View>
    </GestureHandlerRootView>
  );
}
