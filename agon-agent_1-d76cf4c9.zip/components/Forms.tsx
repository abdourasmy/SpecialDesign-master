import React, { useEffect, useState } from 'react';
import { View } from 'react-native';
import { Btn, Field, Picker, Sheet, T, useDialog, row, Badge, Card } from './ui';
import { useStore } from '../lib/store';
import { num, normalizeDigits } from '../lib/format';
import { Customer, CustDevice } from '../lib/types';

export function CustomerForm({ visible, onClose, customer, onSaved }: { visible: boolean; onClose: () => void; customer?: Customer; onSaved?: (c: Customer) => void }) {
  const dlg = useDialog();
  const { db, upsert, newId, nextNumber } = useStore();
  const [f, setF] = useState({ name: '', phone: '', phone2: '', email: '', address: '', notes: '', category: '', creditLimit: '' });
  useEffect(() => {
    if (visible) setF({ name: customer?.name || '', phone: customer?.phone || '', phone2: customer?.phone2 || '', email: customer?.email || '', address: customer?.address || '', notes: customer?.notes || '', category: customer?.category || '', creditLimit: customer?.creditLimit ? String(customer.creditLimit) : '' });
  }, [visible]);
  const set = (k: string) => (t: string) => setF((p) => ({ ...p, [k]: t }));
  const phone = normalizeDigits(f.phone).replace(/\s/g, '');
  const dup = phone.length >= 6 ? db.customers.find((c) => !c.deleted && c.id !== customer?.id && normalizeDigits(c.phone).replace(/\s/g, '') === phone) : undefined;

  const save = async () => {
    if (!f.name.trim()) { dlg.alert('الاسم مطلوب'); return; }
    if (!phone) { dlg.alert('رقم الهاتف مطلوب'); return; }
    if (dup) {
      const ok = await dlg.confirm('عميل مكرر محتمل', `يوجد عميل بنفس الرقم: ${dup.name}. هل تريد الحفظ كعميل جديد رغم ذلك؟ (يمكنك لاحقاً دمجهما)`, { confirmText: 'حفظ رغم التكرار' });
      if (!ok) return;
    }
    const rec: Customer = {
      id: customer?.id || newId('cus-'), code: customer?.code || nextNumber('customer'), createdAt: customer?.createdAt || Date.now(),
      name: f.name.trim(), phone, phone2: f.phone2.trim(), email: f.email.trim(), address: f.address.trim(), notes: f.notes.trim(), category: f.category.trim(), creditLimit: num(f.creditLimit),
    };
    upsert('customers', rec, `${customer ? 'تعديل' : 'إضافة'} العميل ${rec.name}`);
    dlg.toast('تم حفظ العميل');
    onSaved?.(rec);
    onClose();
  };

  return (
    <Sheet visible={visible} title={customer ? 'تعديل عميل' : 'عميل جديد'} onClose={onClose} tall footer={<Btn title="حفظ" icon="checkmark" onPress={save} />}>
      <Field label="الاسم الكامل *" value={f.name} onChangeText={set('name')} placeholder="اسم العميل" />
      <Field label="رقم الهاتف *" value={f.phone} onChangeText={set('phone')} keyboardType="phone-pad" placeholder="05xxxxxxxx" error={dup ? `مسجل باسم: ${dup.name}` : undefined} />
      <Field label="هاتف إضافي" value={f.phone2} onChangeText={set('phone2')} keyboardType="phone-pad" />
      <Field label="البريد الإلكتروني" value={f.email} onChangeText={set('email')} keyboardType="email-address" autoCapitalize="none" />
      <Field label="العنوان" value={f.address} onChangeText={set('address')} />
      <Field label="التصنيف" value={f.category} onChangeText={set('category')} placeholder="مثال: جملة، VIP" />
      <Field label="حد الائتمان" value={f.creditLimit} onChangeText={set('creditLimit')} keyboardType="decimal-pad" hint="0 = بدون حد" />
      <Field label="ملاحظات" value={f.notes} onChangeText={set('notes')} multiline />
    </Sheet>
  );
}

export function DeviceForm({ visible, onClose, customerId, device, onSaved }: { visible: boolean; onClose: () => void; customerId: string; device?: CustDevice; onSaved?: (d: CustDevice) => void }) {
  const dlg = useDialog();
  const { db, upsert, newId } = useStore();
  const [modelId, setModelId] = useState<string | null>(null);
  const [f, setF] = useState({ manual: '', serial: '', imei: '', color: '', storage: '', condition: '', notes: '' });
  useEffect(() => {
    if (visible) {
      setModelId(device?.modelId || null);
      setF({ manual: device?.manual || '', serial: device?.serial || '', imei: device?.imei || '', color: device?.color || '', storage: device?.storage || '', condition: device?.condition || '', notes: device?.notes || '' });
    }
  }, [visible]);
  const set = (k: string) => (t: string) => setF((p) => ({ ...p, [k]: t }));
  const opts = db.models.filter((m) => !m.deleted).map((m) => ({ id: m.id, label: `${m.brand} ${m.name}`, sub: m.category }));
  const save = () => {
    if (!modelId && !f.manual.trim()) { dlg.alert('حدد الموديل أو اكتب وصف الجهاز يدوياً'); return; }
    const rec: CustDevice = { id: device?.id || newId('dev-'), customerId, modelId: modelId || undefined, createdAt: device?.createdAt || Date.now(), ...f, imei: normalizeDigits(f.imei.trim()), serial: f.serial.trim() };
    const m = db.models.find((x) => x.id === modelId);
    upsert('custDevices', rec, `${device ? 'تعديل' : 'تسجيل'} جهاز ${m ? m.brand + ' ' + m.name : f.manual}`);
    dlg.toast('تم حفظ الجهاز');
    onSaved?.(rec);
    onClose();
  };
  return (
    <Sheet visible={visible} title={device ? 'تعديل جهاز' : 'جهاز جديد'} onClose={onClose} tall footer={<Btn title="حفظ الجهاز" icon="checkmark" onPress={save} />}>
      <Picker label="الموديل" value={modelId} options={opts} onSelect={setModelId} allowClear placeholder="اختر من القائمة..." />
      <Field label="أو وصف يدوي (جهاز غير مدرج)" value={f.manual} onChangeText={set('manual')} placeholder="مثال: تابلت صيني 10 بوصة" />
      <Field label="IMEI" value={f.imei} onChangeText={set('imei')} keyboardType="number-pad" />
      <Field label="الرقم التسلسلي" value={f.serial} onChangeText={set('serial')} autoCapitalize="characters" />
      <View style={[row, { gap: 10 }]}>
        <Field style={{ flex: 1 }} label="اللون" value={f.color} onChangeText={set('color')} />
        <Field style={{ flex: 1 }} label="السعة" value={f.storage} onChangeText={set('storage')} placeholder="128GB" />
      </View>
      <Field label="حالة الجهاز" value={f.condition} onChangeText={set('condition')} placeholder="جيدة، خدوش..." />
      <Field label="ملاحظات" value={f.notes} onChangeText={set('notes')} multiline />
    </Sheet>
  );
}

export const deviceName = (db: ReturnType<typeof useStore>['db'], d?: CustDevice) => {
  if (!d) return 'جهاز غير معروف';
  const m = db.models.find((x) => x.id === d.modelId);
  return m ? `${m.brand} ${m.name}` : d.manual || 'جهاز';
};
