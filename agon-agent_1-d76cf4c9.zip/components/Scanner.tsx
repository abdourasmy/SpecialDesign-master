import React, { useEffect, useRef } from 'react';
import { Modal, View, Platform } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { Btn, T, row } from './ui';
import { useTheme } from '../lib/theme';

export default function Scanner({ visible, onScan, onClose }: { visible: boolean; onScan: (code: string) => void; onClose: () => void }) {
  const th = useTheme();
  const [perm, request] = useCameraPermissions();
  const last = useRef('');
  useEffect(() => { if (visible) last.current = ''; }, [visible]);
  return (
    <Modal visible={visible} animationType="slide" onRequestClose={onClose}>
      <View style={{ flex: 1, backgroundColor: '#000', justifyContent: 'center' }}>
        {perm?.granted ? (
          <CameraView
            style={{ flex: 1 }}
            facing="back"
            barcodeScannerSettings={{ barcodeTypes: ['ean13', 'ean8', 'code128', 'code39', 'qr', 'upc_a', 'upc_e'] }}
            onBarcodeScanned={({ data }) => {
              if (data && data !== last.current) {
                last.current = data;
                onScan(data);
              }
            }}
          />
        ) : (
          <View style={{ padding: 24, gap: 14, alignItems: 'center' }}>
            <T v="h3" color="#fff" style={{ textAlign: 'center' }}>يحتاج المسح إلى إذن الكاميرا</T>
            <T v="sub" color="#aaa" style={{ textAlign: 'center' }}>يمكنك أيضاً كتابة الباركود في حقل البحث أو استخدام قارئ باركود خارجي.</T>
            <Btn title="منح الإذن" icon="camera" onPress={() => request()} />
          </View>
        )}
        <View style={{ position: 'absolute', bottom: 40, left: 20, right: 20 }}>
          <Btn title="إغلاق" variant="ghost" icon="close" onPress={onClose} />
        </View>
        {perm?.granted ? (
          <View pointerEvents="none" style={{ position: 'absolute', top: '35%', alignSelf: 'center', width: 260, height: 130, borderWidth: 3, borderColor: th.accent, borderRadius: 16 }} />
        ) : null}
      </View>
    </Modal>
  );
}
