import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import {
  View, Text, TextInput, Pressable, Modal, ScrollView, KeyboardAvoidingView, Platform, StyleSheet, Animated,
  TextInputProps, ViewStyle, TextStyle, FlatList, ActivityIndicator,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import Ionicons from '@expo/vector-icons/Ionicons';
import { R, Theme, useTheme } from '../lib/theme';
import { useStore } from '../lib/store';
import { Perm } from '../lib/engine';

export type IconName = React.ComponentProps<typeof Ionicons>['name'];

export const row: ViewStyle = { flexDirection: 'row-reverse', alignItems: 'center' };

// ---------- Text ----------
type TV = 'h1' | 'h2' | 'h3' | 'body' | 'sub' | 'small' | 'bold';
export function T({ v = 'body', style, color, children, numberOfLines, onPress }: {
  v?: TV; style?: TextStyle | TextStyle[]; color?: string; children?: React.ReactNode; numberOfLines?: number; onPress?: () => void;
}) {
  const th = useTheme();
  const base: Record<TV, TextStyle> = {
    h1: { fontSize: 24, fontWeight: '800', color: th.text },
    h2: { fontSize: 19, fontWeight: '700', color: th.text },
    h3: { fontSize: 16, fontWeight: '700', color: th.text },
    body: { fontSize: 15, color: th.text },
    bold: { fontSize: 15, fontWeight: '700', color: th.text },
    sub: { fontSize: 13, color: th.sub },
    small: { fontSize: 11.5, color: th.sub },
  };
  return (
    <Text onPress={onPress} numberOfLines={numberOfLines} style={[{ textAlign: 'right', writingDirection: 'rtl' }, base[v], color ? { color } : null, style as any]}>
      {children}
    </Text>
  );
}

export function toneColors(th: Theme, tone: string): { bg: string; fg: string } {
  switch (tone) {
    case 'success': return { bg: th.successSoft, fg: th.success };
    case 'danger': return { bg: th.dangerSoft, fg: th.danger };
    case 'warn': return { bg: th.warnSoft, fg: th.warn };
    case 'info': return { bg: th.infoSoft, fg: th.info };
    case 'primary': return { bg: th.primarySoft, fg: th.primary };
    default: return { bg: th.border, fg: th.sub };
  }
}

export function Badge({ text, tone = 'muted', icon }: { text: string; tone?: string; icon?: IconName }) {
  const th = useTheme();
  const c = toneColors(th, tone);
  return (
    <View style={[row, { backgroundColor: c.bg, paddingHorizontal: 9, paddingVertical: 4, borderRadius: 20, alignSelf: 'flex-start', gap: 4 }]}>
      {icon ? <Ionicons name={icon} size={12} color={c.fg} /> : null}
      <Text style={{ color: c.fg, fontSize: 11.5, fontWeight: '700' }}>{text}</Text>
    </View>
  );
}

// ---------- Layout ----------
export function Screen({ title, subtitle, onBack, right, children, noPad }: {
  title: string; subtitle?: string; onBack?: () => void; right?: React.ReactNode; children: React.ReactNode; noPad?: boolean;
}) {
  const th = useTheme();
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: th.bg }} edges={['top']}>
      <View style={[row, { paddingHorizontal: 16, paddingVertical: 12, gap: 10 }]}>
        {onBack ? (
          <Pressable onPress={onBack} hitSlop={10} style={[s.iconBtn, { backgroundColor: th.card, borderColor: th.border }]}>
            <Ionicons name="chevron-forward" size={22} color={th.text} />
          </Pressable>
        ) : null}
        <View style={{ flex: 1 }}>
          <T v="h2" numberOfLines={1}>{title}</T>
          {subtitle ? <T v="small" numberOfLines={1}>{subtitle}</T> : null}
        </View>
        <View style={[row, { gap: 8 }]}>{right}</View>
      </View>
      <View style={{ flex: 1, paddingHorizontal: noPad ? 0 : 16 }}>{children}</View>
    </SafeAreaView>
  );
}

export function Card({ children, style, onPress }: { children: React.ReactNode; style?: ViewStyle | ViewStyle[]; onPress?: () => void }) {
  const th = useTheme();
  const st: ViewStyle[] = [{ backgroundColor: th.card, borderRadius: R.lg, padding: 14, borderWidth: 1, borderColor: th.border, shadowColor: '#0F172A', shadowOpacity: th.dark ? 0 : 0.05, shadowRadius: 8, shadowOffset: { width: 0, height: 2 }, elevation: th.dark ? 0 : 1 }, ...(Array.isArray(style) ? style : style ? [style] : [])];
  if (onPress) return <Pressable onPress={onPress} style={({ pressed }) => [...st, pressed ? { opacity: 0.85 } : null]}>{children}</Pressable>;
  return <View style={st}>{children}</View>;
}

export function IconButton({ icon, onPress, color, bg, size = 20 }: { icon: IconName; onPress: () => void; color?: string; bg?: string; size?: number }) {
  const th = useTheme();
  return (
    <Pressable onPress={onPress} hitSlop={8} style={[s.iconBtn, { backgroundColor: bg || th.card, borderColor: th.border }]}>
      <Ionicons name={icon} size={size} color={color || th.text} />
    </Pressable>
  );
}

export function Btn({ title, onPress, icon, variant = 'primary', small, disabled, flex, loading }: {
  title: string; onPress: () => void; icon?: IconName; variant?: 'primary' | 'soft' | 'ghost' | 'danger' | 'accent' | 'success'; small?: boolean; disabled?: boolean; flex?: boolean; loading?: boolean;
}) {
  const th = useTheme();
  const map = {
    primary: { bg: th.primary, fg: '#fff', bd: th.primary },
    accent: { bg: th.accent, fg: '#1F1300', bd: th.accent },
    success: { bg: th.success, fg: '#fff', bd: th.success },
    soft: { bg: th.primarySoft, fg: th.primary, bd: th.primarySoft },
    ghost: { bg: 'transparent', fg: th.text, bd: th.border },
    danger: { bg: th.dangerSoft, fg: th.danger, bd: th.dangerSoft },
  }[variant];
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled || loading}
      style={({ pressed }) => [
        row, { justifyContent: 'center', gap: 7, backgroundColor: map.bg, borderColor: map.bd, borderWidth: 1, borderRadius: R.md, paddingHorizontal: small ? 12 : 18, paddingVertical: small ? 8 : 13, opacity: disabled ? 0.45 : pressed ? 0.85 : 1 },
        flex ? { flex: 1 } : null,
      ]}
    >
      {loading ? <ActivityIndicator color={map.fg} size="small" /> : icon ? <Ionicons name={icon} size={small ? 15 : 18} color={map.fg} /> : null}
      <Text style={{ color: map.fg, fontWeight: '700', fontSize: small ? 13 : 15 }}>{title}</Text>
    </Pressable>
  );
}

export function Chip({ label, active, onPress, icon, tone }: { label: string; active?: boolean; onPress?: () => void; icon?: IconName; tone?: string }) {
  const th = useTheme();
  return (
    <Pressable onPress={onPress} style={[row, { gap: 5, paddingHorizontal: 13, paddingVertical: 7, borderRadius: 20, borderWidth: 1, backgroundColor: active ? th.primary : th.card, borderColor: active ? th.primary : th.border }]}>
      {icon ? <Ionicons name={icon} size={14} color={active ? '#fff' : th.sub} /> : null}
      <Text style={{ color: active ? '#fff' : th.text, fontWeight: '600', fontSize: 13 }}>{label}</Text>
    </Pressable>
  );
}

export function ChipRow({ children }: { children: React.ReactNode }) {
  return (
    <View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ flexDirection: 'row-reverse', gap: 8, paddingVertical: 4 }}>
        {children}
      </ScrollView>
    </View>
  );
}

export function Field({ label, value, onChangeText, hint, error, multiline, style, ...rest }: TextInputProps & { label?: string; hint?: string; error?: string; value: string; onChangeText: (t: string) => void }) {
  const th = useTheme();
  return (
    <View style={[{ marginBottom: 12 }, style as any]}>
      {label ? <T v="sub" style={{ marginBottom: 5, fontWeight: '600' }}>{label}</T> : null}
      <TextInput
        {...rest}
        value={value}
        onChangeText={onChangeText}
        multiline={multiline}
        placeholderTextColor={th.sub}
        style={{
          backgroundColor: th.input, borderWidth: 1, borderColor: error ? th.danger : th.border, borderRadius: R.md, paddingHorizontal: 13,
          paddingVertical: multiline ? 11 : 11, minHeight: multiline ? 84 : 46, color: th.text, fontSize: 15, textAlign: 'right', writingDirection: 'rtl',
          textAlignVertical: multiline ? 'top' : 'center', ...(Platform.OS === 'web' ? ({ outlineStyle: 'none' } as any) : null),
        }}
      />
      {error ? <T v="small" color={th.danger} style={{ marginTop: 3 }}>{error}</T> : hint ? <T v="small" style={{ marginTop: 3 }}>{hint}</T> : null}
    </View>
  );
}

export function SearchBar({ value, onChangeText, placeholder, onSubmit, right }: { value: string; onChangeText: (t: string) => void; placeholder?: string; onSubmit?: () => void; right?: React.ReactNode }) {
  const th = useTheme();
  return (
    <View style={[row, { gap: 8, marginBottom: 8 }]}>
      <View style={[row, { flex: 1, backgroundColor: th.card, borderRadius: R.md, borderWidth: 1, borderColor: th.border, paddingHorizontal: 12, gap: 8 }]}>
        <Ionicons name="search" size={18} color={th.sub} />
        <TextInput
          value={value}
          onChangeText={onChangeText}
          placeholder={placeholder || 'بحث...'}
          placeholderTextColor={th.sub}
          onSubmitEditing={onSubmit}
          returnKeyType="search"
          style={{ flex: 1, paddingVertical: 11, color: th.text, fontSize: 15, textAlign: 'right', writingDirection: 'rtl', ...(Platform.OS === 'web' ? ({ outlineStyle: 'none' } as any) : null) }}
        />
        {value ? <Pressable onPress={() => onChangeText('')} hitSlop={8}><Ionicons name="close-circle" size={18} color={th.sub} /></Pressable> : null}
      </View>
      {right}
    </View>
  );
}

export function Empty({ icon = 'file-tray-outline', title, sub, action }: { icon?: IconName; title: string; sub?: string; action?: React.ReactNode }) {
  const th = useTheme();
  return (
    <View style={{ alignItems: 'center', padding: 36, gap: 8 }}>
      <View style={{ width: 70, height: 70, borderRadius: 35, backgroundColor: th.primarySoft, alignItems: 'center', justifyContent: 'center' }}>
        <Ionicons name={icon} size={32} color={th.primary} />
      </View>
      <T v="h3" style={{ textAlign: 'center' }}>{title}</T>
      {sub ? <T v="sub" style={{ textAlign: 'center' }}>{sub}</T> : null}
      {action}
    </View>
  );
}

export function SectionTitle({ title, right }: { title: string; right?: React.ReactNode }) {
  return (
    <View style={[row, { justifyContent: 'space-between', marginTop: 18, marginBottom: 8 }]}>
      <T v="h3">{title}</T>
      {right}
    </View>
  );
}

export function KV({ k, v, color, bold }: { k: string; v: string; color?: string; bold?: boolean }) {
  return (
    <View style={[row, { justifyContent: 'space-between', paddingVertical: 5, gap: 10 }]}>
      <T v="sub">{k}</T>
      <T v={bold ? 'bold' : 'body'} color={color} style={{ flexShrink: 1 }}>{v}</T>
    </View>
  );
}

export function Stat({ label, value, icon, tone = 'primary', sub, flex = true }: { label: string; value: string; icon: IconName; tone?: string; sub?: string; flex?: boolean }) {
  const th = useTheme();
  const c = toneColors(th, tone);
  return (
    <Card style={[flex ? { flex: 1, minWidth: '45%' } : {}, { gap: 6 }] as any}>
      <View style={[row, { justifyContent: 'space-between' }]}>
        <View style={{ width: 34, height: 34, borderRadius: 10, backgroundColor: c.bg, alignItems: 'center', justifyContent: 'center' }}>
          <Ionicons name={icon} size={18} color={c.fg} />
        </View>
        <T v="sub">{label}</T>
      </View>
      <T v="h2" style={{ fontSize: 20 }}>{value}</T>
      {sub ? <T v="small">{sub}</T> : null}
    </Card>
  );
}

export function Fab({ icon = 'add', onPress, label }: { icon?: IconName; onPress: () => void; label?: string }) {
  const th = useTheme();
  return (
    <Pressable
      onPress={onPress}
      style={[row, { position: 'absolute', bottom: 18, left: 18, backgroundColor: th.accent, borderRadius: 28, height: 56, paddingHorizontal: label ? 18 : 0, width: label ? undefined : 56, justifyContent: 'center', gap: 6, shadowColor: '#000', shadowOpacity: 0.25, shadowRadius: 8, shadowOffset: { width: 0, height: 4 }, elevation: 6 }]}
    >
      <Ionicons name={icon} size={24} color="#1F1300" />
      {label ? <Text style={{ color: '#1F1300', fontWeight: '800' }}>{label}</Text> : null}
    </Pressable>
  );
}

export function Stepper({ value, onChange, min = 0, max }: { value: number; onChange: (n: number) => void; min?: number; max?: number }) {
  const th = useTheme();
  const b = (icon: IconName, d: number, off: boolean) => (
    <Pressable disabled={off} onPress={() => onChange(value + d)} style={{ width: 32, height: 32, borderRadius: 10, backgroundColor: th.primarySoft, alignItems: 'center', justifyContent: 'center', opacity: off ? 0.4 : 1 }}>
      <Ionicons name={icon} size={18} color={th.primary} />
    </Pressable>
  );
  return (
    <View style={[row, { gap: 8 }]}>
      {b('add', 1, max !== undefined && value >= max)}
      <Text style={{ minWidth: 26, textAlign: 'center', fontWeight: '800', fontSize: 16, color: th.text }}>{value}</Text>
      {b('remove', -1, value <= min)}
    </View>
  );
}

export function Switch2({ value, onChange, label }: { value: boolean; onChange: (v: boolean) => void; label: string }) {
  const th = useTheme();
  return (
    <Pressable onPress={() => onChange(!value)} style={[row, { gap: 10, paddingVertical: 8 }]}>
      <View style={{ width: 24, height: 24, borderRadius: 7, borderWidth: 2, borderColor: value ? th.primary : th.border, backgroundColor: value ? th.primary : 'transparent', alignItems: 'center', justifyContent: 'center' }}>
        {value ? <Ionicons name="checkmark" size={16} color="#fff" /> : null}
      </View>
      <T style={{ flex: 1 }}>{label}</T>
    </Pressable>
  );
}

// ---------- Sheet ----------
export function Sheet({ visible, title, onClose, children, footer, tall }: { visible: boolean; title: string; onClose: () => void; children: React.ReactNode; footer?: React.ReactNode; tall?: boolean }) {
  const th = useTheme();
  const ins = useSafeAreaInsets();
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose} statusBarTranslucent>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1, justifyContent: 'flex-end', backgroundColor: th.overlay }}>
        <Pressable style={{ flex: 1 }} onPress={onClose} />
        <View style={{ backgroundColor: th.bg, borderTopLeftRadius: 24, borderTopRightRadius: 24, maxHeight: '92%', height: tall ? '90%' : undefined, paddingBottom: Math.max(ins.bottom, 12), width: '100%', maxWidth: 560, alignSelf: 'center' }}>
          <View style={[row, { padding: 16, justifyContent: 'space-between' }]}>
            <T v="h2">{title}</T>
            <IconButton icon="close" onPress={onClose} />
          </View>
          <ScrollView style={tall ? { flex: 1 } : { flexGrow: 0 }} contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 12 }} keyboardShouldPersistTaps="handled">
            {children}
          </ScrollView>
          {footer ? <View style={{ paddingHorizontal: 16, paddingTop: 8 }}>{footer}</View> : null}
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

// ---------- Picker ----------
export interface Opt { id: string; label: string; sub?: string; right?: string }
export function Picker({ label, value, options, onSelect, placeholder = 'اختر...', allowClear, searchable = true, icon = 'chevron-down' }: {
  label?: string; value?: string | null; options: Opt[]; onSelect: (id: string | null) => void; placeholder?: string; allowClear?: boolean; searchable?: boolean; icon?: IconName;
}) {
  const th = useTheme();
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState('');
  const cur = options.find((o) => o.id === value);
  const list = q ? options.filter((o) => (o.label + ' ' + (o.sub || '')).toLowerCase().includes(q.toLowerCase())) : options;
  return (
    <View style={{ marginBottom: 12 }}>
      {label ? <T v="sub" style={{ marginBottom: 5, fontWeight: '600' }}>{label}</T> : null}
      <Pressable onPress={() => { setQ(''); setOpen(true); }} style={[row, { backgroundColor: th.input, borderWidth: 1, borderColor: th.border, borderRadius: R.md, paddingHorizontal: 13, minHeight: 46, justifyContent: 'space-between' }]}>
        <T style={{ flex: 1, color: cur ? th.text : th.sub }} numberOfLines={1}>{cur ? cur.label : placeholder}</T>
        <Ionicons name={icon} size={18} color={th.sub} />
      </Pressable>
      <Sheet visible={open} title={label || 'اختيار'} onClose={() => setOpen(false)} tall>
        {searchable ? <SearchBar value={q} onChangeText={setQ} /> : null}
        {allowClear ? (
          <Pressable onPress={() => { onSelect(null); setOpen(false); }} style={{ paddingVertical: 12 }}>
            <T color={th.danger}>بدون اختيار</T>
          </Pressable>
        ) : null}
        {list.length === 0 ? <Empty title="لا توجد نتائج" icon="search-outline" /> : null}
        {list.map((o) => (
          <Pressable key={o.id} onPress={() => { onSelect(o.id); setOpen(false); }} style={[row, { paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: th.border, gap: 10 }]}>
            <View style={{ flex: 1 }}>
              <T v="bold">{o.label}</T>
              {o.sub ? <T v="small">{o.sub}</T> : null}
            </View>
            {o.right ? <T v="sub">{o.right}</T> : null}
            {o.id === value ? <Ionicons name="checkmark-circle" size={20} color={th.primary} /> : null}
          </Pressable>
        ))}
      </Sheet>
    </View>
  );
}

// ---------- Dialog / toast ----------
interface DialogApi {
  alert: (title: string, message?: string) => void;
  confirm: (title: string, message?: string, opts?: { confirmText?: string; danger?: boolean }) => Promise<boolean>;
  toast: (msg: string, tone?: 'success' | 'danger' | 'info') => void;
}
const DialogCtx = createContext<DialogApi>(null as any);
export const useDialog = () => useContext(DialogCtx);

export function DialogProvider({ children }: { children: React.ReactNode }) {
  const th = useTheme();
  const [d, setD] = useState<null | { title: string; message?: string; confirm?: boolean; confirmText?: string; danger?: boolean; resolve: (v: boolean) => void }>(null);
  const [toast, setToast] = useState<null | { msg: string; tone: string; id: number }>(null);
  const anim = useRef(new Animated.Value(0)).current;

  const api = useRef<DialogApi>({
    alert: (title, message) => setD({ title, message, resolve: () => {} }),
    confirm: (title, message, opts) => new Promise<boolean>((resolve) => setD({ title, message, confirm: true, confirmText: opts?.confirmText, danger: opts?.danger, resolve })),
    toast: (msg, tone = 'success') => setToast({ msg, tone, id: Date.now() }),
  }).current;

  useEffect(() => {
    if (!toast) return;
    anim.setValue(0);
    Animated.sequence([Animated.timing(anim, { toValue: 1, duration: 200, useNativeDriver: true }), Animated.delay(2200), Animated.timing(anim, { toValue: 0, duration: 250, useNativeDriver: true })]).start(() => setToast(null));
  }, [toast?.id]);

  const close = (v: boolean) => { d?.resolve(v); setD(null); };
  const tc = toast ? (toast.tone === 'danger' ? th.danger : toast.tone === 'info' ? th.info : th.success) : th.success;
  return (
    <DialogCtx.Provider value={api}>
      {children}
      <Modal visible={!!d} transparent animationType="fade" onRequestClose={() => close(false)} statusBarTranslucent>
        <View style={{ flex: 1, backgroundColor: th.overlay, alignItems: 'center', justifyContent: 'center', padding: 24 }}>
          <View style={{ backgroundColor: th.card, borderRadius: R.xl, padding: 20, width: '100%', maxWidth: 400, gap: 10 }}>
            <T v="h3">{d?.title}</T>
            {d?.message ? <T v="sub" style={{ lineHeight: 21, fontSize: 14 }}>{d.message}</T> : null}
            <View style={[row, { gap: 10, marginTop: 8 }]}>
              <Btn flex title={d?.confirm ? (d.confirmText || 'تأكيد') : 'حسناً'} variant={d?.danger ? 'danger' : 'primary'} onPress={() => close(true)} />
              {d?.confirm ? <Btn flex title="إلغاء" variant="ghost" onPress={() => close(false)} /> : null}
            </View>
          </View>
        </View>
      </Modal>
      {toast ? (
        <Animated.View pointerEvents="none" style={{ position: 'absolute', bottom: 96, left: 20, right: 20, alignItems: 'center', opacity: anim, transform: [{ translateY: anim.interpolate({ inputRange: [0, 1], outputRange: [20, 0] }) }] }}>
          <View style={[row, { backgroundColor: th.dark ? '#E2E8F0' : '#0F172A', paddingHorizontal: 16, paddingVertical: 11, borderRadius: 14, gap: 8, maxWidth: 480 }]}>
            <Ionicons name={toast.tone === 'danger' ? 'alert-circle' : 'checkmark-circle'} size={20} color={tc} />
            <Text style={{ color: th.dark ? '#0F172A' : '#fff', fontWeight: '600', textAlign: 'right', flexShrink: 1 }}>{toast.msg}</Text>
          </View>
        </Animated.View>
      ) : null}
    </DialogCtx.Provider>
  );
}

// ---------- Guard / misc ----------
export function Guard({ perm, children }: { perm: Perm; children: React.ReactNode }) {
  const { can, user } = useStore();
  if (can(perm)) return <>{children}</>;
  return (
    <View style={{ flex: 1, justifyContent: 'center' }}>
      <Empty icon="lock-closed-outline" title="لا تملك الصلاحية" sub={`دورك الحالي (${user.name}) لا يسمح بالوصول إلى هذه الشاشة. بدّل المستخدم من قسم الموظفين والصلاحيات.`} />
    </View>
  );
}

export function SyncBadge({ state }: { state: string }) {
  const m: Record<string, { t: string; tone: string; icon: IconName }> = {
    local: { t: 'مؤكد محلياً', tone: 'primary', icon: 'checkmark-done' },
    pending: { t: 'بانتظار المزامنة', tone: 'warn', icon: 'sync' },
    synced: { t: 'تمت المزامنة', tone: 'success', icon: 'cloud-done' },
    needs_review: { t: 'يحتاج مراجعة', tone: 'danger', icon: 'warning' },
  };
  const x = m[state] || m.local;
  return <Badge text={x.t} tone={x.tone} icon={x.icon} />;
}

export function Avatar({ name, size = 42, tone = 'primary' }: { name: string; size?: number; tone?: string }) {
  const th = useTheme();
  const c = toneColors(th, tone);
  return (
    <View style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: c.bg, alignItems: 'center', justifyContent: 'center' }}>
      <Text style={{ color: c.fg, fontWeight: '800', fontSize: size * 0.4 }}>{(name || '؟').trim().charAt(0)}</Text>
    </View>
  );
}

export function Divider() {
  const th = useTheme();
  return <View style={{ height: 1, backgroundColor: th.border, marginVertical: 8 }} />;
}

export function ListLoading() {
  const th = useTheme();
  return <ActivityIndicator color={th.primary} style={{ marginTop: 40 }} />;
}

export { FlatList };

const s = StyleSheet.create({
  iconBtn: { width: 40, height: 40, borderRadius: 12, alignItems: 'center', justifyContent: 'center', borderWidth: 1 },
});
